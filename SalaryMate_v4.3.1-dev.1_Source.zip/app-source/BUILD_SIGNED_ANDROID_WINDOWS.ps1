$ErrorActionPreference = 'Stop'

Set-Location $PSScriptRoot

$defaultKeystore = Join-Path $env:USERPROFILE 'SalaryMateKeys\salarymate-upload.jks'
$keystorePath = Read-Host "Keystore path [$defaultKeystore]"
if ([string]::IsNullOrWhiteSpace($keystorePath)) {
    $keystorePath = $defaultKeystore
}
if (-not (Test-Path -LiteralPath $keystorePath -PathType Leaf)) {
    Write-Error "Keystore not found: $keystorePath"
    exit 2
}

$keyAlias = Read-Host 'Key alias [salarymate-upload]'
if ([string]::IsNullOrWhiteSpace($keyAlias)) {
    $keyAlias = 'salarymate-upload'
}

$storePassword = Read-Host 'Keystore password' -AsSecureString
$keyPassword = Read-Host 'Private key password' -AsSecureString

try {
    $env:SALARYMATE_KEYSTORE_FILE = (Resolve-Path -LiteralPath $keystorePath).Path
    $env:SALARYMATE_KEY_ALIAS = $keyAlias
    $env:SALARYMATE_STORE_PASSWORD = [System.Net.NetworkCredential]::new('', $storePassword).Password
    $env:SALARYMATE_KEY_PASSWORD = [System.Net.NetworkCredential]::new('', $keyPassword).Password

    & cmd.exe /d /c 'call BUILD_ANDROID_WINDOWS.cmd'
    $buildExitCode = $LASTEXITCODE
}
finally {
    Remove-Item Env:SALARYMATE_KEYSTORE_FILE -ErrorAction SilentlyContinue
    Remove-Item Env:SALARYMATE_KEY_ALIAS -ErrorAction SilentlyContinue
    Remove-Item Env:SALARYMATE_STORE_PASSWORD -ErrorAction SilentlyContinue
    Remove-Item Env:SALARYMATE_KEY_PASSWORD -ErrorAction SilentlyContinue
}

exit $buildExitCode
