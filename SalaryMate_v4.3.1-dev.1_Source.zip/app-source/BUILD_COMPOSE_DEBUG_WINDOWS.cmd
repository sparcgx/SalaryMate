@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SalaryMate v4.3.1-dev.1 Compose Debug Build

echo.
echo =====================================================
echo  SalaryMate v4.3.1-dev.1 - Compose Debug APK Build
echo =====================================================
echo.

if not "%ANDROID_HOME%"=="" goto sdk_ready
if not exist "%LOCALAPPDATA%\Android\Sdk" goto sdk_ready
set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
:sdk_ready

if "%ANDROID_HOME%"=="" goto path_sdk_ready
set "PATH=%ANDROID_HOME%\platform-tools;%ANDROID_HOME%\cmdline-tools\latest\bin;%PATH%"
:path_sdk_ready

where node >nul 2>nul
if errorlevel 1 goto missing_node

for /f "usebackq delims=" %%J in (`node scripts\select-java-home-windows.mjs`) do set "JAVA_HOME=%%J"
if "%JAVA_HOME%"=="" goto missing_java
if not exist "%JAVA_HOME%\bin\keytool.exe" goto missing_java
set "PATH=%JAVA_HOME%\bin;%PATH%"

echo [1/8] Installing locked dependencies...
call npm ci
if errorlevel 1 goto failed

echo [2/8] Checking JDK and Android SDK...
call npm run android:doctor
if errorlevel 1 goto environment_hold

echo [3/8] Running payroll, security, and Compose shell tests...
call npm test
if errorlevel 1 goto failed

echo [4/8] Auditing runtime dependencies...
call npm run audit:runtime
if errorlevel 1 goto failed

echo [5/8] Building local App assets...
call npm run build
if errorlevel 1 goto failed

echo [6/8] Synchronizing Android plugins...
call npx cap sync android
if errorlevel 1 goto failed

echo [7/8] Compiling tests and Compose Debug APK...
pushd android
call gradlew.bat :app:testDebugUnitTest :app:assembleDebugAndroidTest :app:assembleDebug --no-daemon
set "BUILD_RESULT=%ERRORLEVEL%"
popd
if not "%BUILD_RESULT%"=="0" goto failed

set "APK_SOURCE=android\app\build\outputs\apk\debug\app-debug.apk"
if not exist "%APK_SOURCE%" goto missing_output

echo [8/8] Verifying identity, signature, and permissions...
set "APKSIGNER=%ANDROID_HOME%\build-tools\35.0.0\apksigner.bat"
set "AAPT=%ANDROID_HOME%\build-tools\35.0.0\aapt.exe"
if not exist "%APKSIGNER%" goto missing_build_tools
if not exist "%AAPT%" goto missing_build_tools
call "%APKSIGNER%" verify --verbose "%APK_SOURCE%"
if errorlevel 1 goto failed
call "%AAPT%" dump badging "%APK_SOURCE%" | findstr /C:"package: name='com.salarymate.personal.debug'" >nul
if errorlevel 1 goto failed
call "%AAPT%" dump badging "%APK_SOURCE%" | findstr /C:"versionCode='20'" >nul
if errorlevel 1 goto failed
set "PERMISSION_REPORT=%TEMP%\salarymate-compose-debug-permissions-%RANDOM%.txt"
call "%AAPT%" dump permissions "%APK_SOURCE%" > "%PERMISSION_REPORT%"
if errorlevel 1 goto failed
findstr /L /C:"android.permission.INTERNET" /C:"android.permission.ACCESS_NETWORK_STATE" /C:"android.permission.READ_EXTERNAL_STORAGE" /C:"android.permission.WRITE_EXTERNAL_STORAGE" /C:"android.permission.MANAGE_EXTERNAL_STORAGE" /C:"android.permission.CAMERA" /C:"android.permission.RECORD_AUDIO" /C:"android.permission.ACCESS_FINE_LOCATION" /C:"android.permission.ACCESS_COARSE_LOCATION" /C:"android.permission.POST_NOTIFICATIONS" "%PERMISSION_REPORT%" >nul
if not errorlevel 1 goto unexpected_permission
del /Q "%PERMISSION_REPORT%" >nul 2>nul
set "PERMISSION_REPORT="

if exist "output" goto output_ready
mkdir "output"
:output_ready
copy /Y "%APK_SOURCE%" "output\SalaryMate_v4.3.1-dev.1-compose-debug.apk" >nul
certutil -hashfile "output\SalaryMate_v4.3.1-dev.1-compose-debug.apk" SHA256

echo.
echo SUCCESS. Compose Debug APK created:
echo %CD%\output\SalaryMate_v4.3.1-dev.1-compose-debug.apk
echo.
echo Run INSTALL_COMPOSE_DEBUG_WINDOWS.cmd to install beside the Release App.
echo Then run RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd and follow ANDROID_v4.1.0_ACCEPTANCE.md.
pause
exit /b 0

:missing_node
echo.
echo HOLD: Node.js was not found. Install Node.js 24 LTS, close this window, and retry.
goto hold

:missing_java
echo.
echo HOLD: JDK 21 with keytool was not found. Install or select JDK 21, then retry.
goto hold

:environment_hold
echo.
echo HOLD: Complete each item marked HOLD above, then retry.
echo SDK items use Android Studio SDK Manager. This build requires JDK 21.
goto hold

:missing_build_tools
echo.
echo HOLD: Build Tools 35.0.0 apksigner or aapt was not found.
goto hold

:missing_output
echo.
echo FAILED: Gradle returned success, but the Debug APK was not found.
goto hold

:unexpected_permission
if defined PERMISSION_REPORT if exist "%PERMISSION_REPORT%" del /Q "%PERMISSION_REPORT%" >nul 2>nul
echo.
echo FAILED: The merged Debug APK contains an unexpected network, storage, media, location, or notification permission.
goto hold

:failed
echo.
echo BUILD FAILED. Capture the first ERROR through the final line and send it for diagnosis.

:hold
pause
exit /b 1
