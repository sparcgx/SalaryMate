# v4.1.0｜正式版準備與放行閘門

日期：2026-09-23

輸入基線：`v4.1.0-RC.1`。此工作樹獨立於 RC.1 與 dev.4-R2，不修改已交付基線。

## 版本與不變項

- versionCode 12、versionName 4.1.0。
- Release App ID `com.salarymate.personal`；Debug App ID `com.salarymate.personal.debug`。
- `salarymateSQLite.db`、Schema 13、最近 3 份 Snapshot、歷史 1,373 筆 OT 與 `.salarymate` 加密格式不變。
- 本包為正式版「原始碼／建置準備包」，不是已簽章 APK 或已上架 AAB。

## 發布前證據

| 閘門 | 狀態 | 完成條件 |
|---|---|---|
| RC.1 實機 1～72 | 未提供 | 完整執行紀錄與失敗項清單；不可沿用 dev.4-R2 的 1～58 |
| RC.1 覆蓋升級與資料保留 | 未提供 | 相同簽章、安裝前後身分紀錄、資料筆數與關鍵金額一致 |
| RC.1 加密備份互通 | 未提供 | 雙向解密及錯誤密碼／損壞檔案防寫入 |
| RC.1 Internal testing | 未提供 | Play 安裝版及預發布報告的實際結果 |
| 正式版本機回歸 | PASS（本機） | `npm test`、`npm run build`、`npm run android:sync` 通過，runtime audit 為 0 弱點 |
| 正式版 Windows 編譯 | 待 Windows | Debug、單元／instrumentation、signed APK／AAB 建置成功 |
| 正式版裝置與簽章 | 待實機 | 裝置測試、簽章比對、版本身分、權限；安裝前兩份備份 |
| 正式版升級與資料 | 待實機 | 覆蓋安裝不解除安裝／不清資料；各筆數與金額、鎖定狀態不變 |
| 正式版 Play 驗證 | 待 Internal testing | 以正式版 AAB 執行 Play 安裝與回歸，保留證據 |

本執行環境只有 JDK 17，未配置 Android SDK／ADB；本機回歸 PASS 不代表 Kotlin、APK／AAB 或實機 PASS。

Windows 裝置 Gate 會在 `test-results\formal-v4.1.0\<執行編號>\` 自動保存 `result.txt`、`result.json`、`test.log`；此紀錄只證明其中真正執行的自動化步驟，不能替代 RC.1 1～72 與正式版升級、備份及 Play 人工驗收。

填寫 `FORMAL_RELEASE_EVIDENCE.md`，附上編譯輸出、SHA-256、簽章指紋與實機驗收紀錄。若手機現有版本由 Play 簽署，本機 upload-key APK 可能不能直接覆蓋；此情況以 Play 的 Internal testing 升級路徑驗證，不卸載原 App。

## 判定

- 目前狀態：**HOLD FOR RELEASE**。使用者要求進入正式版準備，不代表上述 RC.1 或正式版實機 Gate 已 PASS。
- 全部證據核對通過後，才能標記 **GO FOR RELEASE REVIEW**，另行核准 Production。
- 任何資料差異、簽章衝突或備份失敗，立即停止；保留兩份可解密備份，不解除安裝、不清除資料。
