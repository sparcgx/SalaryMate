# v4.1.0-dev.1｜Compose App Shell 開發閘門

日期：2026-09-18

## 範圍

本版是 Compose 漸進移植第一階段，不是正式發布候選。RC3 的 Schema 13、薪資計算、SQLite、加密備份與安全插件維持單一來源。

| 檢查 | 狀態 | 證據 |
|---|---|---|
| RC3 凍結保護 | PASS | 另建 `feature/v4.1.0-dev.1-compose-app-shell` |
| Compose 建置設定 | PASS（靜態） | Kotlin 2.3.21、Compose BOM 2026.06.01、AGP 8.13；Java/Kotlin/Toolchain 統一 JVM 21 |
| 原生啟動入口 | PASS（靜態） | `ComposeShellActivity` 為唯一 Launcher |
| Web 核心保留 | PASS | `MainActivity` 保留 Capacitor 與兩個既有原生插件 |
| 資料單一來源 | PASS | Compose Shell 無 SQLite、SharedPreferences 或薪資公式 |
| 導覽安全 | PASS | 分頁與操作均由 Java 白名單限制 |
| 版本隔離 | PASS | versionCode 7、versionName 4.1.0-dev.1；Debug 使用 `.debug` |
| Web／資料回歸 | PASS | 完整測試鏈、Compose 靜態門檻與 `npm run build` 通過 |
| 執行期依賴稽核 | PASS | `npm audit --omit=dev`：0 vulnerabilities |
| Android 編譯 | 待 Windows | 本工作環境無法下載 Gradle 8.14.3；須依實機驗收文件建置 |
| Android 12 實機 | 待驗收 | 依 `ANDROID_COMPOSE_ACCEPTANCE.md` 1–16 |

## R2 修正

- R1 Windows 建置顯示 Java 目標 21、Kotlin 目標 17 不一致，造成 `compileDebugKotlin` 失敗。
- R2 將 Java `sourceCompatibility`、`targetCompatibility`、Kotlin `jvmTarget` 與 JVM Toolchain 全部固定為 21。
- 防回歸測試會同時檢查 App 與 Capacitor 產生的 Gradle 設定，不允許 JVM 17 殘留。
- Windows 批次檔與 Doctor 改為只接受 JDK 21；R2 仍須在 Windows 完成 Android 編譯與實機驗收。

## R3 修正

- R2 已通過 JVM 目標檢查，後續 Windows 編譯在 `SalaryMateShell.kt` 偵測到不相容的 `weight` 顯式匯入。
- R3 移除 `androidx.compose.foundation.layout.weight` 顯式匯入，讓 `Modifier.weight()` 使用 `RowScope` 公開 API。
- 加入靜態防回歸檢查，禁止重新加入該內部實作匯入；R3 仍須在 Windows 完成 Android 編譯與實機驗收。

## GO／HOLD

- 原始碼可進入本機建置與實機測試。
- 未完成 Windows Android 編譯與 1–16 實機驗收前，狀態為 **HOLD FOR RELEASE**。
- 不得上傳 Production；需要分發驗證時只使用 Google Play Internal testing。
