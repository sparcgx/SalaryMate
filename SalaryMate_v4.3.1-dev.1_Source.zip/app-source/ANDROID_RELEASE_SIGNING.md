# Android Release 簽署設定

v4.1.0 原始碼包不包含任何 keystore 或密碼。金鑰一旦用於正式 App，後續更新必須遵守相同簽署策略。

既有正式 App 若已使用 `%USERPROFILE%\SalaryMateKeys\salarymate-upload.jks`、alias `salarymate-upload`，本機覆蓋安裝測試須沿用同一簽章；不要為 v4.1.0 另建金鑰。若現有 App 是 Play 安裝版，應透過 Play Internal testing 驗證升級，避免 upload key 簽署的本機 APK 與 Play App signing key 不同。

## 建議策略

使用 Google Play App Signing，讓 Google 保管 App signing key；本機建立獨立 upload key，只用來簽署上傳的 AAB。upload key 仍須離線備份，不能放入專案或公開雲端。

## 建立 upload key（僅首次使用）

若 RC2 的 keystore 已存在，跳過本節，不要覆寫或重建。

在私人命令提示字元執行，路徑可自行調整：

    mkdir "%USERPROFILE%\SalaryMateKeys"
    keytool -genkeypair -v -storetype JKS -keystore "%USERPROFILE%\SalaryMateKeys\salarymate-upload.jks" -alias salarymate-upload -keyalg RSA -keysize 4096 -sigalg SHA256withRSA -validity 10000

`keytool` 會互動詢問密碼與憑證資料，不要把密碼寫進命令、聊天或專案檔案。將 keystore 複製至至少一個離線安全位置。

## 推薦：隱藏密碼的單次建置

在專案資料夾開啟 PowerShell，執行：

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\BUILD_SIGNED_ANDROID_WINDOWS.ps1

依序確認 keystore 路徑、alias，並在隱藏輸入中輸入兩組密碼。腳本只把密碼放在這次建置程序的環境中，完成或失敗後即清除。建置批次檔會先驗證 keystore、alias、儲存庫密碼與私鑰密碼；不正確時會在安裝 npm 依賴與啟動 Gradle 前停止。

## 手動設定（備用）

在同一個私人命令提示字元輸入；密碼只留在該視窗的環境中：

    set "SALARYMATE_KEYSTORE_FILE=C:\Users\你的帳號\SalaryMateKeys\salarymate-upload.jks"
    set "SALARYMATE_KEY_ALIAS=salarymate-upload"
    set "SALARYMATE_STORE_PASSWORD=你的密碼"
    set "SALARYMATE_KEY_PASSWORD=你的密碼"
    call BUILD_ANDROID_WINDOWS.cmd

完成後清除並關閉視窗：

    set "SALARYMATE_STORE_PASSWORD="
    set "SALARYMATE_KEY_PASSWORD="

不要使用 `setx` 保存密碼，也不要建立含密碼的 `.properties`、`.cmd` 或文字檔。

## 必須保存

- upload keystore 原檔與至少一份離線備份。
- alias、建立日期、憑證指紋與密碼保管位置。
- Play Console 的 App signing 設定與 upload certificate。

若遺失 upload key，需依 Play Console 流程申請重設；不要以建立新 App ID 作為日常更新方案。
