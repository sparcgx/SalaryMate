@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SalaryMate v4.3.1-dev.1 Connected Device Gate

where node >nul 2>nul
if errorlevel 1 goto missing_node
node scripts\run-formal-device-gate.mjs
set "GATE_RESULT=%ERRORLEVEL%"
echo.
echo See test-results\formal-v4.3.1-dev.1 for result.txt, result.json and test.log.
pause
exit /b %GATE_RESULT%

:missing_node
if not exist "test-results\formal-v4.3.1-dev.1" mkdir "test-results\formal-v4.3.1-dev.1"
set "BOOTSTRAP_LOG=test-results\formal-v4.3.1-dev.1\bootstrap-node-missing-%RANDOM%.txt"
echo FAIL: Node.js is missing. No tests ran. > "%BOOTSTRAP_LOG%"
echo Date: %DATE% %TIME% >> "%BOOTSTRAP_LOG%"
echo FAIL: Node.js is missing. See "%BOOTSTRAP_LOG%".
pause
exit /b 1
