# dev.1 本機驗證紀錄

執行環境：Linux、Node.js 24.19.0。日期：2026-09-23 UTC。
本文件只記載此環境實際執行的項目；未冒充 macOS、iPhone 或 Android 實機結果。

| 項目 | 結果與證據 |
|---|---|
| 完整 npm test | PASS；17 行 PASS 摘要，涵蓋既有核心及新增 iOS 工程／紀錄測試。詳細見 evidence/node-regression.log；不是 17 項實機測試。 |
| Web build | PASS；見 iOS／Android sync 日誌中的 build 步驟。 |
| iOS assets + SPM 接線生成 | PASS；5 個既有外掛與 2 個本機 Swift 外掛的工程引用已檢查。見 evidence/ios-sync.log；未解析遠端 Swift 依賴、未編譯 Swift。 |
| Android sync | PASS；evidence/android-sync.log。 |
| npm audit --omit=dev | PASS；0 個執行期依賴弱點，見 evidence/runtime-audit.json。 |
| Xcode PBX graph、plist、storyboard、scheme | PASS：來源與資源引用、測試相依方向、XML、隔離身分已檢查。 |
| Mac shell／Node 腳本語法 | PASS。 |
| 測試紀錄 PASS／FAIL／INCOMPLETE／NOT_RUN | PASS：自測驗證未測與失敗不得提升成 PASS。 |
| 在 Linux 實際執行 Mac Gate | 預期 FAIL：缺少 macOS；後續 Xcode 與模擬器步驟皆 NOT_RUN。此處是環境阻擋，不是 iPhone 功能失敗。 |
| Linux WebKit 畫面測試 | NOT_RUN：缺少宿主 GUI 依賴，未以此宣稱 UI 驗證通過。 |
| Xcode / Swift / XCTest | NOT_RUN：需 Mac。 |
| iPhone Face ID／另存／分享／離線／升級 | NOT_RUN。 |
| Android Kotlin／APK | NOT_RUN。 |
| Android ↔ iOS 備份互通 | NOT_RUN：需兩平台實機。 |

可重現：npm ci → npm test → npm run ios:sync / npm run android:sync。
Xcode 真正 build 與 XCTest 請在 Mac 執行 RUN_IOS_FOUNDATION_GATE_MAC.command。

原 v4.1.0-R2 ZIP 未修改；Schema 13 的 snapshot 與 backup crypto 核心保持原始位元組。新分支不含個人薪資資料或簽章密鑰。

## 交付包驗證

從 ZIP 真正解壓到獨立資料夾後，重新執行 npm ci、完整 npm test（17 行 PASS 摘要）及 ios:sync，均成功；見 evidence/extracted-regression.log 與 evidence/extracted-ios-sync.log。ZIP CRC 與 SHA-256 已核對，Mac 入口的 Unix 可執行權限已保存在 ZIP。原始碼最長封裝路徑為 114 字元。
