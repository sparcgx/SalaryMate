#!/bin/bash
set -u
cd -- "$(dirname -- "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v node >/dev/null 2>&1; then
  report_dir="test-results/ios-v4.3.1-dev.1/bootstrap-$(date +%Y%m%d-%H%M%S)-$$"
  mkdir -p "$report_dir"
  printf '%s\n' 'FAIL: Node.js is missing. Install Node.js 22.13+ and retry. iOS tests: NOT_RUN.' > "$report_dir/result.txt"
  printf '%s\n' '{"version":"4.3.1-dev.1","status":"FAIL","reason":"Node.js missing","realDevice":"NOT_RUN","manualAcceptance":"NOT_RUN","releaseDecision":"HOLD FOR RELEASE"}' > "$report_dir/result.json"
  cp "$report_dir/result.txt" "$report_dir/test.log"
  cat "$report_dir/result.txt"
  echo "Results: $report_dir"
  exit 1
fi
node scripts/run-ios-gate.mjs --prepare
status=$?
if [ "$status" -eq 0 ]; then open ios/App/App.xcodeproj; fi
printf '\nExit code: %s\n' "$status"
exit "$status"
