# SalaryMate v4.3.0｜Formal Release Evidence

Date: 2026-09-27
Decision: **APPROVED / STABLE**
Source candidate: `v4.3.0-RC.2`

## Verified Android build evidence
The RC.2 Windows signed build completed successfully and generated signed APK/AAB artifacts. Uploaded artifact hashes independently match the build-log hashes:

- APK SHA-256: `732c41190cba640478de3995351e591cce99e0ccf7bfb8bae0dc396856a91dc6`
- AAB SHA-256: `05484379c6650bd14b84824f38d19a639bc458b95ad74c487380b6d373e2c0d6`
- Pre-install identity: v4.1.0 / versionCode 12
- Post-install identity: v4.3.0-RC.2 / versionCode 19

## Manual physical acceptance
User-confirmed physical QA on 2026-09-27:
- Android PDQ-01～09: PASS
- iOS PDQ-01～10: PASS
- Data preservation: PASS
- Backup/restore round-trip: PASS
- Lifecycle / long session: PASS
- Accessibility: PASS
- Cross-company isolation / write safety: PASS
- Golden numeric / historical data: PASS
- Android Final Acceptance: PASS

## Formal promotion conclusion
v4.3.0-RC.2 has satisfied the full physical QA gate and is eligible for formal promotion. The formal source identity is `4.3.0`; Android versionCode remains `19`; iOS build remains `7`; Schema remains `13`.

The signed RC.2 APK/AAB included with this package are **validated evidence artifacts**, not renamed formal binaries. Build new signed formal artifacts from `01_Formal_Source/Source` so their embedded versionName is `4.3.0`.
