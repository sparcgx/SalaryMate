# v4.2.0-dev.1｜iOS Hybrid Foundation

交付狀態：**開發原始碼已實作，等待 Mac／iPhone 驗證**。
發行狀態：**HOLD FOR RELEASE**。

基線：SM_v4.1.0_Formal_Release_Prep_R2_Test_Records_ShortPath.zip
SHA-256：c712738cc96b82eef75816e31ec762b34535f97bd8c5803ad46c66e3221f78cc

## 身分

| 範圍 | 本分支值 |
|---|---|
| 共用核心／套件 | 4.2.0-dev.1 |
| iOS marketingVersion / build | 4.2.0 / 1 |
| iOS Debug Bundle ID | com.salarymate.personal.iosdev |
| iOS Release Bundle ID | com.salarymate.personal |
| Android 分支 versionName / versionCode | 4.2.0-dev.1 / 13 |
| 資料規格 | Schema 13；SQLite snapshots，最近三份 |
| 原 v4.1.0-R2 | 原 ZIP 不修改；正式驗收仍 HOLD |

## 已實作

- Capacitor 8.5.2 iOS 工程及 Swift Package Manager，依 npm lock 還原既有外掛。
- DeviceSecurity：Face ID／Touch ID／裝置密碼驗證、鎖定設定、防重入及取消處理。
- BackupFile：原生 UIDocumentPicker 另存、背景 I/O、30 MB 限制、實際檔名及 SHA-256 讀回核對、暫存清理。
- 原資料核心：同一 SnapshotRepository、原子交易、Schema 13 與加密 .salarymate 格式；不增加薪資、考勤或加班資料表。
- iOS Scene 生命週期與背景遮蔽，移除 iOS 的 Android 返回／離開呼叫。
- 鎖定視窗置於最上層，保護已開啟的備份／編輯視窗。
- Mac 準備與模擬器測試入口、逐步結果與失敗日誌、XCTest 持久化案例、iPhone 人工驗收表。

## 尚待環境驗證

- Swift 套件解析、Xcode 編譯、模擬器 XCTest：此 Linux 環境未執行。
- iPhone 安裝、Face ID、另存／分享、生命週期、離線與覆蓋更新：未測。
- Android Kotlin／APK 重建：此環境未執行。
- 真實 Android ↔ iOS 備份互通：未測；dev.2 展開完整矩陣。
- SwiftUI 原生頁面、雲端同步、正式 IPA、TestFlight／商店發布：未交付。

只有對應的實際證據可更新上述狀態。沒有產生任何簽章、憑證或使用者密鑰。
