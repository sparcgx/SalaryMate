# v4.3.0-dev.1｜Full Regression & Development Freeze Gate

## Decision

**DEVELOPMENT SOURCE FREEZE: PASS**

**FULL PLATFORM BUILD / DEVICE GATE: PENDING_ENVIRONMENT**

**RC / Stable promotion: NOT AUTHORIZED**

The source line is frozen against new feature development. Remaining work is platform build/device verification and later PAX / RI / RC phases, not new CM feature scope.

## Identity

- Product: `4.3.0-dev.1`
- Release target: `4.3.0`
- Schema: `13`
- Android package: `com.salarymate.personal`
- Android versionCode: `14`
- iOS MARKETING_VERSION: `4.3.0`
- iOS build: `2`
- Version Drift: `0`

## CM Gates

- CM-01 Unified Version Foundation: `PASS_TARGETED`
- CM-02 Company Management Shell: `IMPLEMENTATION_REGRESSION_PASS`
- CM-03 Simplified Salary Rules: `IMPLEMENTATION_REGRESSION_PASS`
- CM-04 Advanced Company Rules: `IMPLEMENTATION_REGRESSION_PASS`
- CM-05 Company Workflow / Cross-Platform UX: `IMPLEMENTATION_REGRESSION_PASS`
- CM-06 Full Source Regression / Freeze: `PASS`

## Executable Regression

- Existing executable script gates: `21 / 21 PASS`
- CM-06 freeze contract gate: `PASS`
- Product FAIL: `0`
- Runtime smoke is executed through `scripts/regression.mjs` against extracted source and passed.

## Frozen Core

- NativePayrollMath: `SAME` vs CM-04 R1
- Storage: `SAME` vs CM-04 R1
- Snapshot Store: `SAME` vs CM-04 R1
- Backup Crypto: `SAME` vs CM-04 R1
- Native Backup: `SAME` vs CM-04 R1
- Tax boundary: `86,000 → 0`, `86,001 → 0`, `86,002 → 4,300`
- OT multipliers: `1 / 1.34 / 1.67 / 2 / 2.67`, Lunar New Year `2.5`
- Year-End runtime golden display: `$153,900`
- Second Company / Salary / Advanced Rule Store: `0`

## Historical OT

Workstation historical import evidence remains preserved:

- Legacy 2021–2024: `914`
- 2025/2026 import: `459`
- Combined historical OT contract: `1,373`
- Combined compound identities: `1,373 unique`

The CM-06 source archive does not embed the user's live database, so physical post-upgrade count verification remains a device/upgrade acceptance item. No claim of current-device physical count is made here.

## Backup / Snapshot

- SQLite transaction / rollback / fail-closed regression: `PASS`
- Snapshot retention: `3`
- AES-GCM backup round-trip / tamper / wrong-password rejection: `PASS`
- Native Save As / extension / encryption verification / lock release: `PASS`
- Restore/import validation: `PASS`

## Cross-company / Workflow Safety

- Single Current Company context: `PASS`
- Module-local operational company selectors: `0`
- Silent first-company fallback: `0`
- Payroll duplicate scope: `companyId + payrollMonth`
- Payroll create flow: `月份 → 本月資料 → 確認`
- Dirty Guard / scoped draft reset: `PASS`

## Environment-Pending Gates

### Production Web Build
`PENDING_ENVIRONMENT`

The clean source intentionally excludes `node_modules`. Reinstall from `package-lock.json` could not complete in the current execution container; therefore `esbuild` is unavailable here. This is not recorded as a product failure.

### Android Gradle / Physical Device
`PENDING_ENVIRONMENT`

Current execution container has no Android SDK / `ANDROID_HOME` / `ANDROID_SDK_ROOT`. JDK 21 and Kotlin compiler are present; source/static Android gates passed.

### iOS Foundation Parser / Build
`PENDING_ENVIRONMENT`

The clean source lockfile includes the Capacitor CLI dependency on `xcode`, but dependency installation could not complete in the current execution container. `ios-gate-test.mjs` passed; full Xcode project parser/build remains pending on the Mac build environment.

## Freeze Rule

After this gate:

- No new CM feature work on `v4.3.0-dev.1`.
- Only release-blocking corrections may modify the frozen source.
- Any source change invalidates the CM-06 source hash and requires affected regression plus a new freeze artifact.
- PAX / RI / RC / Stable remain pending.
