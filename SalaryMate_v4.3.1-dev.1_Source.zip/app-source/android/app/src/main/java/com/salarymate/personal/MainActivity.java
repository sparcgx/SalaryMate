package com.salarymate.personal;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends BridgeActivity {
    public static final String EXTRA_TAB = "salarymate_tab";
    public static final String EXTRA_ACTION = "salarymate_action";

    private static final int ROUTE_RETRY_LIMIT = 16;
    private static final Set<String> ALLOWED_TABS = new HashSet<>(Arrays.asList(
        "dashboard", "records", "overtime", "hourly", "tax", "companies"
    ));
    private static final Set<String> ALLOWED_ACTIONS = new HashSet<>(Arrays.asList(
        "add-record", "add-overtime", "add-leave", "manage-companies",
        "open-interface-settings", "data-health", "company-full-settings", "company-salary-rules", "company-advanced-rules"
    ));

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(DeviceSecurityPlugin.class);
        registerPlugin(BackupFilePlugin.class);
        super.onCreate(savedInstanceState);
        routeFromComposeShell(getIntent(), 0);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        routeFromComposeShell(intent, 0);
    }

    private void routeFromComposeShell(Intent intent, int attempt) {
        if (intent == null || bridge == null || bridge.getWebView() == null) return;

        String requestedTab = intent.getStringExtra(EXTRA_TAB);
        String requestedAction = intent.getStringExtra(EXTRA_ACTION);
        String tab = ALLOWED_TABS.contains(requestedTab) ? requestedTab : null;
        String action = ALLOWED_ACTIONS.contains(requestedAction) ? requestedAction : null;
        if (tab == null && action == null) return;

        WebView webView = bridge.getWebView();
        String tabJson = tab == null ? "null" : JSONObject.quote(tab);
        String actionJson = action == null ? "null" : JSONObject.quote(action);
        String script = "(function(){"
            + "const tab=" + tabJson + ";const action=" + actionJson + ";"
            + "const tabButton=tab?document.querySelector('[data-tab=\"'+tab+'\"]'):null;"
            + "if(tab&&!tabButton)return 'retry';"
            + "if(tabButton)tabButton.click();"
            + "const attendanceTab=action==='add-leave'?'leave':(action==='add-overtime'?'overtime':null);"
            + "const attendanceButton=attendanceTab?document.querySelector('[data-attendance-tab=\"'+attendanceTab+'\"]'):null;"
            + "if(attendanceTab&&!attendanceButton)return 'retry';"
            + "if(attendanceButton)attendanceButton.click();"
            + "const actionButton=action?document.querySelector('[data-action=\"'+action+'\"]'):null;"
            + "if(action&&!actionButton)return 'retry';"
            + "if(actionButton)actionButton.click();"
            + "return 'ok';"
            + "})()";

        webView.postDelayed(() -> webView.evaluateJavascript(script, result -> {
            if (!"\"ok\"".equals(result) && attempt < ROUTE_RETRY_LIMIT) {
                routeFromComposeShell(intent, attempt + 1);
            }
        }), attempt == 0 ? 250L : 180L);
    }
}
