package com.salarymate.personal;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

@CapacitorPlugin(name = "BackupFile")
public class BackupFilePlugin extends Plugin {
    private static final int MAX_BACKUP_BYTES = 30 * 1024 * 1024;
    private static final String MIME_TYPE = "application/octet-stream";

    @PluginMethod
    public void save(PluginCall call) {
        String fileName = call.getString("fileName");
        String data = call.getString("data");
        if (!isSafeBackupName(fileName)) {
            call.reject("備份檔名必須以 .salarymate 結尾", "SAVE_EXTENSION_CHANGED");
            return;
        }
        if (data == null || data.isEmpty()) {
            call.reject("備份內容為空", "SAVE_FAILED");
            return;
        }
        if (data.getBytes(StandardCharsets.UTF_8).length > MAX_BACKUP_BYTES) {
            call.reject("備份超過 30 MB 上限", "SAVE_FAILED");
            return;
        }

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(MIME_TYPE);
        intent.putExtra(Intent.EXTRA_TITLE, fileName);
        startActivityForResult(call, intent, "saveResult");
    }

    @ActivityCallback
    private void saveResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            call.reject("使用者取消另存備份", "SAVE_CANCELLED");
            return;
        }

        Uri uri = result.getData().getData();
        if (uri == null) {
            call.reject("儲存位置無效", "SAVE_FAILED");
            return;
        }

        String savedName = queryDisplayName(uri);
        if (!isSafeBackupName(savedName)) {
            deleteIncomplete(uri);
            call.reject("儲存位置未保留 .salarymate 副檔名", "SAVE_EXTENSION_CHANGED");
            return;
        }

        String data = call.getString("data");
        if (data == null) {
            deleteIncomplete(uri);
            call.reject("備份內容遺失", "SAVE_FAILED");
            return;
        }

        byte[] expected = data.getBytes(StandardCharsets.UTF_8);
        try {
            writeAndVerify(uri, expected);
            JSObject response = new JSObject();
            response.put("fileName", savedName);
            call.resolve(response);
        } catch (Exception error) {
            deleteIncomplete(uri);
            call.reject("備份未能完整寫入或驗證", "SAVE_FAILED", error);
        }
    }

    private boolean isSafeBackupName(String fileName) {
        if (fileName == null || fileName.length() > 180 || fileName.contains("/") || fileName.contains("\\")) return false;
        return fileName.toLowerCase(Locale.ROOT).endsWith(".salarymate");
    }

    private String queryDisplayName(Uri uri) {
        ContentResolver resolver = getContext().getContentResolver();
        try (Cursor cursor = resolver.query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String value = cursor.getString(index);
                    if (value != null && !value.isEmpty()) return value;
                }
            }
        } catch (RuntimeException ignored) {
            // Fail closed below if a provider cannot report the actual saved filename.
        }
        return null;
    }

    private void writeAndVerify(Uri uri, byte[] expected) throws IOException, NoSuchAlgorithmException {
        ContentResolver resolver = getContext().getContentResolver();
        try (OutputStream output = resolver.openOutputStream(uri, "wt")) {
            if (output == null) throw new IOException("No output stream");
            output.write(expected);
            output.flush();
        }

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        long actualLength = 0;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) throw new IOException("No input stream");
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                actualLength += count;
                if (actualLength > MAX_BACKUP_BYTES) throw new IOException("Saved backup too large");
                digest.update(buffer, 0, count);
            }
        }

        byte[] expectedDigest = MessageDigest.getInstance("SHA-256").digest(expected);
        if (actualLength != expected.length || !MessageDigest.isEqual(expectedDigest, digest.digest())) {
            throw new IOException("Saved backup verification mismatch");
        }
    }

    private void deleteIncomplete(Uri uri) {
        try {
            DocumentsContract.deleteDocument(getContext().getContentResolver(), uri);
        } catch (Exception ignored) {
            // The provider may not support deletion; never hide the original save failure.
        }
    }
}
