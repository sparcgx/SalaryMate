# SalaryMate v4.3.0-dev.3｜Release Integration & Real-Device Hardening

## Current decision

- RELEASE INTEGRATION SOURCE GATE: **PASS**
- Source regression: **35 PASS lines / 0 product FAIL**
- Production build: **PENDING_ENVIRONMENT**
- Android real device: **PENDING_DEVICE_QA**
- iOS real device: **PENDING_DEVICE_QA**
- Upgrade / Data Preservation: **PENDING_DEVICE_QA**
- Backup / Restore Physical Round-trip: **PENDING_DEVICE_QA**
- Long-session / Lifecycle: **PENDING_DEVICE_QA**
- RC / Stable promotion: **NOT AUTHORIZED**

## Frozen invariants
- Schema 13
- NativePayrollMath / Repository / Storage / Snapshot / Backup formats unchanged
- Native Backup changes only in product-version binding
- Tax boundary, OT multipliers and Year-End Golden unchanged
- PAX-06 dev.2 source freeze remains the functional baseline

## Platform environment observed here
- JDK 21: PASS
- esbuild: unavailable
- Android SDK / ADB: unavailable
- Xcode / xcode npm module: unavailable
- ios-gate-test: PASS

## Promotion rule
Only actual build/device evidence may change PENDING items to PASS. Source integration PASS does not authorize RC or Stable promotion.
