# SalaryMate v4.3.0｜Formal Release & Stable Freeze Gate

Release date: 2026-09-27
Status: **PASS / STABLE FREEZE AUTHORIZED**
Promotion source: **v4.3.0-RC.2**

## Formal identity
- Product version: `4.3.0`
- Android package: `com.salarymate.personal`
- Android versionCode: `19`
- Android versionName: `4.3.0`
- iOS MARKETING_VERSION: `4.3.0`
- iOS build: `7`
- Schema: `13`

## Physical QA inherited from RC.2
- Android PDQ-01～09: PASS
- iOS PDQ-01～10: PASS
- In-place data preservation: PASS
- `.salarymate` backup → modify → restore → original state: PASS
- Lifecycle / long session: PASS
- Accessibility / touch / VoiceOver / Dynamic Type / keyboard: PASS
- Cross-company isolation and write safety: PASS
- Golden numeric / historical data: PASS

## Zero-tolerance conditions
- Wrong-company Write = 0
- Context Leakage = 0
- Stale Company Exposure = 0
- Duplicate Commit = 0
- Data Loss = 0

## Frozen invariants
- Schema 13
- Historical OT = 1,373
- Snapshot retention = 3
- Withholding golden: 86,000→0; 86,001→0; 86,002→4,300
- OT multipliers: 1 / 1.34 / 1.67 / 2 / 2.67; Spring Festival 2.5
- Year-End Runtime Golden = 153,900
- No second Attendance / OT / Addition / Payslip / Company store
- NativeSalaryMateRepository, NativePayrollMath, storage and backup crypto behavior remain unchanged from RC.2.

## Promotion rule
This promotion changes release identity and stable-freeze metadata only. Functional changes must start from a new post-freeze branch/version. v4.3.0 Stable is immutable except for explicit Hotfix/Recovery governance.
