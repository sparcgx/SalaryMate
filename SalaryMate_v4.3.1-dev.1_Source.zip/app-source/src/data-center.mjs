import { snapshotSummary, validateSnapshot } from './snapshot-store.mjs';
import { inspectBackupCandidate } from './backup-import.mjs';

const MAX_IMPORT_BYTES = 30 * 1024 * 1024;

function friendlyError(error) {
  const messages = {
    PASSWORD_REQUIRED: '請輸入備份密碼。',
    PASSWORD_TOO_SHORT: '新備份密碼至少需要 12 個字元。',
    AUTH_FAILED: '密碼錯誤，或備份檔案已損壞。原資料未變更。',
    INVALID_FORMAT: '備份格式錯誤或檔案已損壞。原資料未變更。',
    UNSUPPORTED_VERSION: '此加密備份版本尚未支援。',
    CRYPTO_UNAVAILABLE: '此裝置無法建立安全加密備份。',
    AUTH_CANCELLED: '裝置驗證已取消，設定未變更。',
    AUTH_UNAVAILABLE: '請先在裝置設定啟用螢幕鎖或生物辨識。',
    SAVE_CANCELLED: '已取消另存備份，原資料未變更。',
    SAVE_UNAVAILABLE: '此裝置無法開啟安全另存功能，請改用系統分享。',
    SAVE_EXTENSION_CHANGED: '儲存位置未保留 .salarymate 副檔名，請重新另存並保留完整檔名。',
    SAVE_FAILED: '備份未能完整寫入，請更換儲存位置後重試。'
  };
  if (messages[error?.code]) return messages[error.code];
  const detail = String(error?.message || '');
  return /[\u3400-\u9fff]/.test(detail) ? detail : '操作未完成，原資料未變更。請確認檔案後重試。';
}

function createPasswordForm(panel, { title, confirmPassword, submitLabel, onSubmit }) {
  panel.replaceChildren();
  const form = document.createElement('form');
  const heading = document.createElement('h4');
  heading.textContent = title;
  const passwordLabel = document.createElement('label');
  passwordLabel.textContent = confirmPassword ? '設定備份密碼（至少 12 個字元）' : '輸入此備份的密碼';
  const password = document.createElement('input');
  password.className = 'field';
  password.type = 'password';
  password.required = true;
  password.autocomplete = confirmPassword ? 'new-password' : 'current-password';
  passwordLabel.append(password);
  form.append(heading, passwordLabel);

  let confirmation;
  if (confirmPassword) {
    const confirmationLabel = document.createElement('label');
    confirmationLabel.textContent = '再次輸入備份密碼';
    confirmation = document.createElement('input');
    confirmation.className = 'field';
    confirmation.type = 'password';
    confirmation.required = true;
    confirmation.autocomplete = 'new-password';
    confirmationLabel.append(confirmation);
    form.append(confirmationLabel);
  }

  const error = document.createElement('p');
  error.setAttribute('role', 'alert');
  const actions = document.createElement('div');
  actions.className = 'form-actions';
  const cancel = document.createElement('button');
  cancel.type = 'button';
  cancel.className = 'btn';
  cancel.textContent = '取消';
  cancel.addEventListener('click', () => {
    password.value = '';
    if (confirmation) confirmation.value = '';
    panel.replaceChildren();
  });
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.className = 'btn btn-primary';
  submit.textContent = submitLabel;
  actions.append(cancel, submit);
  form.append(error, actions);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    error.textContent = '';
    if (confirmation && password.value !== confirmation.value) {
      error.textContent = '兩次輸入的備份密碼不一致。';
      return;
    }
    submit.disabled = true;
    cancel.disabled = true;
    try {
      await onSubmit(password.value);
      password.value = '';
      if (confirmation) confirmation.value = '';
      panel.replaceChildren();
    } catch (caught) {
      error.textContent = friendlyError(caught);
      password.select();
    } finally {
      submit.disabled = false;
      cancel.disabled = false;
    }
  });
  panel.append(form);
  password.focus({ preventScroll: true });
}

export function openDataCenter({ repository, backup, app, security, nativeCopy, recovery = false }) {
  if (document.querySelector('dialog.data-center')) return;
  const dialog = document.createElement('dialog');
  dialog.className = 'data-center';
  const heading = document.createElement('h2');
  heading.textContent = recovery ? '保護快照救援' : '資料匯入／匯出';
  const note = document.createElement('p');
  note.textContent = '匯出 .salarymate 檔案可供日後匯入；網站與其他安裝身分不會自動同步。匯入前會核對內容，確認後才取代資料。';
  const privacy = document.createElement('p');
  privacy.textContent = '一般匯出不加密，請將檔案存於可信任位置。如主動選擇密碼加密，密碼不會儲存在 App，也無法代為找回。App 內保護快照最多三份。';
  const privacyDetails = document.createElement('details');
  const privacySummary = document.createElement('summary');
  privacySummary.textContent = '隱私與資料處理說明';
  const privacyCopy = document.createElement('p');
  privacyCopy.textContent = '薪資資料只在此裝置本機處理；App 不建立帳號、不含廣告或分析追蹤，也不會自動上傳資料。只有您主動另存、分享或匯入備份時，資料才會交給所選的檔案或分享服務。';
  privacyDetails.append(privacySummary, privacyCopy);
  const message = document.createElement('p');
  message.className = 'data-center-message';
  message.setAttribute('role', 'status');
  const list = document.createElement('div');
  const passwordPanel = document.createElement('div');
  passwordPanel.className = 'password-panel';
  const fileActions = document.createElement('div');

  const button = (label, fn, className = 'btn') => {
    const node = document.createElement('button');
    node.type = 'button';
    node.className = className;
    node.textContent = label;
    node.addEventListener('click', async () => {
      node.disabled = true;
      try { await fn(); }
      catch (error) { message.textContent = friendlyError(error); }
      finally { node.disabled = false; }
    });
    return node;
  };
  const close = () => { if (dialog.open) dialog.close(); else dialog.remove(); };
  const apply = async payload => {
    validateSnapshot(payload);
    if (!recovery) {
      if (document.querySelector('#appDialog')?.open) throw new Error('請先關閉編輯視窗');
      await window.SalaryMateStorage.flush?.();
      close();
      await app.importPayload(payload);
    } else {
      if (!window.confirm(`還原會取代目前使用的資料。\n${snapshotSummary(payload)}\n確認使用此備份？`)) return;
      await repository.write(payload);
      if (await repository.read() !== payload) throw new Error('還原後驗證失敗');
      window.location.reload();
    }
  };
  const newPassword = (title, payload, mode = 'save') => createPasswordForm(passwordPanel, {
    title,
    confirmPassword: true,
    submitLabel: mode === 'save' ? '加密並選擇儲存位置' : '建立並開啟系統分享',
    onSubmit: async password => {
      await window.SalaryMateStorage.flush?.();
      if (mode === 'save') {
        const result = await backup.saveEncrypted(payload, password);
        message.textContent = `已安全儲存「${result.fileName}」，並完成寫入驗證。`;
      } else {
        await backup.shareEncrypted(payload, password);
        message.textContent = '分享視窗已關閉；接收端可能改寫副檔名，重要備份請優先使用「另存 .salarymate」。';
      }
    }
  });

  dialog.append(heading, note, privacy, privacyDetails);

  if (security && !recovery) {
    const securityGroup = document.createElement('section');
    securityGroup.className = 'data-center-group';
    const securityTitle = document.createElement('h3');
    securityTitle.textContent = 'App 存取保護';
    const securityNote = document.createElement('p');
    securityNote.textContent = `${nativeCopy?.lock ?? 'App 鎖定使用裝置驗證。'} ${nativeCopy?.protection ?? '螢幕保護會阻擋截圖、錄影與最近使用畫面預覽。'}`;
    const settings = document.createElement('div');
    const renderSecurity = () => {
      const current = security.currentStatus();
      settings.replaceChildren();
      const row = (title, description, action) => {
        const container = document.createElement('div');
        container.className = 'security-setting';
        const copy = document.createElement('div');
        copy.className = 'security-setting-copy';
        const strong = document.createElement('strong');
        strong.textContent = title;
        const detail = document.createElement('span');
        detail.textContent = description;
        copy.append(strong, detail);
        container.append(copy, action);
        return container;
      };
      const lockAction = button(current.lockEnabled ? '停用' : '啟用', async () => {
        const result = await security.configureLock(!current.lockEnabled);
        message.textContent = result.lockEnabled ? '已啟用 App 鎖定。' : '已停用 App 鎖定。';
        renderSecurity();
      });
      settings.append(row(
        `App 鎖定：${current.lockEnabled ? '已啟用' : '未啟用'}`,
        current.available ? '支援生物辨識或裝置螢幕鎖' : '請先設定裝置螢幕鎖',
        lockAction
      ));
      const screenAction = button(current.screenProtectionEnabled ? '停用' : '啟用', async () => {
        const result = await security.setScreenProtection(!current.screenProtectionEnabled);
        message.textContent = result.screenProtectionEnabled
          ? (result.screenProtectionActive ? `已啟用${nativeCopy?.protectionName ?? '螢幕與最近使用畫面保護'}。` : '設定已儲存，但此裝置未能啟動畫面保護。')
          : '已停用畫面保護。';
        renderSecurity();
      });
      settings.append(row(
        `${nativeCopy?.protectionName ?? '螢幕保護'}：${current.screenProtectionEnabled ? '已啟用' : '未啟用'}`,
        current.screenProtectionEnabled && !current.screenProtectionActive ? '目前未能確認保護已生效' : (nativeCopy?.protection ?? '防止截圖、錄影與背景預覽'),
        screenAction
      ));
      if (current.lockEnabled) settings.append(row(
        '立即測試鎖定',
        '關閉此視窗後立即要求裝置驗證',
        button('立即鎖定', async () => { close(); await security.lockNow(); })
      ));
    };
    renderSecurity();
    securityGroup.append(securityTitle, securityNote, settings);
    dialog.append(securityGroup);
  }

  if (app) {
    const backupGroup = document.createElement('section');
    backupGroup.className = 'data-center-group';
    const title = document.createElement('h3');
    title.textContent = '匯出資料';
    const detail = document.createElement('p');
    detail.textContent = '預設匯出不設定密碼；檔案含薪資資料，請存於可信任位置。需要密碼時可另外選擇加密匯出。';
    const saveButton = button('匯出 .salarymate', async () => {
      if (document.querySelector('#appDialog')?.open) throw new Error('請先關閉編輯視窗');
      await window.SalaryMateStorage.flush?.();
      const result = await backup.savePlain(app.exportPayload());
      message.textContent = `已建立「${result.fileName}」；請確認檔案已存至選定位置。`;
    }, 'btn btn-primary');
    const shareButton = button('選用密碼加密匯出', () => {
      if (document.querySelector('#appDialog')?.open) throw new Error('請先關閉編輯視窗');
      newPassword('設定密碼並匯出', app.exportPayload(), 'save');
    });
    backupGroup.append(title, detail, saveButton, shareButton);
    dialog.append(backupGroup);
  }

  const importGroup = document.createElement('section');
  importGroup.className = 'data-center-group';
  const importTitle = document.createElement('h3');
  importTitle.textContent = '匯入資料';
  const pickerLabel = document.createElement('label');
  pickerLabel.textContent = '選擇 .salarymate、BIN、.file 或舊版 JSON；加密檔才會要求原密碼：';
  const picker = document.createElement('input');
  picker.className = 'field';
  picker.type = 'file';
  picker.accept = '*/*';
  pickerLabel.append(picker);
  picker.addEventListener('change', async () => {
    const file = picker.files?.[0];
    fileActions.replaceChildren();
    passwordPanel.replaceChildren();
    if (!file) return;
    try {
      if (file.size > MAX_IMPORT_BYTES) throw new Error('檔案超過 30 MB 上限');
      const text = await file.text();
      const candidate = inspectBackupCandidate(file.name, text, backup);
      if (candidate.kind === 'encrypted') {
        message.textContent = `已讀取加密備份「${candidate.fileName}」，尚未解密或還原。`;
        createPasswordForm(passwordPanel, {
          title: '解鎖這份加密備份',
          confirmPassword: false,
          submitLabel: '解密並核對內容',
          onSubmit: async password => {
            const payload = await backup.decrypt(text, password);
            const summary = snapshotSummary(payload);
            message.textContent = `解密成功：${summary}。尚未還原。`;
            fileActions.replaceChildren(button('確認此備份／繼續還原', () => apply(payload), 'btn btn-primary'));
          }
        });
      } else {
        message.textContent = `已讀取未加密資料「${candidate.fileName}」：${candidate.summary}。尚未匯入。`;
        fileActions.replaceChildren(button('確認此檔案／繼續還原', () => apply(text), 'btn btn-primary'));
      }
    } catch (error) {
      message.textContent = friendlyError(error);
    } finally { picker.value = ''; }
  });
  importGroup.append(importTitle, pickerLabel, fileActions);
  dialog.append(importGroup);

  const snapshotsGroup = document.createElement('section');
  snapshotsGroup.className = 'data-center-group';
  const snapshotsTitle = document.createElement('h3');
  snapshotsTitle.textContent = 'App 內保護快照';
  const snapshotsNote = document.createElement('p');
  snapshotsNote.textContent = '查看最近三份已完成寫入的資料；損壞快照只會標示，不會嘗試載入。';
  snapshotsGroup.append(snapshotsTitle, snapshotsNote, button('查看最近三份保護快照', async () => {
    if (!recovery) await window.SalaryMateStorage.flush?.();
    const rows = await repository.list();
    list.replaceChildren();
    if (!rows.length) list.textContent = '目前沒有保護快照。';
    for (const row of rows) {
      const card = document.createElement('section');
      const label = document.createElement('p');
      label.textContent = `${row.created_at} — ${row.valid ? row.summary : '損壞或不支援，無法還原'}`;
      card.append(label);
      if (row.valid) {
        card.append(button('選擇這份快照', () => apply(row.payload)));
        if (app) {
          card.append(button('以密碼加密後另存', () => newPassword('加密並另存此保護快照', row.payload, 'save')));
          card.append(button('以密碼加密後分享', () => newPassword('加密分享此保護快照', row.payload, 'share')));
        }
      }
      list.append(card);
    }
  }), list);
  if (repository) dialog.append(snapshotsGroup);
  dialog.append(passwordPanel, message, button('稍後／關閉', close));
  dialog.addEventListener('cancel', event => { event.preventDefault(); close(); });
  dialog.addEventListener('close', () => dialog.remove(), { once: true });
  document.body.append(dialog);
  dialog.showModal();
}
