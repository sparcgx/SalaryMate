import { Capacitor, registerPlugin } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection } from '@capacitor-community/sqlite';
import { SnapshotRepository, createNativeStore } from './snapshot-store.mjs';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';
import { PrivacyScreen } from '@capacitor/privacy-screen';
import { createBackupService } from './native-backup.mjs';
import { openDataCenter } from './data-center.mjs';
import { createSecurityController, createSecurityCoverView } from './native-security.mjs';
import { platformPrivacyScreen, platformCopy, platformLifecycle } from './native-platform.mjs';

const platform = Capacitor.getPlatform();
document.documentElement.dataset.platform = platform;
const nativeCopy = platformCopy(platform);
if (platform === 'ios') document.querySelector('[data-security-leave]').hidden = true;

let repository;
let security;
const DeviceSecurity = registerPlugin('DeviceSecurity');
const BackupFile = registerPlugin('BackupFile');
const backup = createBackupService(
  Filesystem,
  Share,
  Directory.Cache,
  Encoding.UTF8,
  '4.3.1-dev.1',
  undefined,
  BackupFile
);

const status = document.createElement('div');
status.className = 'storage-status';
status.setAttribute('role', 'status');
status.textContent = '正在讀取本機資料…';
document.body.prepend(status);
function report(state) {
  status.textContent = ({ pending: '正在儲存，請勿關閉 App…', saved: '已儲存至本機資料庫',
    failed: '儲存失敗：變更尚未保存。請先備份全部資料，勿繼續修改或直接關閉 App。' })[state];
  status.dataset.state = state;
}
try {
  if (Capacitor.isNativePlatform()) {
    security = createSecurityController({
      appPlugin: platformLifecycle(platform, App, DeviceSecurity),
      deviceSecurity: DeviceSecurity,
      privacyScreen: platformPrivacyScreen(platform, PrivacyScreen, DeviceSecurity),
      view: createSecurityCoverView(document.querySelector('#securityCover'))
    });
    await security.startGate();
    const sqlite = new SQLiteConnection(CapacitorSQLite);
    const db = await sqlite.createConnection('salarymate', false, 'no-encryption', 1, false);
    await db.open();
    repository = new SnapshotRepository(db);
    window.SalaryMateStorage = await createNativeStore(repository, localStorage, report);
    window.SalaryMateNative = {
      openDataCenter: () => openDataCenter({ repository, backup, app: window.SalaryMateData, security, nativeCopy })
    };
    report('saved');
  } else {
    window.SalaryMateStorage = Object.freeze({
      getItem: key => localStorage.getItem(key),
      setItem: (key, value) => localStorage.setItem(key, value),
      removeItem: key => localStorage.removeItem(key)
    });
    status.textContent = 'Web 開發預覽：資料保存在此瀏覽器，與手機 App 不同步';
  }
  const script = document.createElement('script');
  script.src = './app.js';
  script.onload = async () => {
    try {
      if (!repository) {
        const browserSaver = {
          async save({ fileName, data, mimeType }) {
            const url = URL.createObjectURL(new Blob([data], { type: mimeType }));
            try {
              const link = document.createElement('a');
              link.href = url;
              link.download = fileName;
              document.body.append(link);
              link.click();
              link.remove();
            } finally { setTimeout(() => URL.revokeObjectURL(url), 60000); }
            return { fileName };
          }
        };
        const browserBackup = createBackupService(null, null, null, null, '4.3.1-dev.1', undefined, browserSaver);
        document.querySelector('[data-action="export-json"]')?.setAttribute('hidden', '');
        document.querySelector('#jsonImport')?.closest('label')?.setAttribute('hidden', '');
        const entry = document.createElement('button');
        entry.type = 'button';
        entry.textContent = '資料匯入／匯出';
        entry.onclick = () => openDataCenter({ repository: null, backup: browserBackup, app: window.SalaryMateData });
        document.querySelector('#dataMenu .menu-section').append(entry);
      }
      if (repository) {
        const rawExport = document.querySelector('[data-action="export-json"]');
        if (rawExport) rawExport.hidden = true;
        const rawImport = document.querySelector('#jsonImport')?.closest('label');
        if (rawImport) rawImport.hidden = true;
        const entry = document.createElement('button');
        entry.type = 'button'; entry.textContent = '資料匯入／匯出';
        entry.onclick = () => {
          document.querySelector('#dataMenu').hidden = true;
          document.querySelector('#dataMenuButton').setAttribute('aria-expanded', 'false');
          window.SalaryMateNative.openDataCenter();
        };
        document.querySelector('#dataMenu .menu-section').append(entry);
        await security.startLifecycle();
        if (platform === 'android') await App.addListener('backButton', async () => {
          if (security.isCovered()) return App.exitApp();
          const center = document.querySelector('dialog.data-center[open]');
          if (center) { center.close(); return; }
          if (window.SalaryMateData?.handleBackButton?.()) return;
          await App.exitApp();
        });
      }
      if (repository && !window.SalaryMateStorage.getItem('salarymate_v310_state')) window.SalaryMateNative.openDataCenter();
    } catch {
      status.textContent = '安全監聽無法啟動，已停止顯示薪資資料。請保留 App 並重新啟動。';
      status.dataset.state = 'failed';
      security?.failClosed();
    }
  };
  document.body.appendChild(script);
} catch {
  status.textContent = '無法安全開啟本機資料，已停止載入，未清除或覆寫原資料。請保留 App，勿解除安裝。';
  status.dataset.state = 'failed';
  security?.failClosed();
  if (repository) {
    const recover = document.createElement('button');
    recover.className = 'btn'; recover.textContent = '選擇保護快照或 JSON 救援';
    recover.onclick = () => openDataCenter({ repository, backup, recovery: true });
    status.append(recover);
  }
}
