import { validateSnapshot } from './snapshot-store.mjs';
import { decryptBackup, encryptBackup, inspectEncryptedBackup, isEncryptedBackup } from './backup-crypto.mjs';

// Dependencies are injected so disk, crypto and share-sheet failures remain testable without a phone.
export function createBackupService(
  filesystem,
  share,
  directory,
  encoding,
  version = '4.3.1-dev.1',
  crypto = { encryptBackup, decryptBackup, inspectEncryptedBackup, isEncryptedBackup },
  fileSaver
) {
  let busy = false;
  const fileName = () => `SalaryMate_v${version}_${new Date().toISOString().slice(0, 10)}.salarymate`;
  const prepare = async (payload, password) => {
    validateSnapshot(payload);
    const encrypted = await crypto.encryptBackup(payload, password);
    const verifiedPayload = await crypto.decryptBackup(encrypted, password);
    if (verifiedPayload !== payload) throw new Error('備份解密驗證失敗');
    return encrypted;
  };
  const exclusive = async action => {
    if (busy) throw new Error('備份正在進行中');
    busy = true;
    try { return await action(); }
    finally { busy = false; }
  };
  return Object.freeze({
    isEncrypted: crypto.isEncryptedBackup,
    inspect: crypto.inspectEncryptedBackup,
    async decrypt(text, password) {
      const payload = await crypto.decryptBackup(text, password);
      validateSnapshot(payload);
      return payload;
    },
    async savePlain(payload) {
      return exclusive(async () => {
        if (!fileSaver?.save) {
          const error = new Error('此裝置無法開啟另存功能');
          error.code = 'SAVE_UNAVAILABLE';
          throw error;
        }
        validateSnapshot(payload);
        const suggestedName = fileName();
        const result = await fileSaver.save({ fileName: suggestedName, data: payload, mimeType: 'application/octet-stream' });
        const savedName = String(result?.fileName || suggestedName);
        if (!savedName.toLowerCase().endsWith('.salarymate')) {
          const error = new Error('儲存位置未保留 .salarymate 副檔名');
          error.code = 'SAVE_EXTENSION_CHANGED';
          throw error;
        }
        return { fileName: savedName };
      });
    },
    async saveEncrypted(payload, password) {
      return exclusive(async () => {
        if (!fileSaver?.save) {
          const error = new Error('此裝置無法開啟安全另存功能');
          error.code = 'SAVE_UNAVAILABLE';
          throw error;
        }
        const encrypted = await prepare(payload, password);
        const suggestedName = fileName();
        const result = await fileSaver.save({
          fileName: suggestedName,
          data: encrypted,
          mimeType: 'application/octet-stream'
        });
        const savedName = String(result?.fileName || suggestedName);
        if (!savedName.toLowerCase().endsWith('.salarymate')) {
          const error = new Error('儲存位置未保留 .salarymate 副檔名');
          error.code = 'SAVE_EXTENSION_CHANGED';
          throw error;
        }
        return { fileName: savedName };
      });
    },
    async shareEncrypted(payload, password) {
      return exclusive(async () => {
        const encrypted = await prepare(payload, password);
        const path = fileName();
        await filesystem.writeFile({ path, data: encrypted, directory, encoding });
        const verified = await filesystem.readFile({ path, directory, encoding });
        if (verified.data !== encrypted) throw new Error('備份寫入驗證失敗');
        const { uri } = await filesystem.getUri({ path, directory });
        await share.share({
          title: path,
          files: [uri],
          dialogTitle: '分享加密薪資備份'
        });
        // A resolved system share sheet does not prove that another app saved the file.
        return { fileName: path };
      });
    }
  });
}
