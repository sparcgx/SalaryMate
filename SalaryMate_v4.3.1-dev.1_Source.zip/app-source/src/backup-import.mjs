import { snapshotSummary } from './snapshot-store.mjs';

// Android document providers often expose custom extensions as BIN or .file.
// Trust the validated payload format, never the provider-supplied name or MIME type.
export function inspectBackupCandidate(fileName, text, backup) {
  const safeName = String(fileName || '未命名備份');
  if (backup.isEncrypted(text)) {
    backup.inspect(text);
    return Object.freeze({ kind: 'encrypted', fileName: safeName });
  }
  return Object.freeze({
    kind: 'legacy-json',
    fileName: safeName,
    summary: snapshotSummary(text)
  });
}
