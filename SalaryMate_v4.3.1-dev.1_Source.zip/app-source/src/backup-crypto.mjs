const FORMAT = 'salarymate-encrypted-backup';
const VERSION = 1;
const ITERATIONS = 310_000;
const MIN_ITERATIONS = 100_000;
const MAX_ITERATIONS = 1_000_000;
const MIN_PASSWORD_LENGTH = 12;
const MAX_PLAINTEXT_BYTES = 20 * 1024 * 1024;
const MAX_CIPHERTEXT_BYTES = 28 * 1024 * 1024;
const AAD = 'SalaryMate|encrypted-backup|v1';

export class BackupCryptoError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'BackupCryptoError';
    this.code = code;
  }
}

function requireCrypto(api) {
  if (!api?.subtle || typeof api.getRandomValues !== 'function') {
    throw new BackupCryptoError('CRYPTO_UNAVAILABLE', '此裝置不支援安全備份加密');
  }
  return api;
}

function normalizePassword(password, enforceMinimum = false) {
  const value = String(password ?? '').normalize('NFC');
  if (!value) throw new BackupCryptoError('PASSWORD_REQUIRED', '請輸入備份密碼');
  if (enforceMinimum && [...value].length < MIN_PASSWORD_LENGTH) {
    throw new BackupCryptoError('PASSWORD_TOO_SHORT', `備份密碼至少需要 ${MIN_PASSWORD_LENGTH} 個字元`);
  }
  return value;
}

function bytesToBase64(bytes) {
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }
  return globalThis.btoa(binary);
}

function base64ToBytes(value, label) {
  if (typeof value !== 'string' || !value.length || value.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(value)) {
    throw new BackupCryptoError('INVALID_FORMAT', `${label} 格式錯誤`);
  }
  try {
    const binary = globalThis.atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
    return bytes;
  } catch {
    throw new BackupCryptoError('INVALID_FORMAT', `${label} 格式錯誤`);
  }
}

function parseEnvelope(text) {
  let envelope;
  try { envelope = JSON.parse(text); }
  catch { throw new BackupCryptoError('INVALID_FORMAT', '不是有效的加密備份'); }
  if (!envelope || Array.isArray(envelope) || typeof envelope !== 'object' || envelope.format !== FORMAT) {
    throw new BackupCryptoError('INVALID_FORMAT', '不是個人薪資管理加密備份');
  }
  if (envelope.version !== VERSION) {
    throw new BackupCryptoError('UNSUPPORTED_VERSION', '此加密備份版本尚不支援');
  }
  if (envelope.kdf?.name !== 'PBKDF2' || envelope.kdf?.hash !== 'SHA-256'
      || !Number.isInteger(envelope.kdf?.iterations)
      || envelope.kdf.iterations < MIN_ITERATIONS || envelope.kdf.iterations > MAX_ITERATIONS
      || envelope.cipher?.name !== 'AES-GCM' || envelope.cipher?.tagLength !== 128) {
    throw new BackupCryptoError('INVALID_FORMAT', '加密參數不受支援');
  }
  const salt = base64ToBytes(envelope.kdf.salt, 'Salt');
  const iv = base64ToBytes(envelope.cipher.iv, 'IV');
  const ciphertext = base64ToBytes(envelope.payload, 'Payload');
  if (salt.length !== 16 || iv.length !== 12 || ciphertext.length < 17 || ciphertext.length > MAX_CIPHERTEXT_BYTES) {
    throw new BackupCryptoError('INVALID_FORMAT', '加密備份大小或參數錯誤');
  }
  return { envelope, salt, iv, ciphertext };
}

async function deriveKey(password, salt, iterations, api) {
  const encoder = new TextEncoder();
  const material = await api.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']);
  return api.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt, iterations },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export function isEncryptedBackup(text) {
  try {
    const value = JSON.parse(text);
    return Boolean(value && !Array.isArray(value) && value.format === FORMAT);
  } catch { return false; }
}

export function inspectEncryptedBackup(text) {
  const { envelope } = parseEnvelope(text);
  return Object.freeze({ format: envelope.format, version: envelope.version, createdAt: envelope.createdAt || null });
}

export async function encryptBackup(payload, password, cryptoApi = globalThis.crypto) {
  const api = requireCrypto(cryptoApi);
  const normalizedPassword = normalizePassword(password, true);
  const plaintext = new TextEncoder().encode(String(payload));
  if (!plaintext.length || plaintext.length > MAX_PLAINTEXT_BYTES) {
    throw new BackupCryptoError('PAYLOAD_TOO_LARGE', '備份內容為空或超過 20 MB');
  }
  const salt = api.getRandomValues(new Uint8Array(16));
  const iv = api.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(normalizedPassword, salt, ITERATIONS, api);
  const encrypted = new Uint8Array(await api.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(AAD), tagLength: 128 },
    key,
    plaintext
  ));
  return JSON.stringify({
    format: FORMAT,
    version: VERSION,
    createdAt: new Date().toISOString(),
    kdf: { name: 'PBKDF2', hash: 'SHA-256', iterations: ITERATIONS, salt: bytesToBase64(salt) },
    cipher: { name: 'AES-GCM', iv: bytesToBase64(iv), tagLength: 128 },
    payload: bytesToBase64(encrypted)
  });
}

export async function decryptBackup(text, password, cryptoApi = globalThis.crypto) {
  const api = requireCrypto(cryptoApi);
  const normalizedPassword = normalizePassword(password);
  const { envelope, salt, iv, ciphertext } = parseEnvelope(text);
  try {
    const key = await deriveKey(normalizedPassword, salt, envelope.kdf.iterations, api);
    const plaintext = new Uint8Array(await api.subtle.decrypt(
      { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(AAD), tagLength: 128 },
      key,
      ciphertext
    ));
    if (!plaintext.length || plaintext.length > MAX_PLAINTEXT_BYTES) throw new Error('Invalid plaintext size');
    return new TextDecoder('utf-8', { fatal: true }).decode(plaintext);
  } catch (error) {
    if (error instanceof BackupCryptoError) throw error;
    throw new BackupCryptoError('AUTH_FAILED', '密碼錯誤，或備份檔案已損壞');
  }
}

export const BACKUP_CRYPTO_LIMITS = Object.freeze({
  minimumPasswordLength: MIN_PASSWORD_LENGTH,
  maximumPlaintextBytes: MAX_PLAINTEXT_BYTES,
  maximumEncryptedBytes: MAX_CIPHERTEXT_BYTES
});
