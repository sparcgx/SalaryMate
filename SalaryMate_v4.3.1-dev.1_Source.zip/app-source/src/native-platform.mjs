// iOS uses SceneDelegate's window overlay, avoiding modal conflicts with Files/Face ID.
// Android retains the existing FLAG_SECURE-based plugin.
export function platformPrivacyScreen(platform, androidPlugin, deviceSecurity) {
  return platform === 'ios'
    ? Object.freeze({
      async enable() {
        const state = await deviceSecurity.setScreenProtectionEnabled({ enabled: true });
        return { success: state.screenProtectionEnabled === true };
      },
      async disable() {
        const state = await deviceSecurity.setScreenProtectionEnabled({ enabled: false });
        return { success: state.screenProtectionEnabled === false };
      }
    })
    : androidPlugin;
}

export function platformLifecycle(platform, appPlugin, deviceSecurity) {
  return platform === 'ios'
    ? Object.freeze({ addListener: (name, handler) => deviceSecurity.addListener(name, handler) })
    : appPlugin;
}

export function platformCopy(platform) {
  const ios = platform === 'ios';
  return Object.freeze({
    lock: ios ? 'App 鎖定使用 Face ID、Touch ID 或 iPhone 裝置密碼。' : 'App 鎖定使用 Android 系統驗證。',
    protection: ios ? '切至背景時隱藏 App 預覽；不阻擋系統截圖或螢幕錄影。' : '防止截圖、錄影與背景預覽',
    protectionName: ios ? '背景畫面保護' : '螢幕保護'
  });
}
