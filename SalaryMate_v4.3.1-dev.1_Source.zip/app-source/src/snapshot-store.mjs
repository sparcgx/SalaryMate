export const STATE_KEY = 'salarymate_v310_state';
export const CREATE_SQL = `CREATE TABLE IF NOT EXISTS snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payload TEXT NOT NULL,
  created_at TEXT NOT NULL
);`;

export function validateSnapshot(text) {
  const value = JSON.parse(text);
  if (!value || Array.isArray(value) || typeof value !== 'object') throw new Error('Invalid backup');
  if (!Number.isInteger(value.schemaVersion) || value.schemaVersion < 1 || value.schemaVersion > 13) throw new Error('Unsupported schema');
  for (const field of ['companies', 'records', 'overtimeLogs']) {
    if (!Array.isArray(value[field])) throw new Error(`Missing ${field}`);
  }
  for (const field of ['leaveRecords', 'salaryAdjustments', 'yearEndEstimates']) {
    if (value[field] !== undefined && !Array.isArray(value[field])) throw new Error(`Invalid ${field}`);
  }
  return value;
}

// Snapshot transactions preserve the existing JSON contract, not duplicate payroll tables.
// DB version 1 is independent of payroll Schema 13. No automatic corrupt-data fallback.
export class SnapshotRepository {
  constructor(db) { this.db = db; }
  async open() { await this.db.execute(CREATE_SQL); }
  async read() {
    const result = await this.db.query('SELECT payload FROM snapshots ORDER BY id DESC LIMIT 1;');
    const payload = result.values?.[0]?.payload ?? null;
    if (payload !== null) validateSnapshot(payload);
    return payload;
  }
  async list() {
    const result = await this.db.query('SELECT id, payload, created_at FROM snapshots ORDER BY id DESC LIMIT 3;');
    return (result.values || []).map(row => {
      try { return { ...row, valid: true, summary: snapshotSummary(row.payload) }; }
      catch { return { id: row.id, created_at: row.created_at, valid: false }; }
    });
  }
  async write(payload, reset = false) {
    validateSnapshot(payload);
    await this.db.executeSet([
      ...(reset ? [{ statement: 'DELETE FROM snapshots;', values: [] }] : []),
      { statement: 'INSERT INTO snapshots (payload, created_at) VALUES (?, ?);', values: [payload, new Date().toISOString()] },
      { statement: 'DELETE FROM snapshots WHERE id NOT IN (SELECT id FROM snapshots ORDER BY id DESC LIMIT 3);', values: [] }
    ], true);
  }
}

export function snapshotSummary(payload) {
  const data = validateSnapshot(payload);
  return ['companies', 'records', 'overtimeLogs', 'leaveRecords', 'salaryAdjustments', 'yearEndEstimates']
    .map((key, i) => `${['公司', '薪資', '加班', '請假', '調薪', '年終'][i]} ${data[key]?.length || 0} 筆`).join('、');
}

export async function createNativeStore(repository, legacy, onStatus = () => {}) {
  await repository.open();
  let value = await repository.read();
  if (value === null) {
    const old = legacy.getItem(STATE_KEY);
    if (old !== null) {
      validateSnapshot(old);
      await repository.write(old);
      value = old; // Leave original untouched, even if verification fails.
      if (await repository.read() !== old) throw new Error('Migration verification failed');
    }
  }
  let tail = Promise.resolve();
  let failed = null;
  let pending = 0;
  return Object.freeze({
    getItem(key) { return key === STATE_KEY ? value : legacy.getItem(key); },
    setItem(key, text, reset = false) {
      if (key !== STATE_KEY) throw new Error('Unsupported storage key');
      if (failed) throw failed;
      validateSnapshot(text);
      value = text;
      pending++;
      onStatus('pending');
      tail = tail.then(async () => {
        if (failed) throw failed;
        await repository.write(text, reset);
        if (reset) {
          for (const oldKey of [STATE_KEY, 'my_salary_records_v2', 'my_salary_companies_v2', 'my_salary_overtime_v2', 'my_salary_hourly_settings_v2']) legacy.removeItem(oldKey);
        }
        pending--;
        if (!pending) onStatus('saved');
      }).catch(error => {
        failed = error;
        onStatus('failed');
        throw error;
      });
      tail.catch(() => {}); // Handled by flush and persistent UI error; no unhandled rejection.
    },
    flush() { return tail; }
  });
}
