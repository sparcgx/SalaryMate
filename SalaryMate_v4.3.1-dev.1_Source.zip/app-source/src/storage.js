/* Stage 1 synchronous adapter. No native durability/encryption claims yet.
 * Preserve the Schema 13 contract while the transactional adapter is developed.
 */
(() => {
  'use strict';
  window.SalaryMateStorage = Object.freeze({
    getItem(key) { return localStorage.getItem(key); },
    setItem(key, value) { localStorage.setItem(key, value); },
    removeItem(key) { localStorage.removeItem(key); }
  });
})();
