const CANCEL_CODES = new Set(['AUTH_CANCELLED', 'USER_CANCELLED']);

const cloneStatus = status => Object.freeze({ ...status });

export function createSecurityCoverView(root) {
  const message = root.querySelector('[data-security-message]');
  const retry = root.querySelector('[data-security-unlock]');
  const leave = root.querySelector('[data-security-leave]');
  root.addEventListener('cancel', event => event.preventDefault());
  const setPageInert = enabled => {
    for (const node of root.parentElement?.children || []) {
      if (node !== root) node.inert = enabled;
    }
  };
  return Object.freeze({
    show(text, busy = false) {
      message.textContent = text;
      retry.disabled = busy;
      retry.textContent = busy ? '正在驗證…' : '使用裝置解鎖';
      setPageInert(true);
      root.hidden = false;
      if (!root.open) root.showModal();
      root.setAttribute('aria-busy', String(busy));
      if (!busy) retry.focus({ preventScroll: true });
    },
    hide() {
      root.hidden = true;
      if (root.open) root.close();
      root.setAttribute('aria-busy', 'false');
      setPageInert(false);
    },
    isVisible: () => !root.hidden,
    bindRetry: handler => retry.addEventListener('click', handler),
    bindExit: handler => leave.addEventListener('click', handler)
  });
}

export function createSecurityController({ appPlugin, deviceSecurity, privacyScreen, view }) {
  let status = {
    available: false,
    lockEnabled: false,
    screenProtectionEnabled: true,
    screenProtectionActive: false,
    locked: false
  };
  let authenticating = false;
  let gateResolve = null;

  const refresh = async () => {
    const next = await deviceSecurity.getStatus();
    status = { ...status, ...next };
    return cloneStatus(status);
  };

  const applyScreenProtection = async () => {
    try {
      if (status.screenProtectionEnabled) {
        const result = await privacyScreen.enable({ android: { dimBackground: true, privacyModeOnActivityHidden: 'none' } });
        status.screenProtectionActive = result?.success !== false;
      } else {
        const result = await privacyScreen.disable();
        status.screenProtectionActive = result?.success !== false ? false : status.screenProtectionActive;
      }
    } catch {
      status.screenProtectionActive = false;
    }
    return cloneStatus(status);
  };

  const unlockMessage = error => {
    if (CANCEL_CODES.has(error?.code)) return '驗證已取消，資料仍保持鎖定。';
    if (error?.code === 'AUTH_UNAVAILABLE') return '請先在裝置設定啟用螢幕鎖或生物辨識，再返回重試。';
    return '無法完成裝置驗證，資料仍保持鎖定。請重試。';
  };

  const attemptUnlock = async () => {
    if (authenticating) return false;
    if (!status.available) {
      view.show('請先在裝置設定啟用螢幕鎖或生物辨識，再返回重試。');
      return false;
    }
    authenticating = true;
    view.show('請使用生物辨識或裝置螢幕鎖確認身分。', true);
    try {
      await deviceSecurity.authenticate({ reason: '解鎖薪資與備份資料' });
      status.locked = false;
      view.hide();
      if (gateResolve) {
        const resolve = gateResolve;
        gateResolve = null;
        resolve(cloneStatus(status));
      }
      return true;
    } catch (error) {
      status.locked = true;
      view.show(unlockMessage(error));
      return false;
    } finally {
      authenticating = false;
    }
  };

  view.bindRetry(async () => {
    try { await refresh(); }
    catch { view.show('無法讀取裝置安全狀態，請稍後重試。'); return; }
    await attemptUnlock();
  });
  view.bindExit(() => appPlugin.minimizeApp?.());

  return Object.freeze({
    async startGate() {
      await refresh();
      await applyScreenProtection();
      if (!status.lockEnabled || status.unlockedRecently) {
        status.locked = false;
        view.hide();
        return cloneStatus(status);
      }
      status.locked = true;
      view.show('個人薪資管理已鎖定。');
      if (await attemptUnlock()) return cloneStatus(status);
      return new Promise(resolve => { gateResolve = resolve; });
    },
    async startLifecycle() {
      await appPlugin.addListener('appStateChange', async ({ isActive }) => {
        if (authenticating) return;
        if (!isActive) {
          view.show('薪資畫面已隱藏。');
          if (status.lockEnabled) status.locked = true;
          return;
        }
        try {
          await refresh();
          if (status.lockEnabled && status.locked) await attemptUnlock();
          else view.hide();
        } catch {
          status.locked = true;
          view.show('無法讀取裝置安全狀態，薪資資料保持鎖定。');
        }
      });
    },
    async configureLock(enabled) {
      authenticating = true;
      try {
        const result = await deviceSecurity.configureLock({ enabled: Boolean(enabled) });
        status = { ...status, ...result, lockEnabled: Boolean(result.lockEnabled ?? enabled), locked: false };
        view.hide();
        return cloneStatus(status);
      } finally { authenticating = false; }
    },
    async setScreenProtection(enabled) {
      const result = await deviceSecurity.setScreenProtectionEnabled({ enabled: Boolean(enabled) });
      status.screenProtectionEnabled = Boolean(result.screenProtectionEnabled ?? enabled);
      return applyScreenProtection();
    },
    async lockNow() {
      await refresh();
      if (!status.lockEnabled) return false;
      status.locked = true;
      view.show('個人薪資管理已鎖定。');
      return attemptUnlock();
    },
    failClosed(message = '安全保護無法啟動，薪資資料保持鎖定。') {
      status.locked = true;
      view.show(message);
    },
    currentStatus: () => cloneStatus(status),
    isCovered: () => view.isVisible()
  });
}
