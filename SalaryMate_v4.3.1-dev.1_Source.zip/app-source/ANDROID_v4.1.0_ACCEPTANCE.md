# Android v4.1.0｜正式版驗收

前提：RC.1 的 `ANDROID_RC1_ACCEPTANCE.md` 1～72 項須先重測並留存 PASS 紀錄。本清單用於 versionCode 12 的正式版來源包，不取代 RC.1 證據。請先建立兩份可解密 `.salarymate` 備份。

| 項目 | 通過條件 |
|---|---|
| 身分 | Release 為 `com.salarymate.personal`、versionCode 12、versionName 4.1.0；Debug 為 `.debug` 且資料隔離 |
| 編譯 | Windows Debug、signed Release APK／AAB 與 instrumentation 全部成功 |
| 簽章 | 與現有安裝版相容，無用新金鑰覆蓋；驗證 APK、AAB 簽章與 SHA-256 |
| 權限 | 打包後權限符合既有白名單檢查，無意外網路、外部儲存、相機、麥克風、定位或通知權限 |
| 覆蓋升級 | 不解除安裝、不清資料；腳本 `adb install -r` 後比對安裝前後身分 |
| 資料保留 | 公司、薪資、加班、請假、年終、調薪與 1,373 筆歷史 OT 的筆數、關鍵金額一致 |
| 單一資料來源 | Compose 與完整核心共用 SQLite Schema 13，新增與修改各只寫入一次 |
| 安全與備份 | App 鎖與螢幕保護保留；跨版本加密備份可解密還原；錯誤密碼不寫入 |
| 離線與無崩潰 | 飛航模式可完成核心操作；冷啟動／切回／重啟後無資料消失、閃退或 ANR |
| Play 測試 | Internal testing 安裝的正式版 AAB 重做升級、資料與備份重點項；證據無阻擋問題 |

如果現有 App 是 Play 安裝版，請用 Play Internal testing 驗證升級，不因本機 APK 簽章不符而卸載現有 App。每項結果填入 `FORMAL_RELEASE_EVIDENCE.md`；任何 FAIL 即 HOLD FOR RELEASE。
