import assert from 'node:assert/strict';
import { inspectBackupCandidate } from '../src/backup-import.mjs';

const encrypted = 'encrypted-backup-payload';
let inspections = 0;
const backup = {
  isEncrypted: text => text === encrypted,
  inspect(text) {
    assert.equal(text, encrypted);
    inspections++;
    return { version: 1 };
  }
};

for (const fileName of ['backup.salarymate', 'backup.file', 'backup.bin', 'backup.salarymate.json']) {
  assert.deepEqual(inspectBackupCandidate(fileName, encrypted, backup), {
    kind: 'encrypted',
    fileName
  });
}
assert.equal(inspections, 4, 'every encrypted candidate must pass envelope inspection');

const legacy = JSON.stringify({
  schemaVersion: 13,
  companies: [{ id: 'company' }],
  records: [{ id: 'salary' }],
  overtimeLogs: [{ id: 'overtime' }]
});
const legacyResult = inspectBackupCandidate('provider-renamed.file', legacy, backup);
assert.equal(legacyResult.kind, 'legacy-json');
assert.equal(legacyResult.fileName, 'provider-renamed.file');
assert.match(legacyResult.summary, /公司 1 筆/);
assert.match(legacyResult.summary, /薪資 1 筆/);
assert.match(legacyResult.summary, /加班 1 筆/);

for (const invalid of ['not a backup', '{"schemaVersion":13}', '{bad']) {
  assert.throws(() => inspectBackupCandidate('anything.bin', invalid, backup));
}

console.log('PASS: backup import trusts validated encrypted/JSON content instead of provider MIME type or extension');
