import assert from 'node:assert/strict';
import fs from 'node:fs'; import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8'); const v=readVersionContract();
for (const p of ['scripts/formal-device-results.mjs','scripts/ios-results.mjs']) {
 const s=read(p); for (const m of ['realDevice','upgradeDataPreservation','backupRestore','lifecycle','longSession','manualAcceptance','releaseDecision']) assert(s.includes(m),`${p} missing ${m}`);
}
const a=read(`REAL_DEVICE_ACCEPTANCE_v${v.productVersion}.md`);
for (const m of ['Historical OT physical count = 1,373','VoiceOver / Dynamic Type / keyboard','Wrong-company Write = 0','Duplicate Commit = 0']) assert(a.includes(m));
console.log(`PASS: RR-03 physical evidence schema is preserved for ${v.productVersion}`);
