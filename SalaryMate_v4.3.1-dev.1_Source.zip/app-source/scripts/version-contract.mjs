import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export function readVersionContract(root = projectRoot) {
  const file = path.join(root, 'version.json');
  const value = JSON.parse(fs.readFileSync(file, 'utf8'));
  const required = ['productVersion', 'releaseVersion', 'buildNumber', 'androidVersionCode', 'schemaVersion'];
  for (const key of required) {
    if (value[key] === undefined || value[key] === null || value[key] === '') {
      throw new Error(`version.json missing ${key}`);
    }
  }
  if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(String(value.productVersion))) {
    throw new Error(`Invalid productVersion: ${value.productVersion}`);
  }
  if (!/^\d+\.\d+\.\d+$/.test(String(value.releaseVersion))) {
    throw new Error(`Invalid releaseVersion: ${value.releaseVersion}`);
  }
  for (const key of ['buildNumber', 'androidVersionCode', 'schemaVersion']) {
    if (!Number.isInteger(Number(value[key])) || Number(value[key]) < 1) {
      throw new Error(`Invalid ${key}: ${value[key]}`);
    }
    value[key] = Number(value[key]);
  }
  return Object.freeze(value);
}

export function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
