import assert from 'node:assert/strict';
import fs from 'node:fs'; import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8'); const v=readVersionContract(); const status=JSON.parse(read('version.json'));
assert.equal(status.stableEligible,false);
const gate=read(`RELEASE_GATE_v${v.productVersion}.md`);
for (const m of ['PENDING_ENVIRONMENT','PENDING_DEVICE_QA','NOT AUTHORIZED']) assert(gate.includes(m),`Gate must preserve blocker: ${m}`);
const a=read(`REAL_DEVICE_ACCEPTANCE_v${v.productVersion}.md`); assert(/Physical execution: \*\*NOT_RUN\*\*/.test(a));
console.log(`PASS: RR-04 release promotion remains fail-closed on ${v.productVersion} while physical evidence is incomplete`);
