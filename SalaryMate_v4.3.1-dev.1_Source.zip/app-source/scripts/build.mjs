import fs from 'node:fs';
import { build } from 'esbuild';
fs.rmSync('www', { recursive: true, force: true });
fs.mkdirSync('www', { recursive: true });
for (const file of ['index.html', 'styles.css', 'app.js']) {
  fs.copyFileSync(`src/${file}`, `www/${file}`);
}
fs.cpSync('src/icons', 'www/icons', { recursive: true });
await build({ entryPoints: ['src/bootstrap.mjs'], outfile: 'www/bootstrap.js', bundle: true, format: 'esm', target: 'es2022' });
console.log('App assets built. PWA and service-worker assets are intentionally omitted from the native package.');
