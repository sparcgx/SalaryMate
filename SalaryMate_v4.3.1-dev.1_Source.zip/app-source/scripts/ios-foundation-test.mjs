import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { platformCopy, platformLifecycle, platformPrivacyScreen } from '../src/native-platform.mjs';
import { createSecurityCoverView } from '../src/native-security.mjs';
import { readVersionContract } from './version-contract.mjs';
const version = readVersionContract();
const require = createRequire(import.meta.url);
const xcode = require('xcode');
const read = name => fs.readFileSync(name, 'utf8');
const pack = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
assert.equal(pack.version, version.productVersion);
assert.equal(lock.packages['node_modules/@capacitor/ios'].version, lock.packages['node_modules/@capacitor/core'].version);
const config = JSON.parse(read('capacitor.config.json'));
assert.equal(config.plugins.CapacitorSQLite.iosDatabaseLocation, 'Library/CapacitorDatabase');
assert(!config.server?.url, 'Native build must bundle local assets');

// Parse the actual Xcode graph, not just check whether source filenames occur in it.
const project = xcode.project('ios/App/App.xcodeproj/project.pbxproj'); project.parseSync();
const objects = project.hash.project.objects;
const targets = Object.values(objects.PBXNativeTarget).filter(t => typeof t === 'object');
const app = targets.find(t => t.name.replaceAll('"', '') === 'App');
const test = targets.find(t => t.name.replaceAll('"', '') === 'AppUITests');
const sourcePaths = target => target.buildPhases.flatMap(({value}) => objects.PBXSourcesBuildPhase?.[value]?.files ?? [])
  .map(({value}) => objects.PBXFileReference[objects.PBXBuildFile[value].fileRef].path.replaceAll('"', ''));
assert.deepEqual(sourcePaths(app).filter(p => p.endsWith('Plugin.swift')).sort(), ['BackupFilePlugin.swift','DeviceSecurityPlugin.swift']);
assert(sourcePaths(app).includes('SalaryMateViewController.swift'));
assert(sourcePaths(test).includes('FoundationUITests.swift'));
assert.match(test.productType, /ui-testing/);
assert.match(objects.PBXFileReference[test.productReference].path, /AppUITests\.xctest/);
assert.equal(app.dependencies.length, 0, 'App must not depend on the test runner');
assert.equal(test.dependencies.length, 1);
const configs = target => objects.XCConfigurationList[target.buildConfigurationList].buildConfigurations.map(({value}) => objects.XCBuildConfiguration[value]);
for (const c of configs(app)) {
  assert.equal(c.buildSettings.MARKETING_VERSION, version.releaseVersion);
  assert.equal(Number(c.buildSettings.CURRENT_PROJECT_VERSION), version.buildNumber);
  assert.equal(c.buildSettings.PRODUCT_BUNDLE_IDENTIFIER, c.name === 'Debug' ? 'com.salarymate.personal.iosdev' : 'com.salarymate.personal');
}
assert(read('ios/App/App/SceneDelegate.swift').includes('SalaryMateViewController()'));
assert(read('ios/App/App/Base.lproj/Main.storyboard').includes('customClass="SalaryMateViewController"'));
assert(!read('ios/App/App.xcodeproj/project.pbxproj').includes('undefined'));
assert(read('ios/App/App/DeviceSecurityPlugin.swift').includes('UIScene.willDeactivateNotification'));
const privacyResources = app.buildPhases.flatMap(({value}) => objects.PBXResourcesBuildPhase?.[value]?.files ?? [])
  .map(({value}) => objects.PBXFileReference[objects.PBXBuildFile[value].fileRef]?.path ?? '');
assert(privacyResources.some(p => p.includes('PrivacyInfo.xcprivacy')));

const android = { addListener: () => { throw new Error('Android API called on iOS'); } };
let routed = false;
const ios = platformLifecycle('ios', android, { addListener: async (name, handler) => { routed = name === 'appStateChange'; handler({isActive:false}); } });
let active = true;
await ios.addListener('appStateChange', s => { active = s.isActive; });
assert(routed); assert.equal(active, false); assert.equal(ios.minimizeApp, undefined);
assert.equal(platformLifecycle('android', android, {}), android);
assert.equal(platformPrivacyScreen('android', android), android);
let protection;
const screen = platformPrivacyScreen('ios', android, {
  async setScreenProtectionEnabled({ enabled }) { protection = enabled; return { screenProtectionEnabled: enabled }; }
});
assert.equal((await screen.enable()).success, true); assert.equal(protection, true);
assert.equal((await screen.disable()).success, true); assert.equal(protection, false);
assert.match(platformCopy('ios').protection, /不阻擋/);
assert.match(platformCopy('ios').lock, /Face ID/);

// Lock must occupy the top layer even when the backup dialog is already open.
const events = {};
const nodes = Object.fromEntries(['message','unlock','leave'].map(n => [n, { addEventListener() {}, focus() {} }]));
const sibling = {inert:false};
const root = { hidden:true, open:false,
  querySelector: selector => nodes[selector.match(/security-(\w+)/)[1]],
  addEventListener: (name, action) => { events[name] = action; },
  setAttribute() {}, showModal() { this.open=true; }, close() { this.open=false; }
};
root.parentElement = { children:[root,sibling] };
const view = createSecurityCoverView(root);
view.show('locked'); assert(root.open && sibling.inert && !root.hidden);
let prevented=false; events.cancel({preventDefault(){prevented=true;}}); assert(prevented);
view.hide(); assert(!root.open && !sibling.inert && root.hidden);
console.log('PASS: iOS project graph, isolated identity, native bridge routing and modal lock safety (not Swift compilation)');
