import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chooseSimulator } from './ios-runtime.mjs';
import { createIOSResults } from './ios-results.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const prepare = process.argv.includes('--prepare');
const baseSteps = ['Mac / Node environment', 'Xcode version', 'Locked dependencies', 'Regression tests', 'iOS assets and plugins sync', 'Swift package resolution'];
const simulationSteps = ['Simulator runtime', 'Create isolated simulator', 'Boot simulator', 'Simulator build and XCTest', 'XCTest result validation'];
const report = createIOSResults(root, prepare ? 'PREPARE_ONLY' : 'SIMULATOR_AUTOMATION', [...baseSteps, ...(prepare ? [] : simulationSteps)]);
let child;
let simulator;
let interrupted = false;
const print = message => { process.stdout.write(message + '\n'); report.log(message + '\n'); };
const xcodeArgs = ['-project', 'ios/App/App.xcodeproj', '-scheme', 'App', '-configuration', 'Debug'];


async function run(name, command, args, verify) {
  if (interrupted) throw new Error('使用者中斷');
  const step = report.start(name);
  print(`\n[RUN] ${name}`);
  let output = '';
  let exitCode = 1;
  try {
    const code = await new Promise(resolve => {
      child = spawn(command, args, { cwd: root, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
      child.stdout.on('data', chunk => { output += chunk.toString(); process.stdout.write(chunk); report.log(chunk); });
      child.stderr.on('data', chunk => { process.stderr.write(chunk); report.log(chunk); });
      child.on('error', error => { print(error.message); resolve(1); });
      child.on('close', code => resolve(Number.isInteger(code) ? code : 1));
    });
    exitCode = code;
    if (code !== 0 || interrupted) throw new Error(`${name} failed (exit ${code})`);
    if (verify) verify(output);
    report.complete(step, 0);
    return output;
  } catch (error) {
    report.complete(step, exitCode || 1);
    throw error;
  } finally { child = null; }
}

for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
  interrupted = true;
  report.finish('INCOMPLETE', `執行被 ${signal} 中斷；未執行項目維持 NOT_RUN`);
  child?.kill(signal);
});

try {
  const environmentStep = report.start('Mac / Node environment');
  const [nodeMajor, nodeMinor] = process.versions.node.split('.').map(Number);
  if (process.platform !== 'darwin' || nodeMajor < 22 || (nodeMajor === 22 && nodeMinor < 13)) {
    report.complete(environmentStep, 1);
    throw new Error('需要 macOS、Node.js 22.13+ 及 Xcode；本環境未執行 iOS 建置或實機測試');
  }
  report.complete(environmentStep, 0);
  await run('Xcode version', 'xcodebuild', ['-version'], output => {
    const major = Number(output.match(/Xcode (\d+)/)?.[1]);
    if (!major || major < 26) throw new Error('需要 Xcode 26+；請確認 xcode-select 指向完整 Xcode');
  });
  await run('Locked dependencies', 'npm', ['ci']);
  await run('Regression tests', 'npm', ['test']);
  await run('iOS assets and plugins sync', 'npm', ['run', 'ios:sync']);
  await run('Swift package resolution', 'xcodebuild', [...xcodeArgs, '-resolvePackageDependencies']);
  if (!prepare) {
    const listing = JSON.parse(await run('Simulator runtime', 'xcrun', ['simctl', 'list', '-j']));
    const { runtime, device } = chooseSimulator(listing.runtimes, listing.devicetypes);
    simulator = (await run('Create isolated simulator', 'xcrun', ['simctl', 'create', `SalaryMate-${report.result.runId}`, device.identifier, runtime.identifier])).trim();
    if (!/^[A-Fa-f0-9-]{36}$/.test(simulator)) throw new Error('無法辨識新建立的模擬器');
    await run('Boot simulator', 'xcrun', ['simctl', 'bootstatus', simulator, '-b']);
    const bundle = path.join(report.directory, 'Foundation.xcresult');
    await run('Simulator build and XCTest', 'xcodebuild', [...xcodeArgs, '-destination', `platform=iOS Simulator,id=${simulator}`, '-parallel-testing-enabled', 'NO', '-resultBundlePath', bundle, '-derivedDataPath', path.join(root, 'ios', 'DerivedData'), 'CODE_SIGNING_ALLOWED=NO', 'test']);
    await run('XCTest result validation', 'xcrun', ['xcresulttool', 'get', 'test-results', 'summary', '--path', bundle], output => {
      const summary = JSON.parse(output);
      if (!(summary.passedTests > 0) || summary.failedTests !== 0 || summary.skippedTests > 0 || summary.testResult !== 'Passed') {
        throw new Error('XCTest 結果必須有實際執行的 PASS 測試且沒有失敗／跳過');
      }
    });
  }
  report.finish('PASS', prepare ? 'iOS 工程準備完成；尚未編譯或執行 iPhone 測試' : '模擬器編譯與 XCTest 通過；iPhone 人工驗收仍未執行');
} catch (error) {
  report.finish(interrupted ? 'INCOMPLETE' : 'FAIL', error.message);
  process.exitCode = 1;
} finally {
  // Delete only the disposable simulator created by THIS run; never reset a user's device.
  if (simulator && /^[A-Fa-f0-9-]{36}$/.test(simulator)) {
    for (const action of ['shutdown', 'delete']) await new Promise(resolve => {
      const cleanup = spawn('xcrun', ['simctl', action, simulator], { stdio: 'ignore' });
      cleanup.on('error', resolve); cleanup.on('close', resolve);
    });
  }
  print(`\n${report.result.status}: ${report.result.reason}\n紀錄：${report.directory}`);
}
