import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const repository = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt',
  'utf8'
);
const math = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt',
  'utf8'
);
const models = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt',
  'utf8'
);
const screen = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt',
  'utf8'
);
const nativeUiDirectory = 'android/app/src/main/java/com/salarymate/personal/ui';
const nativeUiSources = fs.readdirSync(nativeUiDirectory)
  .filter(file => file.endsWith('.kt'))
  .map(file => fs.readFileSync(path.join(nativeUiDirectory, file), 'utf8'))
  .join('\n');

for (const marker of [
  'prepareSalaryDraft',
  'saveSalaryRecord',
  'deleteSalaryRecord',
  'salaryProfileAt',
  'salaryAdjustments',
  'salaryMonthForDate',
  '這家公司已有',
  'sourceType != "leave-sync"',
  'root.put("records", nextRecords)',
  'writeSnapshot(database, root)'
]) assert(repository.includes(marker), `Missing native payroll repository marker: ${marker}`);

for (const marker of [
  'data class NativeSalaryRecord',
  'data class NativeSalaryDraft',
  'val salaryRecords: List<NativeSalaryRecord>'
]) assert(models.includes(marker), `Missing native payroll model marker: ${marker}`);

for (const marker of [
  '建立月度薪資',
  '複製下一月',
  '刪除薪資紀錄？',
  '應發超過 NT$ 86,001 時按 5% 計算',
  '國定假日仍請依公司公告確認'
]) assert(screen.includes(marker), `Missing native payroll UI marker: ${marker}`);

assert(math.includes('gross > 86_001L'));
assert(math.includes('calendar.add(Calendar.DAY_OF_MONTH, -1)'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS salary'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS payroll'));
assert.equal(
  (nativeUiSources.match(/fun\s+money\s*\(\s*value\s*:\s*Long\s*\)/g) ?? []).length,
  1,
  'Native UI must expose exactly one money(Long) formatter'
);

const tax = gross => gross > 86_001 ? Math.round(gross * 0.05) : 0;
assert.equal(tax(86_000), 0);
assert.equal(tax(86_001), 0);
assert.equal(tax(86_002), 4_300);

const defaultPayDate = (year, month) => {
  const date = new Date(Date.UTC(year, month, 5));
  while ([0, 6].includes(date.getUTCDay())) date.setUTCDate(date.getUTCDate() - 1);
  return date.toISOString().slice(0, 10);
};
assert.equal(defaultPayDate(2026, 8), '2026-09-04');
assert.equal(defaultPayDate(2026, 9), '2026-10-05');

console.log('PASS: native monthly payroll operations, formatter uniqueness, tax and payday boundaries are guarded');
