import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { readVersionContract } from './version-contract.mjs';

const now = () => new Date().toISOString();

export function createResults(root) {
  const version = readVersionContract();
  const runId = `${now().replace(/[-:]/g, '').replace(/\..*$/, '').replace('T', '_')}_${process.pid}_${randomUUID().slice(0, 8)}`;
  const directory = path.join(root, 'test-results', `formal-v${version.productVersion}`, runId);
  fs.mkdirSync(directory, { recursive: true });
  fs.writeFileSync(path.join(directory, 'test.log'), '', 'utf8');
  const result = {
    schemaVersion: 1,
    version: version.productVersion,
    runId,
    startedAt: now(),
    finishedAt: null,
    status: 'INCOMPLETE',
    failedStep: null,
    reason: 'Test run has not completed',
    steps: [],
    realDevice: 'NOT_RUN',
    upgradeDataPreservation: 'NOT_RUN',
    backupRestore: 'NOT_RUN',
    lifecycle: 'NOT_RUN',
    longSession: 'NOT_RUN',
    manualAcceptance: 'NOT_RUN',
    releaseDecision: 'HOLD FOR RELEASE'
  };
  function persist() {
    const target = path.join(directory, 'result.json');
    const temporary = `${target}.tmp`;
    fs.writeFileSync(temporary, `${JSON.stringify(result, null, 2)}\n`, 'utf8');
    fs.renameSync(temporary, target);
    const lines = [
      `SalaryMate v${version.productVersion} device gate: ${result.status}`,
      `Run ID: ${result.runId}`,
      `Started (UTC): ${result.startedAt}`,
      `Finished (UTC): ${result.finishedAt ?? 'INCOMPLETE'}`,
      `Failed step: ${result.failedStep ?? 'none'}`,
      `Reason: ${result.reason}`,
      `Real device: ${result.realDevice}`,
      `Upgrade / data preservation: ${result.upgradeDataPreservation}`,
      `Backup / restore: ${result.backupRestore}`,
      `Lifecycle: ${result.lifecycle}`,
      `Long session: ${result.longSession}`,
      `Manual acceptance: ${result.manualAcceptance}`,
      `Release decision: ${result.releaseDecision}`,
      '',
      ...result.steps.map(step => `${step.status} | ${step.name} | exit=${step.exitCode ?? 'n/a'} | ${step.startedAt} | ${step.finishedAt ?? 'INCOMPLETE'}`),
      '',
      'Detailed command output: test.log',
      'This automated result does not approve a Production release.'
    ];
    fs.writeFileSync(path.join(directory, 'result.txt'), `${lines.join('\n')}\n`, 'utf8');
  }
  persist();
  return {
    directory,
    result,
    log(line) { fs.appendFileSync(path.join(directory, 'test.log'), `${line}\n`, 'utf8'); },
    append(chunk) { fs.appendFileSync(path.join(directory, 'test.log'), chunk); },
    start(name) {
      const step = { name, status: 'RUNNING', startedAt: now(), finishedAt: null, exitCode: null };
      result.steps.push(step);
      persist();
      return step;
    },
    complete(step, exitCode) {
      step.finishedAt = now();
      step.exitCode = exitCode;
      step.status = exitCode === 0 ? 'PASS' : 'FAIL';
      persist();
    },
    finish(status, reason, failedStep = null) {
      result.finishedAt = now();
      result.status = status;
      result.reason = reason;
      result.failedStep = failedStep;
      persist();
    }
  };
}
