import assert from 'node:assert/strict';
import fs from 'node:fs';
import { readVersionContract } from './version-contract.mjs';

const version = readVersionContract();
const manifest = fs.readFileSync('android/app/src/main/AndroidManifest.xml', 'utf8');
const gradle = fs.readFileSync('android/app/build.gradle', 'utf8');
const capacitorGradle = fs.readFileSync('android/app/capacitor.build.gradle', 'utf8');
const rootGradle = fs.readFileSync('android/build.gradle', 'utf8');
const variables = fs.readFileSync('android/variables.gradle', 'utf8');
const capacitor = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
const strings = fs.readFileSync('android/app/src/main/res/values/strings.xml', 'utf8');
const debugStrings = fs.readFileSync('android/app/src/debug/res/values/strings.xml', 'utf8');
const plugin = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/DeviceSecurityPlugin.java', 'utf8');
const backupPlugin = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/BackupFilePlugin.java', 'utf8');
const mainActivity = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/MainActivity.java', 'utf8');
const composeActivity = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ComposeShellActivity.kt', 'utf8');
const nativeSecurity = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/NativeSecurityController.kt', 'utf8');
const nativeRepository = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt', 'utf8');
const filePaths = fs.readFileSync('android/app/src/main/res/xml/file_paths.xml', 'utf8');
const bootstrap = fs.readFileSync('src/bootstrap.mjs', 'utf8');
const dataCenter = fs.readFileSync('src/data-center.mjs', 'utf8');
const app = fs.readFileSync('src/app.js', 'utf8');
const index = fs.readFileSync('src/index.html', 'utf8');
const buildScript = fs.readFileSync('scripts/build.mjs', 'utf8');
const instrumentedTest = fs.readFileSync('android/app/src/androidTest/java/com/salarymate/personal/SalaryMateInstrumentedTest.java', 'utf8');
const unitTest = fs.readFileSync('android/app/src/test/java/com/salarymate/personal/SalaryMateUnitTest.java', 'utf8');
const secureBuild = fs.readFileSync('BUILD_SIGNED_ANDROID_WINDOWS.ps1', 'utf8');
const buildCommand = fs.readFileSync('BUILD_ANDROID_WINDOWS.cmd');
const installCommand = fs.readFileSync('INSTALL_TO_ANDROID_WINDOWS.cmd');
const composeDebugBuild = fs.readFileSync('BUILD_COMPOSE_DEBUG_WINDOWS.cmd');
const composeDebugInstall = fs.readFileSync('INSTALL_COMPOSE_DEBUG_WINDOWS.cmd');

assert.equal(capacitor.appId, 'com.salarymate.personal');
assert.equal(capacitor.appName, '個人薪資管理');
assert(strings.includes('<string name="package_name">com.salarymate.personal</string>'));
assert(!strings.includes('開發版'));
assert(debugStrings.includes('com.salarymate.personal.debug'));
assert(debugStrings.includes('個人薪資管理 Compose'));
assert(manifest.includes('android:allowBackup="false"'));
assert(manifest.includes('android:usesCleartextTraffic="false"'));
assert(manifest.includes('android:dataExtractionRules="@xml/data_extraction_rules"'));
assert(manifest.includes('android.permission.USE_BIOMETRIC'));
assert(!manifest.includes('android.permission.INTERNET'));
assert(!filePaths.includes('<external-path'));
assert(filePaths.includes('<cache-path'));

assert(variables.includes('compileSdkVersion = 36'));
assert(variables.includes('targetSdkVersion = 36'));
assert(gradle.includes('namespace = "com.salarymate.personal"'));
assert(gradle.includes('applicationId "com.salarymate.personal"'));
assert(gradle.includes(`versionCode ${version.androidVersionCode}`));
assert(gradle.includes(`versionName "${version.productVersion}"`));
assert(gradle.includes('applicationIdSuffix ".debug"'));
assert(gradle.includes('debuggable false'));
assert(gradle.includes('androidx.biometric:biometric:1.1.0'));
assert(gradle.includes('androidx.compose:compose-bom:2026.06.01'));
assert(gradle.includes("apply plugin: 'org.jetbrains.kotlin.plugin.compose'"));
assert(rootGradle.includes('kotlin-gradle-plugin:2.3.21'));
assert(gradle.includes('sourceCompatibility JavaVersion.VERSION_21'));
assert(gradle.includes('targetCompatibility JavaVersion.VERSION_21'));
assert(gradle.includes("jvmTarget = '21'"));
assert(gradle.includes('jvmToolchain(21)'));
assert(capacitorGradle.includes('sourceCompatibility JavaVersion.VERSION_21'));
assert(capacitorGradle.includes('targetCompatibility JavaVersion.VERSION_21'));
assert(!gradle.includes('JavaVersion.VERSION_17'));
assert(!gradle.includes("jvmTarget = '17'"));
for (const variable of [
  'SALARYMATE_KEYSTORE_FILE',
  'SALARYMATE_KEY_ALIAS',
  'SALARYMATE_STORE_PASSWORD',
  'SALARYMATE_KEY_PASSWORD'
]) assert(gradle.includes(`System.getenv('${variable}')`), `Missing environment-only signing input: ${variable}`);
assert(gradle.includes('releaseSigningReady'));
assert(gradle.includes("[':app:assembleRelease', ':app:bundleRelease']"));
assert(!/storePassword\s+["'][^"']/.test(gradle), 'Release store password must not be hard-coded');
assert(!/keyPassword\s+["'][^"']/.test(gradle), 'Release key password must not be hard-coded');
assert(!rootGradle.includes('com.google.gms:google-services'));
assert(!gradle.includes("apply plugin: 'com.google.gms.google-services'"));
assert(!gradle.includes('google-services.json'));

assert(plugin.startsWith('package com.salarymate.personal;'));
assert(plugin.includes('BIOMETRIC_STRONG'));
assert(plugin.includes('DEVICE_CREDENTIAL'));
assert(plugin.includes('AUTH_CANCELLED'));
for (const marker of [
  'Intent.ACTION_CREATE_DOCUMENT',
  'Intent.CATEGORY_OPENABLE',
  'Intent.EXTRA_TITLE',
  'application/octet-stream',
  'OpenableColumns.DISPLAY_NAME',
  'SHA-256',
  '.salarymate',
  'SAVE_CANCELLED',
  'SAVE_EXTENSION_CHANGED',
  'SAVE_FAILED'
]) assert(backupPlugin.includes(marker), `Missing native backup hardening marker: ${marker}`);
assert(backupPlugin.startsWith('package com.salarymate.personal;'));
assert(mainActivity.startsWith('package com.salarymate.personal;'));
assert(mainActivity.includes('registerPlugin(BackupFilePlugin.class)'));
assert(composeActivity.includes('class ComposeShellActivity : FragmentActivity()'));
assert(composeActivity.includes('NativeSecurityController'));
assert(nativeSecurity.includes('WindowManager.LayoutParams.FLAG_SECURE'));
assert(nativeSecurity.includes('BIOMETRIC_STRONG'));
assert(nativeSecurity.includes('DEVICE_CREDENTIAL'));
assert(nativeRepository.includes('salarymateSQLite.db'));
assert(nativeRepository.includes('executeSet(statements, true'));
assert(plugin.includes('unlockedRecently'));
assert(manifest.includes('android:name=".ComposeShellActivity"'));
assert(manifest.match(/android:name="\.ComposeShellActivity"[\s\S]*?android:exported="true"/));
assert(manifest.match(/android:name="\.MainActivity"[\s\S]*?android:exported="false"/));

assert(bootstrap.includes("App.addListener('backButton'"));
assert(bootstrap.includes('rawExport.hidden = true'));
assert(bootstrap.includes(`'${version.productVersion}'`));
assert(bootstrap.includes("createConnection('salarymate'"));
assert(!bootstrap.includes("createConnection('salarymate_dev'"));
assert(dataCenter.includes('.salarymate'));
assert(dataCenter.includes("picker.accept = '*/*'"));
assert(dataCenter.includes('inspectBackupCandidate'));
assert(dataCenter.includes('saveEncrypted'));
assert(dataCenter.includes('shareEncrypted'));
assert(dataCenter.includes('隱私與資料處理說明'));
assert(app.includes(`APP_VERSION = '${version.productVersion}'`));
assert(app.includes('handleBackButton'));
assert(app.includes('const LEAVE_KPI_TYPES'));
assert(app.includes('calendarMonthLeaveCycle'));
assert(app.includes("mode: 'monthly_once'"));
assert(app.includes('data-fixed-leave-policy="menstrual"'));
assert(app.includes('每個曆月 1 天'));
assert(!app.includes('loadSample'));
assert(!app.includes("'load-sample'"));
assert(!index.includes('載入示範資料'));
for (const marker of ['serviceWorker', 'beforeinstallprompt', 'install-app', 'apply-pwa-update', 'pwaUpdateBanner']) {
  assert(!app.includes(marker), `Native App must not retain PWA-only runtime marker: ${marker}`);
  assert(!index.includes(marker), `Native App must not retain PWA-only UI marker: ${marker}`);
}
assert(buildScript.includes("fs.rmSync('www'"));
assert(!buildScript.includes("'storage.js'"));

assert(instrumentedTest.startsWith('package com.salarymate.personal;'));
assert(instrumentedTest.includes('com.salarymate.personal.debug'));
assert(unitTest.startsWith('package com.salarymate.personal;'));
assert(!fs.existsSync('android/app/src/androidTest/java/com/getcapacitor/myapp/ExampleInstrumentedTest.java'));
assert(!fs.existsSync('android/app/src/test/java/com/getcapacitor/myapp/ExampleUnitTest.java'));
assert(secureBuild.includes("Read-Host 'Keystore password' -AsSecureString"));
assert(secureBuild.includes("Read-Host 'Private key password' -AsSecureString"));
assert(secureBuild.includes('Remove-Item Env:SALARYMATE_STORE_PASSWORD'));
assert(!/SALARYMATE_(?:STORE|KEY)_PASSWORD\s*=\s*['"][^'"]+['"]/.test(secureBuild));

for (const command of [buildCommand, installCommand, composeDebugBuild, composeDebugInstall]) {
  assert([...command].every(byte => byte < 128), 'Windows commands must remain ASCII-only');
  for (let index = 0; index < command.length; index++) {
    if (command[index] === 0x0a) assert.equal(command[index - 1], 0x0d, 'Windows commands must use CRLF');
  }
}
const buildText = buildCommand.toString('ascii');
const installText = installCommand.toString('ascii');
const assertBatchTargets = text => {
  const labels = new Set([...text.matchAll(/^:([A-Za-z0-9_]+)\r?$/gm)].map(match => match[1].toLowerCase()));
  for (const match of text.matchAll(/\bgoto\s+([A-Za-z0-9_]+)/gi)) {
    assert(labels.has(match[1].toLowerCase()), `Undefined batch label: ${match[1]}`);
  }
};
assertBatchTargets(buildText);
assertBatchTargets(installText);
assert(!buildText.includes('echo %SALARYMATE_'), 'Signing environment values must never be printed');
for (const marker of [
  '[1/10] Validating release keystore and signing passwords',
  '-storepass:env SALARYMATE_STORE_PASSWORD',
  '-keypass:env SALARYMATE_KEY_PASSWORD',
  'signing_validation_failed',
  'npm run audit:runtime',
  ':app:testDebugUnitTest :app:assembleDebugAndroidTest',
  'clean assembleRelease bundleRelease',
  'apksigner.bat',
  'aapt.exe',
  'dump permissions',
  'android.permission.INTERNET',
  'unexpected_permission',
  'jarsigner.exe',
  'keytool.exe',
  "package: name='com.salarymate.personal'",
  `versionCode='${version.androidVersionCode}'`,
  `SalaryMate_v${version.productVersion}-release.apk`,
  `SalaryMate_v${version.productVersion}-release.aab`
]) assert(buildText.includes(marker), `Missing release build marker: ${marker}`);
assert(installText.includes(`SalaryMate_v${version.productVersion}-release.apk`));
assert(installText.includes('com.salarymate.personal'));
const composeDebugBuildText = composeDebugBuild.toString('ascii');
const composeDebugInstallText = composeDebugInstall.toString('ascii');
assertBatchTargets(composeDebugBuildText);
assertBatchTargets(composeDebugInstallText);
for (const marker of [
  ':app:testDebugUnitTest :app:assembleDebugAndroidTest :app:assembleDebug',
  "package: name='com.salarymate.personal.debug'",
  `versionCode='${version.androidVersionCode}'`,
  `SalaryMate_v${version.productVersion}-compose-debug.apk`,
  'android.permission.INTERNET'
]) assert(composeDebugBuildText.includes(marker), `Missing Compose Debug build marker: ${marker}`);
assert(composeDebugInstallText.includes(`SalaryMate_v${version.productVersion}-compose-debug.apk`));
assert(composeDebugInstallText.includes('com.salarymate.personal.debug'));

console.log('PASS: Compose dev identity, API 36, environment-only signing, native shell, auth and encrypted backup hardening');
