import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { readVersionContract } from './version-contract.mjs';

const read = (path) => fs.readFileSync(path, 'utf8');
const version = readVersionContract();
const app = read('src/app.js');
const css = read('src/styles.css');
const index = read('src/index.html');
const company = read('android/app/src/main/java/com/salarymate/personal/ui/NativeCompanyManagementScreen.kt');
const payroll = read('android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt');
const math = read('android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt');
const repo = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt');

assert.equal(version.releaseVersion, '4.3.0');
assert(version.completedGates.includes('PAX-03_IMPLEMENTATION_REGRESSION'));
assert.equal(version.schemaVersion, 13);
new vm.Script(app);

// Validation contract: native constraints -> inline field message -> focus first error.
assert(app.includes('const clearFieldValidation = (control) =>'));
assert(app.includes('const clearFormValidation = (form) =>'));
assert(app.includes('const setFieldValidation = (control, message, severity = \'error\') =>'));
assert(app.includes('const nativeConstraintMessage = (control) =>'));
assert(app.includes('const focusFirstValidationError = (form) =>'));
assert(app.includes('const validateNativeForm = (form) =>'));
assert(app.includes('const validateField = (form, name, message, severity = \'error\') =>'));
assert(app.includes('const showValidationSummary = (form, message, severity = \'error\') =>'));
assert(app.includes('有 ${invalid.length} 個欄位需要確認。'));
assert(app.includes("control.setAttribute('aria-describedby'"));
assert(app.includes("control.setAttribute('aria-invalid', 'true')"));
assert(app.includes("event.preventDefault();\n        setFieldValidation(control, nativeConstraintMessage(control), 'error');"));

// Error / warning / info are visually and semantically distinct.
assert(css.includes('PAX-03 Form Validation & Error Messaging'));
assert(css.includes('.field-message.error'));
assert(css.includes('.field-message.warning'));
assert(css.includes('.field-message.info'));
assert(css.includes('.validation-summary.error'));
assert(css.includes('.validation-summary.warning'));
assert(css.includes('.toast.warning'));
assert(css.includes('.toast.info'));
assert(index.includes('id="toast"'));
assert(app.includes("['success', 'error', 'warning', 'info']"));

// Company validation: duplicate / zero salary are warnings, required/date/negative are errors.
assert(app.includes("validateField(form, 'name', '請輸入公司名稱。')"));
assert(app.includes("validateField(form, 'employmentStartDate', '到職日格式不正確，請重新選擇日期。')"));
assert(app.includes('已有相同公司名稱；不同任職期間仍可儲存。'));
assert(app.includes('基本月薪為 0 元；允許儲存，但請確認這是預期設定。'));

// Payroll / OT / leave / advanced validation and duplicate scope stay explicit.
assert(app.includes('recordExists(draft, editing ? draft.id : \'\')'));
assert(app.includes('這家公司在這個薪資月份已有薪資紀錄。'));
assert(app.includes("validateField(form, 'hourlyRate', '每日加班時薪必須大於 0。')"));
assert(app.includes('相同日期、公司、類型與時數的加班紀錄已存在。'));
assert(app.includes("validateField(form, 'endDate', '結束日期不可早於開始日期。')"));
assert(app.includes('年終規則資料需要確認。'));
assert(app.includes('年度加薪設定資料需要確認。'));
assert(app.includes('開始日必須是 1～31。'));
assert(app.includes('結束日必須是 1～31。'));

// Commit failure must roll back in-memory state and keep persisted state unchanged.
assert(app.includes('const commitStateMutation = (mutation'));
assert(app.includes('const before = clone(state);'));
assert(app.includes('state = before;'));
assert(app.includes('薪資建立失敗。資料尚未建立，原本資料保持不變。'));
assert(app.includes('公司建立失敗。資料尚未建立。'));
assert(app.includes('還原失敗。現有資料保持不變。'));

// Backup errors are distinguished instead of collapsing into one message.
assert(app.includes('備份檔案無法讀取。現有資料保持不變。'));
assert(app.includes('不支援的備份格式。現有資料保持不變。'));
assert(app.includes('備份檔案內容已損毀或不是有效 JSON。現有資料保持不變。'));

// Android uses field-level error/supporting text and save remains actionable to reveal errors.
assert(company.includes('var attemptedSave by remember(company?.id)'));
assert(company.includes('isError = nameError'));
assert(company.includes('supportingText = { if (nameError) Text("請輸入公司名稱。") }'));
assert(company.includes('isError = salaryError'));
assert(company.includes('isError = startDateError'));
assert(company.includes('Button(enabled = !busy, onClick = {'));
assert(payroll.includes('fun validationMessage(includeMonthlyData: Boolean): String?'));
assert(payroll.includes('目前公司資料需要確認。請回公司管理重新選擇目前公司。'));
assert(payroll.includes('基本時薪必須大於 0。'));

// Frozen domain rules remain in the existing core implementation.
assert(math.includes('gross > 86_001L'));
assert(math.includes('safeHours * safeRate * 2.5'));
assert(repo.includes('目前公司尚未設定。請先到公司管理設為目前公司，再建立薪資。'));

console.log('PASS: PAX-03 validation layers, inline errors, warnings, fail-closed commits, backup error taxonomy and Android field validation contract');
