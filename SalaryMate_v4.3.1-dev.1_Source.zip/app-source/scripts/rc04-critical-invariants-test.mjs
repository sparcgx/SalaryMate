import assert from 'node:assert/strict'; import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
const gate=read('RELEASE_GATE_v4.3.0-RC.2.md');
for(const m of ['Schema 13','86,000 → 0','86,001 → 0','86,002 → 4,300','OT 1 / 1.34 / 1.67 / 2 / 2.67','Year-End Runtime Golden 153,900','Historical OT retained contract 1,373','Wrong-company Write = 0','Duplicate UI Write = 0']) assert(gate.includes(m),`Missing invariant ${m}`);
console.log('PASS: RC-04 payroll/tax/OT/year-end/historical/cross-company invariants are frozen');
