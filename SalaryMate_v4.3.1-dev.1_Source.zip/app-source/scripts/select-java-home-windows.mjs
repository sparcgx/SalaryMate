import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

function envValue(...names) {
  for (const name of names) {
    const value = process.env[name];
    if (value) return value;
  }
  return '';
}

function childDirectories(base) {
  if (!base || !fs.existsSync(base)) return [];
  try {
    return fs.readdirSync(base, { withFileTypes: true })
      .filter((entry) => entry.isDirectory())
      .map((entry) => path.join(base, entry.name));
  } catch {
    return [];
  }
}

export function parseJavaMajor(text) {
  return Number(String(text || '').match(/version "(\d+)/)?.[1] || 0);
}

export function isSupportedJavaMajor(major) {
  return major === 21;
}

export function inspectJava(home) {
  if (!home) return null;
  const javaName = process.platform === 'win32' ? 'java.exe' : 'java';
  const java = path.join(home, 'bin', javaName);
  if (!fs.existsSync(java)) return null;
  const result = spawnSync(java, ['-version'], { encoding: 'utf8' });
  const text = `${result.stdout || ''}\n${result.stderr || ''}`;
  const major = parseJavaMajor(text);
  return result.status === 0 && isSupportedJavaMajor(major)
    ? { home: path.resolve(home), major }
    : null;
}

export function selectCompatibleJava(candidates, inspector = inspectJava) {
  return candidates
    .filter(Boolean)
    .filter((candidate, index, all) => all.indexOf(candidate) === index)
    .map(inspector)
    .filter(Boolean)
    .sort((left, right) => left.major - right.major)[0] || null;
}

function main() {
  const programFiles = envValue('ProgramFiles', 'PROGRAMFILES');
  const userProfile = envValue('USERPROFILE');
  const explicitCandidates = [
    envValue('SALARYMATE_JAVA_HOME'),
    envValue('JAVA_HOME'),
    envValue('STUDIO_JDK'),
    programFiles && path.join(programFiles, 'Android', 'Android Studio', 'jbr')
  ];
  const searchRoots = [
    userProfile && path.join(userProfile, '.jdks'),
    programFiles && path.join(programFiles, 'Eclipse Adoptium'),
    programFiles && path.join(programFiles, 'Microsoft'),
    programFiles && path.join(programFiles, 'Java'),
    programFiles && path.join(programFiles, 'Zulu'),
    programFiles && path.join(programFiles, 'Amazon Corretto')
  ];
  const selected = selectCompatibleJava([...explicitCandidates, ...searchRoots.flatMap(childDirectories)]);
  if (selected) process.stdout.write(selected.home);
  else process.exitCode = 1;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();
