import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { readVersionContract } from './version-contract.mjs';
const version = readVersionContract();
const adapter = fs.readFileSync('src/storage.js', 'utf8');
const app = fs.readFileSync('src/app.js', 'utf8');
new vm.Script(adapter);
new vm.Script(app);
assert(!app.includes('localStorage.'), 'Application must use the storage boundary');
assert(app.includes('SCHEMA_VERSION = 13'));
assert(app.includes("'salarymate_v310_state'"));
const values = new Map();
const context = { window: {}, localStorage: {
  getItem: key => values.get(key) ?? null,
  setItem: (key, value) => values.set(key, String(value)),
  removeItem: key => values.delete(key)
} };
vm.runInNewContext(adapter, context);
context.window.SalaryMateStorage.setItem('test', 'snapshot');
assert.equal(context.window.SalaryMateStorage.getItem('test'), 'snapshot');
context.window.SalaryMateStorage.removeItem('test');
assert.equal(context.window.SalaryMateStorage.getItem('test'), null);
context.localStorage.setItem = () => { throw new Error('quota'); };
assert.throws(() => context.window.SalaryMateStorage.setItem('test', 'x'), /quota/);
// Run the existing full payroll/backup regression against the extracted source.
// Only the test input and new export version are substituted; assertions stay intact.
const combined = `<script>${app}</script>`;
let test = fs.readFileSync('tests/runtime-smoke.mjs', 'utf8')
  .replace("const html = fs.readFileSync(new URL('../dist/index.html', import.meta.url), 'utf8');", () => `const html = ${JSON.stringify(combined)};`)
  .replace('  vm.runInNewContext(script, {', '  window.SalaryMateStorage = localStorage;\n  vm.runInNewContext(script, {')
  .replaceAll('個人薪資管理_v3.11.1_backup_', `個人薪資管理_v${version.productVersion}_backup_`);
try {
  await import(`data:text/javascript;base64,${Buffer.from(test).toString('base64')}`);
} catch (error) {
  console.error(error.message);
  process.exit(1);
}
console.log('PASS: extracted App core and storage boundary preserve baseline behavior');
