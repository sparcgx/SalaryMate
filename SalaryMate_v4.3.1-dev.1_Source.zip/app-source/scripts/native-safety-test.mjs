import assert from 'node:assert/strict';
import fs from 'node:fs';

const crypto = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/backup/NativeBackupCrypto.kt',
  'utf8'
);
const backupService = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/backup/NativeBackupService.kt',
  'utf8'
);
const activity = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/ComposeShellActivity.kt',
  'utf8'
);
const settings = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/ui/NativeSettingsScreen.kt',
  'utf8'
);
const security = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/NativeSecurityController.kt',
  'utf8'
);
const repository = fs.readFileSync(
  'android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt',
  'utf8'
);
const webCrypto = fs.readFileSync('src/backup-crypto.mjs', 'utf8');
const manifest = fs.readFileSync('android/app/src/main/AndroidManifest.xml', 'utf8');

for (const sharedMarker of [
  'salarymate-encrypted-backup',
  'SalaryMate|encrypted-backup|v1',
  '310_000',
  'AES-GCM',
  'PBKDF2'
]) {
  assert(crypto.includes(sharedMarker), `Missing native crypto marker: ${sharedMarker}`);
  assert(webCrypto.includes(sharedMarker), `Missing Web crypto marker: ${sharedMarker}`);
}
for (const marker of [
  'Mac.getInstance("HmacSHA256")',
  'password.toByteArray(Charsets.UTF_8)',
  'AES/GCM/NoPadding',
  'GCMParameterSpec(TAG_LENGTH_BITS, iv)',
  'MIN_PASSWORD_LENGTH = 12',
  'MAX_PLAINTEXT_BYTES = 20 * 1024 * 1024',
  'CodingErrorAction.REPORT'
]) assert(crypto.includes(marker), `Missing native crypto safety marker: ${marker}`);

for (const marker of [
  'writeDocumentAndVerify',
  'OpenableColumns.DISPLAY_NAME',
  'SAVE_EXTENSION_CHANGED',
  'MessageDigest.isEqual',
  'FileProvider.getUriForFile',
  'appContext.packageName',
  'FLAG_GRANT_READ_URI_PERMISSION',
  'MAX_IMPORT_BYTES = 30 * 1024 * 1024'
]) assert(backupService.includes(marker), `Missing native backup file marker: ${marker}`);

assert(!backupService.includes('BuildConfig'), 'Native backup must not depend on generated BuildConfig');

for (const marker of [
  'ActivityResultContracts.CreateDocument',
  'ActivityResultContracts.OpenDocument',
  'prepareEncryptedBackup',
  'prepareRestoreCandidate',
  'applyRestoreCandidate',
  'externalSystemFlow',
  'pendingRestorePassword = null'
]) assert(activity.includes(marker), `Missing native backup activity marker: ${marker}`);

for (const marker of [
  '加密並另存 .salarymate',
  '加密後使用系統分享',
  '選擇加密備份並還原',
  '核對還原內容',
  '確認還原',
  'App 鎖',
  '螢幕保護',
  '密碼不會寫入 App 設定'
]) assert(settings.includes(marker), `Missing native settings UI marker: ${marker}`);

assert(security.includes('fun configureLock('));
assert(security.includes('setScreenProtectionEnabled'));
assert(security.includes('WindowManager.LayoutParams.FLAG_SECURE'));
assert(repository.includes('exportSnapshotPayload'));
assert(repository.includes('restoreSnapshotPayload'));
assert(repository.includes('schemaValue !is Number || schemaValue.toDouble() != 13.0'));
assert(repository.includes('writeSnapshot(database, root)'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS backup'));
assert(manifest.includes('android:allowBackup="false"'));
assert(manifest.includes('androidx.core.content.FileProvider'));
assert(manifest.includes('android:authorities="${applicationId}.fileprovider"'));
assert(manifest.match(/android:name="\.ComposeShellActivity"[\s\S]*?android:configChanges=/));

console.log('PASS: native encrypted backup, restore, share, security and single-source guards are present');
