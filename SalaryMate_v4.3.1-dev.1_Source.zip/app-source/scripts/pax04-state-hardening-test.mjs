import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { readVersionContract } from './version-contract.mjs';

const read = path => fs.readFileSync(path, 'utf8');
const version = readVersionContract();
const app = read('src/app.js');
const css = read('src/styles.css');
const models = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt');
const shell = read('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt');
const home = read('android/app/src/main/java/com/salarymate/personal/ui/NativeHomeScreen.kt');
const quick = read('android/app/src/main/java/com/salarymate/personal/ui/NativeQuickEntryScreen.kt');
const payroll = read('android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt');
const company = read('android/app/src/main/java/com/salarymate/personal/ui/NativeCompanyManagementScreen.kt');
const settings = read('android/app/src/main/java/com/salarymate/personal/ui/NativeSettingsScreen.kt');
const math = read('android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt');
const repo = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt');

assert.equal(version.releaseVersion, '4.3.0');
assert(version.completedGates.includes('PAX-04_IMPLEMENTATION_REGRESSION'));
assert.equal(version.schemaVersion, 13);
new vm.Script(app);

// Explicit web state model.
assert(app.includes("const APP_DATA_STATES = Object.freeze(['idle', 'loading', 'ready', 'empty', 'invalid', 'failure'])"));
assert(app.includes("const OPERATION_STATES = Object.freeze(['idle', 'loading', 'submitting', 'failure'])"));
assert(app.includes('const classifyDataStatus = () =>'));
assert(app.includes("if (!domainRecordCount()) return 'empty';"));
assert(app.includes("if (!state.companies.length) return 'invalid';"));
assert(app.includes("if (currentCount !== 1) return 'invalid';"));
assert(app.includes("setDataStatus('failure', '無法安全讀取本機薪資資料。系統沒有把讀取失敗當成空白資料"));
assert(!app.includes('舊資料無法解析，已以空白資料啟動'));

// Loading / Failure / Invalid are different render states and failure has a safe retry.
assert(app.includes('const renderAppStatePanel = () =>'));
assert(app.includes('正在讀取薪資資料'));
assert(app.includes('資料讀取失敗'));
assert(app.includes('目前公司設定需要確認'));
assert(app.includes("data-action=\"retry-load\""));
assert(app.includes('const retryAppLoad = () =>'));
assert(app.includes("const invalidBlocked = runtimeState.dataStatus === 'invalid' && ui.tab !== 'companies'"));
assert(css.includes('PAX-04 Loading / Empty / Failure State Hardening'));
assert(css.includes('.app-state-card.failure'));
assert(css.includes('.operation-state.submitting'));

// Company switching must preserve the old context until commit succeeds.
assert(app.includes("setOperationStatus('submitting', 'switch-company'"));
assert(app.includes("const previousCompany = currentCompany();"));
assert(app.includes("const ok = commitStateMutation(() => {"));
assert(app.includes('無法切換公司。目前仍使用'));
assert(app.includes('ui.companyFilter = previousFilter;'));
assert(app.includes("ui.companyDetailId = '';"));

// Restore validates before replacement and restores old state on failure.
assert(app.includes("setOperationStatus('loading', 'restore-read'"));
assert(app.includes('const imported = normalizeState(raw);'));
assert(app.includes('const before = clone(state);'));
assert(app.includes('resetTransientUiAfterRestore();'));
assert(app.includes("setOperationStatus('failure', 'restore-commit', '還原失敗。現有資料保持不變。')"));
assert(app.includes('備份檔案無法讀取。現有資料保持不變。'));
assert(app.includes('不支援的備份格式。現有資料保持不變。'));
assert(app.includes('備份檔案內容已損毀或不是有效 JSON。現有資料保持不變。'));

// Destructive writes use rollback instead of mutating then blindly saving.
for (const message of [
  '刪除失敗。原本薪資紀錄保持不變。',
  '刪除失敗。原本加班紀錄保持不變。',
  '刪除失敗。原本請假紀錄保持不變。',
  '刪除失敗。原本公司資料保持不變。',
  '刪除失敗。原本調薪紀錄保持不變。',
  '清除失敗。原本資料保持不變。'
]) assert(app.includes(message), `Missing fail-closed message: ${message}`);

// Android uses a shared explicit Loading / Empty / Invalid / Failed / Ready contract.
assert(models.includes('data object Loading : NativeLoadState'));
assert(models.includes('data class Empty(val snapshot: NativeSnapshot) : NativeLoadState'));
assert(models.includes('data class Invalid(val snapshot: NativeSnapshot, val message: String) : NativeLoadState'));
assert(models.includes('data class Ready(val snapshot: NativeSnapshot) : NativeLoadState'));
assert(models.includes('data class Failed(val message: String) : NativeLoadState'));
assert(shell.includes('private fun classifyNativeLoadState(snapshot: NativeSnapshot): NativeLoadState'));
assert(shell.includes('!snapshot.hasSnapshot || snapshot.companies.isEmpty() -> NativeLoadState.Empty(snapshot)'));
assert(shell.includes('snapshot.currentCompany == null -> NativeLoadState.Invalid'));
assert(shell.includes('classifyNativeLoadState(repository.loadSnapshot())'));
assert(home.includes('is NativeLoadState.Empty'));
assert(home.includes('is NativeLoadState.Invalid'));
assert(quick.includes('is NativeLoadState.Empty'));
assert(quick.includes('is NativeLoadState.Invalid'));
assert(payroll.includes('is NativeLoadState.Empty'));
assert(payroll.includes('is NativeLoadState.Invalid'));
assert(company.includes('is NativeLoadState.Empty, is NativeLoadState.Invalid, is NativeLoadState.Ready'));
assert(settings.includes('is NativeLoadState.Empty'));
assert(settings.includes('is NativeLoadState.Invalid'));

// Existing business rules remain frozen.
assert(math.includes('gross > 86_001L'));
assert(math.includes('safeHours * safeRate * 2.5'));
assert(repo.includes('schema == 13'));

console.log('PASS: PAX-04 separates loading/empty/invalid/failure/ready, preserves current-company context, and fails closed for restore/destructive writes');
