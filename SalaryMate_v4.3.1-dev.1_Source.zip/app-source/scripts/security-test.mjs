import assert from 'node:assert/strict';
import { createSecurityController } from '../src/native-security.mjs';

let status = { available: true, lockEnabled: true, screenProtectionEnabled: true };
let authenticationCalls = 0;
let failNextAuthentication = true;
let appStateListener;
let retry;
let exit;
let minimized = 0;
const viewState = { visible: false, message: '', busy: false };
const view = {
  show(message, busy = false) { Object.assign(viewState, { visible: true, message, busy }); },
  hide() { viewState.visible = false; },
  isVisible() { return viewState.visible; },
  bindRetry(handler) { retry = handler; },
  bindExit(handler) { exit = handler; }
};
const appPlugin = {
  async addListener(name, handler) { if (name === 'appStateChange') appStateListener = handler; },
  async minimizeApp() { minimized++; }
};
const deviceSecurity = {
  async getStatus() { return { ...status }; },
  async authenticate() {
    authenticationCalls++;
    if (failNextAuthentication) {
      failNextAuthentication = false;
      const error = new Error('cancelled');
      error.code = 'AUTH_CANCELLED';
      throw error;
    }
    return { authenticated: true };
  },
  async configureLock({ enabled }) {
    status.lockEnabled = enabled;
    return { ...status };
  },
  async setScreenProtectionEnabled({ enabled }) {
    status.screenProtectionEnabled = enabled;
    return { ...status };
  }
};
let privacyEnabled = 0;
let privacyDisabled = 0;
const privacyScreen = {
  async enable() { privacyEnabled++; return { success: true }; },
  async disable() { privacyDisabled++; return { success: true }; }
};

const controller = createSecurityController({ appPlugin, deviceSecurity, privacyScreen, view });
const gate = controller.startGate();
await new Promise(resolve => setTimeout(resolve, 0));
assert.equal(viewState.visible, true);
assert.match(viewState.message, /取消/);
assert.equal(privacyEnabled, 1);
await retry();
await gate;
assert.equal(viewState.visible, false);
assert.equal(authenticationCalls, 2);

await controller.startLifecycle();
await appStateListener({ isActive: false });
assert.equal(viewState.visible, true);
await appStateListener({ isActive: true });
assert.equal(viewState.visible, false);
assert.equal(authenticationCalls, 3);

await controller.setScreenProtection(false);
assert.equal(privacyDisabled, 1);
assert.equal(controller.currentStatus().screenProtectionEnabled, false);
await controller.configureLock(false);
assert.equal(controller.currentStatus().lockEnabled, false);
exit();
assert.equal(minimized, 1);
controller.failClosed();
assert.equal(viewState.visible, true);
assert.equal(controller.currentStatus().locked, true);
console.log('PASS: startup gate, cancellation/retry, foreground relock, privacy toggle and safe exit lifecycle');
