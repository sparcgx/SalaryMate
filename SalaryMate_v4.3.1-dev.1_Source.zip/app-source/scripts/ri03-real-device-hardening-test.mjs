import assert from 'node:assert/strict';
import fs from 'node:fs';
import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8'); const v=readVersionContract(); const acceptance=`REAL_DEVICE_ACCEPTANCE_v${v.productVersion}.md`;
const android=read('scripts/formal-device-results.mjs');
const ios=read('scripts/ios-results.mjs');
for(const marker of ['realDevice','upgradeDataPreservation','backupRestore','lifecycle','longSession','releaseDecision']) {
 assert(android.includes(marker),`Android result missing ${marker}`); assert(ios.includes(marker),`iOS result missing ${marker}`);
}
assert(read('scripts/run-formal-device-gate.mjs').includes(':app:connectedDebugAndroidTest'));
assert(read('scripts/run-ios-gate.mjs').includes('Simulator build and XCTest'));
assert(read(acceptance).includes('Wrong-company Write = 0'));
console.log('PASS: RI-03 device evidence schema covers real device, upgrade, backup, lifecycle, long-session and isolation acceptance');
