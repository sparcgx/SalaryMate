import assert from 'node:assert/strict';
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
import { readVersionContract } from './version-contract.mjs';

const v = readVersionContract();
const run = spawnSync(process.execPath, ['scripts/sync-version.mjs', '--check'], { encoding: 'utf8' });
if (run.stdout) process.stdout.write(run.stdout);
if (run.stderr) process.stderr.write(run.stderr);
assert.equal(run.status, 0, 'Generated version bindings drifted from version.json');

const read = p => fs.readFileSync(p, 'utf8');
const pack = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
assert.equal(pack.version, v.productVersion);
assert.equal(lock.version, v.productVersion);
assert.equal(lock.packages[''].version, v.productVersion);
assert.match(read('android/app/build.gradle'), new RegExp(`versionCode\\s+${v.androidVersionCode}\\b`));
assert(read('android/app/build.gradle').includes(`versionName "${v.productVersion}"`));
assert(read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt').includes(`NATIVE_APP_VERSION = "${v.productVersion}"`));
assert(read('ios/App/App/Info.plist').includes(`<string>${v.productVersion}</string>`));
assert(read('ios/App/App.xcodeproj/project.pbxproj').includes(`MARKETING_VERSION = ${v.releaseVersion};`));
assert(read('ios/App/App.xcodeproj/project.pbxproj').includes(`CURRENT_PROJECT_VERSION = ${v.buildNumber};`));
assert(!read('scripts/run-formal-device-gate.mjs').includes('4.2.0-dev.1-debug'), 'Legacy formal-device version residue');
console.log(`PASS: CM-01 unified version contract ${v.productVersion}; schema ${v.schemaVersion}; drift 0`);
