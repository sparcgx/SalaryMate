import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createResults } from './formal-device-results.mjs';

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'salarymate-formal-report-'));
try {
  const report = createResults(root);
  const json = () => JSON.parse(fs.readFileSync(path.join(report.directory, 'result.json'), 'utf8'));
  assert.equal(json().status, 'INCOMPLETE');
  assert.equal(json().realDevice, 'NOT_RUN');
  assert.equal(json().upgradeDataPreservation, 'NOT_RUN');
  assert.equal(json().backupRestore, 'NOT_RUN');
  assert.equal(json().lifecycle, 'NOT_RUN');
  assert.equal(json().longSession, 'NOT_RUN');
  assert.equal(json().manualAcceptance, 'NOT_RUN');
  const passing = report.start('Actual step A');
  assert.equal(json().steps[0].status, 'RUNNING');
  report.complete(passing, 0);
  const failing = report.start('Actual step B');
  report.complete(failing, 23);
  report.log('ERROR example');
  report.finish('FAIL', 'Actual step B failed with exit 23', 'Actual step B');
  assert.equal(json().status, 'FAIL');
  assert.equal(json().failedStep, 'Actual step B');
  assert.deepEqual(json().steps.map(step => step.status), ['PASS', 'FAIL']);
  assert.equal(json().steps[1].exitCode, 23);
  assert.equal(json().releaseDecision, 'HOLD FOR RELEASE');
  assert.match(fs.readFileSync(path.join(report.directory, 'result.txt'), 'utf8'), /Actual step B/);
  assert.match(fs.readFileSync(path.join(report.directory, 'test.log'), 'utf8'), /ERROR example/);

  const passedReport = createResults(root);
  const passedStep = passedReport.start('Actual successful step');
  passedReport.complete(passedStep, 0);
  passedReport.finish('PASS', 'Automated checks passed');
  const success = JSON.parse(fs.readFileSync(path.join(passedReport.directory, 'result.json'), 'utf8'));
  assert.equal(success.status, 'PASS');
  assert.equal(success.steps[0].status, 'PASS');
  assert.equal(success.manualAcceptance, 'NOT_RUN');
  assert.notEqual(passedReport.directory, report.directory);
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}

console.log('PASS: formal device result files capture real step statuses and failure codes');
