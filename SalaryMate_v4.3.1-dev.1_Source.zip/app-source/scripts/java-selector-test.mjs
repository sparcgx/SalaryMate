import assert from 'node:assert/strict';
import {
  isSupportedJavaMajor,
  parseJavaMajor,
  selectCompatibleJava
} from './select-java-home-windows.mjs';

assert.equal(parseJavaMajor('openjdk version "21.0.8" 2025-07-15 LTS'), 21);
assert.equal(parseJavaMajor('java version "25.0.1"'), 25);
assert.equal(parseJavaMajor('not Java output'), 0);
assert.equal(isSupportedJavaMajor(21), true);
assert.equal(isSupportedJavaMajor(24), false);
assert.equal(isSupportedJavaMajor(25), false);

const majors = new Map([
  ['jdk-25', 25],
  ['jdk-23', 23],
  ['jdk-21', 21]
]);
const inspect = (home) => {
  const major = majors.get(home) || 0;
  return isSupportedJavaMajor(major) ? { home, major } : null;
};

assert.deepEqual(
  selectCompatibleJava(['jdk-25', 'jdk-23', 'jdk-21'], inspect),
  { home: 'jdk-21', major: 21 }
);
assert.equal(selectCompatibleJava(['jdk-25'], inspect), null);

console.log('PASS: Windows JDK selector requires JDK 21 for the Android and Kotlin toolchains');
