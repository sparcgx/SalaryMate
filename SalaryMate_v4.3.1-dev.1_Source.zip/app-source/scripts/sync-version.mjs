import fs from 'node:fs';
import path from 'node:path';
import { projectRoot, readVersionContract } from './version-contract.mjs';

const mode = process.argv.includes('--write') ? 'write' : 'check';
const v = readVersionContract(projectRoot);
const changed = [];

function read(rel) { return fs.readFileSync(path.join(projectRoot, rel), 'utf8'); }
function write(rel, text) { fs.writeFileSync(path.join(projectRoot, rel), text, 'utf8'); }
function expectReplace(text, regex, replacement, label) {
  if (!regex.test(text)) throw new Error(`Version binding pattern not found: ${label}`);
  regex.lastIndex = 0;
  return text.replace(regex, replacement);
}
function apply(rel, transform) {
  const before = read(rel);
  const after = transform(before);
  if (before !== after) {
    changed.push(rel);
    if (mode === 'write') write(rel, after);
  }
}
function applyJson(rel, transform) {
  const before = JSON.parse(read(rel));
  const after = transform(before);
  const text = `${JSON.stringify(after, null, 2)}\n`;
  const current = read(rel);
  if (current !== text) {
    changed.push(rel);
    if (mode === 'write') write(rel, text);
  }
}

applyJson('package.json', value => ({ ...value, version: v.productVersion }));
applyJson('package-lock.json', value => {
  value.version = v.productVersion;
  if (value.packages?.['']) value.packages[''].version = v.productVersion;
  return value;
});

apply('src/app.js', text => expectReplace(text, /const APP_VERSION = '[^']+';/, `const APP_VERSION = '${v.productVersion}';`, 'src/app.js APP_VERSION'));
apply('src/bootstrap.mjs', text => expectReplace(text, /(Encoding\.UTF8,\s*\n\s*)'[^']+'/, `$1'${v.productVersion}'`, 'src/bootstrap.mjs backup version'));
apply('src/native-backup.mjs', text => expectReplace(text, /version = '[^']+'/, `version = '${v.productVersion}'`, 'src/native-backup.mjs default version'));
apply('src/index.html', text => text
  .replace(/(<title>個人薪資管理 v)[^<]+(<\/title>)/, `$1${v.productVersion}$2`)
  .replace(/(<span class="version">v)[^<]+(<\/span>)/, `$1${v.productVersion}$2`));

apply('android/app/build.gradle', text => text
  .replace(/versionCode\s+\d+/, `versionCode ${v.androidVersionCode}`)
  .replace(/versionName\s+"[^"]+"/, `versionName "${v.productVersion}"`));
apply('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt', text =>
  expectReplace(text, /const val NATIVE_APP_VERSION = "[^"]+"/, `const val NATIVE_APP_VERSION = "${v.productVersion}"`, 'NATIVE_APP_VERSION'));
apply('android/app/src/androidTest/java/com/salarymate/personal/SalaryMateInstrumentedTest.java', text => text
  .replace(/assertEquals\(\d+L, packageInfo\.getLongVersionCode\(\)\);/, `assertEquals(${v.androidVersionCode}L, packageInfo.getLongVersionCode());`)
  .replace(/versionName\.equals\("[^"]+"\) \|\| packageInfo\.versionName\.equals\("[^"]+-debug"\)/,
    `versionName.equals("${v.productVersion}") || packageInfo.versionName.equals("${v.productVersion}-debug")`));

apply('ios/App/App/Info.plist', text => expectReplace(text,
  /(<key>SalaryMateVersion<\/key>\s*\n\s*<string>)[^<]+(<\/string>)/,
  `$1${v.productVersion}$2`, 'Info.plist SalaryMateVersion'));
apply('ios/App/App.xcodeproj/project.pbxproj', text => text
  .replace(/CURRENT_PROJECT_VERSION = \d+;/g, `CURRENT_PROJECT_VERSION = ${v.buildNumber};`)
  .replace(/MARKETING_VERSION = [^;]+;/g, `MARKETING_VERSION = ${v.releaseVersion};`));

for (const rel of [
  'BUILD_ANDROID_WINDOWS.cmd',
  'BUILD_COMPOSE_DEBUG_WINDOWS.cmd',
  'INSTALL_COMPOSE_DEBUG_WINDOWS.cmd',
  'INSTALL_TO_ANDROID_WINDOWS.cmd',
  'RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd',
  'PREPARE_IOS_MAC.command',
  'RUN_IOS_FOUNDATION_GATE_MAC.command'
]) {
  apply(rel, text => text
    .replace(/v4\.3\.0(?:-(?:dev|RC)\.\d+)?/g, `v${v.productVersion}`)
    .replace(/4\.3\.0(?:-(?:dev|RC)\.\d+)?/g, v.productVersion)
    .replace(/versionCode='\d+'/g, `versionCode='${v.androidVersionCode}'`)
    .replace(/versionCode=\d+/g, `versionCode=${v.androidVersionCode}`)
    .replace(/versionCode \d+\./g, `versionCode ${v.androidVersionCode}.`));
}

if (changed.length) {
  if (mode === 'check') {
    console.error(`VERSION DRIFT: ${changed.length} generated binding(s) differ from version.json`);
    for (const rel of changed) console.error(` - ${rel}`);
    console.error('Run: npm run version:sync');
    process.exitCode = 1;
  } else {
    console.log(`Version bindings synchronized from version.json: ${changed.length}`);
    for (const rel of changed) console.log(` - ${rel}`);
  }
} else {
  console.log(`PASS: version.json bindings are synchronized (${v.productVersion}, schema ${v.schemaVersion})`);
}
