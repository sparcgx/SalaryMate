import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export function inspectAndroid() {
  const java = process.env.JAVA_HOME ? path.join(process.env.JAVA_HOME, 'bin', process.platform === 'win32' ? 'java.exe' : 'java') : 'java';
  const result = spawnSync(java, ['-version'], { encoding: 'utf8' });
  const javaText = `${result.stdout || ''}\n${result.stderr || ''}`;
  const major = Number(javaText.match(/version "(\d+)/)?.[1] || 0);
  const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
  const javaSupported = result.status === 0 && major === 21;
  const javaDetail = !major
    ? '找不到 Java；請使用 Android Studio 內建 JBR'
    : javaSupported
      ? `目前 JDK ${major}`
      : `目前 JDK ${major}；本版 Java/Kotlin Toolchain 固定使用 JDK 21`;
  const checks = [
    ['JDK 21', javaSupported, javaDetail],
    ['Android SDK 路徑', Boolean(sdk && fs.existsSync(sdk)), sdk ? '已設定環境變數' : '請設定 ANDROID_HOME'],
    ['Android API 36', Boolean(sdk && fs.existsSync(path.join(sdk, 'platforms', 'android-36', 'android.jar'))), 'SDK Manager → Android 16 / API 36'],
    ['Android Build Tools', Boolean(sdk && fs.existsSync(path.join(sdk, 'build-tools', '35.0.0'))), 'SDK Manager → Build Tools 35.0.0'],
    ['ADB 裝置工具', Boolean(sdk && fs.existsSync(path.join(sdk, 'platform-tools', process.platform === 'win32' ? 'adb.exe' : 'adb'))), 'SDK Manager → Platform Tools']
  ];
  return checks;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const checks = inspectAndroid();
  for (const [name, pass, detail] of checks) console.log(`${pass ? 'PASS' : 'HOLD'} ${name} — ${detail}`);
  console.log('此檢查不代表 Gradle 依賴下載、APK 編譯或手機驗收成功。');
  process.exitCode = checks.every(([, pass]) => pass) ? 0 : 1;
}
