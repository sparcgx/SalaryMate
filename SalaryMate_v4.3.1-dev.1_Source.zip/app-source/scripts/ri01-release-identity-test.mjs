import assert from 'node:assert/strict';
import fs from 'node:fs';
import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8');
const v=readVersionContract();
assert.match(v.productVersion,/^4\.3\.0-(?:dev|RC)\.\d+$/);
assert.equal(v.releaseVersion,'4.3.0');
assert.ok(v.androidVersionCode >= 16);
assert.ok(v.buildNumber >= 4);
assert.equal(v.schemaVersion,13);
for(const [p,m] of [
 ['package.json',`\"version\": \"${v.productVersion}\"`],['src/app.js',`APP_VERSION = '${v.productVersion}'`],
 ['android/app/build.gradle',`versionCode ${v.androidVersionCode}`],['android/app/build.gradle',`versionName \"${v.productVersion}\"`],
 ['ios/App/App/Info.plist',`<string>${v.productVersion}</string>`],['ios/App/App.xcodeproj/project.pbxproj',`CURRENT_PROJECT_VERSION = ${v.buildNumber};`]
]) assert(read(p).includes(m),`${p} missing ${m}`);
assert(read('scripts/sync-version.mjs').includes('(?:-(?:dev|RC)\\.\\d+)?'));
console.log(`PASS: RI-01 release identity is unified at ${v.productVersion} / code ${v.androidVersionCode} / iOS build ${v.buildNumber} / Schema ${v.schemaVersion}`);
