import assert from 'node:assert/strict';
import fs from 'node:fs';
import { readVersionContract } from './version-contract.mjs';

const read = path => fs.readFileSync(path, 'utf8');
const json = path => JSON.parse(read(path));
const contract = readVersionContract();
const version = contract.productVersion;
const code = contract.androidVersionCode;
const schema = contract.schemaVersion;
const pack = json('package.json');
const lock = json('package-lock.json');
const gradle = read('android/app/build.gradle');
const manifest = read('android/app/src/main/AndroidManifest.xml');
const models = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt');
const repo = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt');
const nativeBackup = read('android/app/src/main/java/com/salarymate/personal/backup/NativeBackupService.kt');
const nativeCrypto = read('android/app/src/main/java/com/salarymate/personal/backup/NativeBackupCrypto.kt');
const signed = read('BUILD_ANDROID_WINDOWS.cmd');
const debug = read('BUILD_COMPOSE_DEBUG_WINDOWS.cmd');
const installer = read('INSTALL_TO_ANDROID_WINDOWS.cmd');
const device = read('RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd');
const evidence = read('FORMAL_RELEASE_EVIDENCE.md');
const gate = read('RELEASE_GATE_v4.1.0.md');
const instrumented = read('android/app/src/androidTest/java/com/salarymate/personal/SalaryMateInstrumentedTest.java');

assert.equal(pack.version, version);
assert.equal(lock.version, version);
assert.equal(lock.packages[''].version, version);
assert(gradle.includes('applicationId "com.salarymate.personal"'));
assert(gradle.includes('applicationIdSuffix ".debug"'));
assert(gradle.includes(`versionCode ${code}`));
assert(gradle.includes(`versionName "${version}"`));
assert(models.includes(`NATIVE_APP_VERSION = "${version}"`));
assert(read('src/app.js').includes(`APP_VERSION = '${version}'`));
assert(read('src/bootstrap.mjs').includes(`'${version}'`));
assert(read('src/native-backup.mjs').includes(`version = '${version}'`));
assert(read('src/index.html').includes(`v${version}`));
assert(instrumented.includes(`assertEquals(${code}L, packageInfo.getLongVersionCode())`));
assert(instrumented.includes(`versionName.equals("${version}-debug")`));
assert(repo.includes('salarymateSQLite.db'));
assert(repo.includes('schema == 13'));
assert(repo.includes('ORDER BY id DESC LIMIT 3'));
assert(!repo.includes('CREATE TABLE IF NOT EXISTS overtime'));
assert(!repo.includes('CREATE TABLE IF NOT EXISTS leave'));
assert(!repo.includes('CREATE TABLE IF NOT EXISTS backup'));
assert(nativeCrypto.includes('SalaryMate|encrypted-backup|v1'));
assert(nativeCrypto.includes('310_000'));
assert(nativeBackup.includes('appContext.packageName'));
assert(!nativeBackup.includes('BuildConfig'));
assert(manifest.includes('android:authorities="${applicationId}.fileprovider"'));

for (const output of [`SalaryMate_v${version}-release.apk`, `SalaryMate_v${version}-release.aab`]) {
  assert(signed.includes(output));
}
for (const marker of [`versionCode='${code}'`, `versionName='${version}'`, 'apksigner.bat', 'jarsigner.exe', 'dump permissions']) {
  assert(signed.includes(marker), `Missing signed build check: ${marker}`);
}
assert(debug.includes(`versionCode='${code}'`));
assert(debug.includes(`SalaryMate_v${version}-compose-debug.apk`));
assert(installer.includes(`SalaryMate_v${version}-release.apk`));
assert(installer.includes('install -r'));
assert(installer.includes('FORMAL_preinstall_identity.txt'));
assert(installer.includes('FORMAL_postinstall_identity.txt'));
assert(!/^\s*"?%ADB%"?\s+(?:uninstall|shell\s+pm\s+clear)\b/im.test(installer));
assert(device.includes('scripts\\run-formal-device-gate.mjs'));
assert(read('scripts/run-formal-device-gate.mjs').includes(':app:connectedDebugAndroidTest'));
assert(read('scripts/run-formal-device-gate.mjs').includes('readVersionContract'));
assert(read('scripts/run-formal-device-gate.mjs').includes('version.productVersion'));
assert.equal(schema, 13);
assert(read('scripts/formal-device-results.mjs').includes('manualAcceptance: \'NOT_RUN\''));

assert(gate.includes('RC.1 實機 1～72'));
assert(gate.includes('全部證據核對通過後'));
assert(evidence.includes('RC.1 1～72 實機測試'));
assert(evidence.includes('最終放行者／日期'));
if (evidence.includes('| 未測 |') || evidence.includes('最終放行者／日期：未核准')) {
  assert(gate.includes('目前狀態：**HOLD FOR RELEASE**'), 'Unverified evidence cannot be promoted');
}
assert(read('ANDROID_v4.1.0_ACCEPTANCE.md').includes('1～72'));

for (const path of [
  'BUILD_ANDROID_WINDOWS.cmd',
  'BUILD_COMPOSE_DEBUG_WINDOWS.cmd',
  'INSTALL_COMPOSE_DEBUG_WINDOWS.cmd',
  'INSTALL_TO_ANDROID_WINDOWS.cmd',
  'RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd'
]) {
  const bytes = fs.readFileSync(path);
  assert([...bytes].every(byte => byte < 128), `${path} must remain ASCII-only`);
  for (let index = 0; index < bytes.length; index++) {
    if (bytes[index] === 10) assert.equal(bytes[index - 1], 13, `${path} must use CRLF`);
  }
  const script = bytes.toString('ascii');
  const labels = new Set([...script.matchAll(/^:([A-Za-z0-9_]+)\r?$/gm)].map(match => match[1].toLowerCase()));
  for (const match of script.matchAll(/\bgoto\s+([A-Za-z0-9_]+)/gi)) {
    assert(labels.has(match[1].toLowerCase()), `${path}: undefined label ${match[1]}`);
  }
}

console.log(`PASS: ${version} identity, data invariants, upgrade safety and release gate`);
