import assert from 'node:assert/strict'; import fs from 'node:fs'; import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8'); const v=readVersionContract(); const status=JSON.parse(read('version.json'));
assert.equal(v.productVersion,'4.3.0-RC.2'); assert.equal(v.schemaVersion,13);
assert.equal(status.stableEligible,false); assert.equal(status.fullPlatformGate,'PENDING_ENVIRONMENT');
const gate=read('RELEASE_GATE_v4.3.0-RC.2.md'); assert(gate.includes('RC.2 compile-integration source gate: **PASS**')); assert(gate.includes('SOURCE_READY_DEVICE_PENDING')); assert(gate.includes('Stable promotion: **NOT AUTHORIZED**'));
console.log('PASS: RC-06 Release Candidate source freeze contract is present while physical/Stable gates remain blocked');
