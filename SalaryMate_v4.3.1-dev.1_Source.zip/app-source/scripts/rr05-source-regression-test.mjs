import assert from 'node:assert/strict';
import fs from 'node:fs'; const v=JSON.parse(fs.readFileSync('version.json','utf8'));
for(const g of ['PAX-06_SOURCE_FREEZE','RI-06_SOURCE_REGRESSION','RR-01_EVIDENCE_COMPLETENESS','RR-04_RC_PROMOTION_BLOCKER']) assert(v.completedGates.includes(g),`Missing completed gate ${g}`);
assert.equal(v.schemaVersion,13); assert.match(v.productVersion,/^4\.3\.0-(?:dev|RC)\.\d+$/);
console.log(`PASS: RR-05 ${v.productVersion} inherits frozen PAX/RI contracts and remains Schema 13`);
