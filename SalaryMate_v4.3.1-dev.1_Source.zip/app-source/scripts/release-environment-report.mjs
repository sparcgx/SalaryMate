import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { readVersionContract, projectRoot } from './version-contract.mjs';

const require = createRequire(import.meta.url);
const v = readVersionContract(projectRoot);
const exists = p => Boolean(p && fs.existsSync(p));
const command = (name, args=['--version']) => {
  const r = spawnSync(name, args, { encoding:'utf8' });
  return { available:r.status === 0, exitCode:r.status, output:`${r.stdout||''}${r.stderr||''}`.trim().split(/\r?\n/)[0]||'' };
};
const moduleAvailable = name => { try { require.resolve(name); return true; } catch { return false; } };
const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || '';
const adbName = process.platform === 'win32' ? 'adb.exe' : 'adb';
const gradleName = process.platform === 'win32' ? 'gradlew.bat' : 'gradlew';
const xcode = process.platform === 'darwin' ? command('xcodebuild',['-version']) : {available:false,exitCode:null,output:'not macOS'};
const report = {
  productVersion:v.productVersion, releaseVersion:v.releaseVersion, schemaVersion:v.schemaVersion,
  platform:process.platform, arch:process.arch, node:process.version,
  tooling:{
    esbuild:moduleAvailable('esbuild'), xcodeNpmModule:moduleAvailable('xcode'),
    androidSdk:exists(sdk), adb:exists(path.join(sdk,'platform-tools',adbName)),
    androidGradleWrapper:exists(path.join(projectRoot,'android',gradleName)),
    xcodebuild:xcode.available, xcodeVersion:xcode.output,
    java:command('java',['-version'])
  }
};
report.productionBuild = report.tooling.esbuild ? 'READY_TO_RUN' : 'PENDING_ENVIRONMENT';
report.androidBuildDevice = report.tooling.androidSdk && report.tooling.adb && report.tooling.androidGradleWrapper ? 'READY_TO_RUN' : 'PENDING_ENVIRONMENT';
report.iosBuildDevice = process.platform === 'darwin' && report.tooling.xcodebuild && report.tooling.xcodeNpmModule ? 'READY_TO_RUN' : 'PENDING_ENVIRONMENT';
report.result = [report.productionBuild,report.androidBuildDevice,report.iosBuildDevice].every(x=>x==='READY_TO_RUN') ? 'READY' : 'PENDING_ENVIRONMENT';
const target = path.join(projectRoot,'release-evidence',`v${v.productVersion}_Release_Environment.json`);
fs.mkdirSync(path.dirname(target),{recursive:true});
fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
console.log(`Environment evidence: ${target}`);
