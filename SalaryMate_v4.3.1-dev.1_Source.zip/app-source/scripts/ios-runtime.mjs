export function chooseSimulator(runtimes, deviceTypes) {
  const runtime = runtimes.filter(r => r.isAvailable && r.identifier.includes('.iOS-') && Number(r.version.split('.')[0]) >= 16)
    .sort((a, b) => b.version.localeCompare(a.version, undefined, { numeric: true }))[0];
  const min = runtime?.supportedDeviceTypes?.map(d => d.identifier);
  const devices = deviceTypes.filter(d => d.name.startsWith('iPhone') && (!min || min.includes(d.identifier)));
  const device = devices.find(d => d.name === 'iPhone 15') ?? devices.at(-1);
  if (!runtime || !device) throw new Error('找不到可用的 iOS 16+ 模擬器；請到 Xcode Settings > Components 安裝 iOS runtime');
  return { runtime, device };
}

