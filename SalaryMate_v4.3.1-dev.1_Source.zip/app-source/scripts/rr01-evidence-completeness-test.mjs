import assert from 'node:assert/strict';
import fs from 'node:fs';
import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8'); const exists=p=>fs.existsSync(p); const v=readVersionContract();
for (const p of ['REAL_DEVICE_ACCEPTANCE_v4.3.0-dev.4.md','RELEASE_GATE_v4.3.0-dev.4.md','FORMAL_RELEASE_EVIDENCE.md','ANDROID_RELEASE_SIGNING.md']) assert(exists(p),`Missing ${p}`);
const acceptance=read('REAL_DEVICE_ACCEPTANCE_v4.3.0-dev.4.md');
for (const marker of ['Real device: NOT_RUN','Upgrade / data preservation: NOT_RUN','Backup / restore physical round-trip: NOT_RUN','Lifecycle / background / foreground: NOT_RUN','Long session: NOT_RUN','Wrong-company Write = 0','Duplicate Commit = 0']) assert(acceptance.includes(marker),`Missing acceptance marker: ${marker}`);
assert.equal(v.schemaVersion,13);
console.log('PASS: RR-01 RC evidence completeness contract is present and defaults to NOT_RUN/HOLD');
