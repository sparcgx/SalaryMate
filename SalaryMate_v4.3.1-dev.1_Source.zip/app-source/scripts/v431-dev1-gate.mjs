import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { readVersionContract } from './version-contract.mjs';
import { createBackupService } from '../src/native-backup.mjs';
import { inspectBackupCandidate } from '../src/backup-import.mjs';

const v = readVersionContract();
assert.equal(v.productVersion, '4.3.1-dev.1');
assert.equal(v.releaseVersion, '4.3.1');
assert.equal(v.androidVersionCode, 20);
assert.equal(v.buildNumber, 8);
assert.equal(v.schemaVersion, 13);
assert.equal(v.channel, 'dev');
const read = path => fs.readFileSync(path, 'utf8');
const manifest = JSON.parse(read('SOURCE_MANIFEST.json'));
for (const path of [
  'src/storage.js', 'src/snapshot-store.mjs', 'src/backup-crypto.mjs',
  'android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt',
  'android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt'
]) {
  const expected = manifest.entries.find(row => row.path === path)?.sha256;
  assert(expected, `Frozen source manifest missing ${path}`);
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex'), expected, `Frozen core changed: ${path}`);
}
assert(read('android/app/src/main/java/com/salarymate/personal/ui/NativeHomeScreen.kt').includes('onOpenHealth'));
assert(read('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt').includes('import com.salarymate.personal.data.NativeSnapshot'));
assert(read('android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt').includes('internal fun PayrollIdentityBox') || read('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt').includes('PayrollIdentityBox'));
assert(!read('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt').includes('ShellDestination.Quick'));
assert(!read('src/index.html').includes('>快速登記</button>'));
const payload = JSON.stringify({ schemaVersion: 13, companies: [], records: [], overtimeLogs: [] });
let exported;
const service = createBackupService(null, null, null, null, v.productVersion, undefined, {
  async save(request) { exported = request; return { fileName: request.fileName }; }
});
await service.savePlain(payload);
assert.equal(exported.data, payload);
assert(exported.fileName.endsWith('.salarymate'));
assert.equal(inspectBackupCandidate(exported.fileName, exported.data, service).summary.includes('公司'), true);
console.log('PASS: dev Identity, frozen core hash, quick-entry navigation removal, password-free export and import validation');
