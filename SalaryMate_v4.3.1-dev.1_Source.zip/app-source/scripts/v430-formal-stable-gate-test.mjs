import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';

const read = p => fs.readFileSync(p, 'utf8');
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const v = JSON.parse(read('version.json'));

assert.equal(v.productVersion, '4.3.0');
assert.equal(v.releaseVersion, '4.3.0');
assert.equal(v.androidVersionCode, 19);
assert.equal(v.buildNumber, 7);
assert.equal(v.schemaVersion, 13);
assert.equal(v.channel, 'stable');
assert.equal(v.status, 'formal-release-stable-freeze');
assert.equal(v.fullPlatformGate, 'PASS');
assert.equal(v.stableEligible, true);
assert.equal(v.rcPromotionEligible, true);
assert.equal(v.physicalDeviceQA, 'PASS');

const expected = new Map([
  ['android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt', '9a4585a2589568edc862ef1482712e3765e61c2ba732253bcdcc3bf444a27459'],
  ['android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt', 'b80dbbe1db8d1f610f425849e8a24a6b61cfb6d206b77bbf7210964d18852ce2'],
  ['src/storage.js', '7a7b7f1294e0264d065bab596c62e682066c229aa4771e48b75bae62b403b343'],
  ['src/backup-crypto.mjs', '4203eb2c69014a55300903941f7049083739b05c7dfc0fd6c56a8e1fc3dc9b2e'],
  ['android/app/src/main/java/com/salarymate/personal/backup/NativeBackupCrypto.kt', 'f606d2a531137289ebf434acda08bf2a46c321887fc88aa41781c40c2334925b']
]);
for (const [path, digest] of expected) assert.equal(sha(path), digest, `Frozen core changed: ${path}`);

const payroll = read('android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt');
const quick = read('android/app/src/main/java/com/salarymate/personal/ui/NativeQuickEntryScreen.kt');
const shell = read('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt');
assert(payroll.includes('NativeErrorCard(loadState.message, onOpenHealth = { onOpenWeb("dashboard", "data-health") })'));
assert(quick.includes('NativeErrorCard(loadState.message, onOpenHealth = { onOpenWeb("dashboard", "data-health") })'));
assert(payroll.includes('internal fun PayrollIdentityBox(title: String, detail: String)'));
assert(shell.includes('import com.salarymate.personal.data.NativeSnapshot'));

const gate = read('RELEASE_GATE_v4.3.0.md');
assert(gate.includes('PASS / STABLE FREEZE AUTHORIZED'));
assert(gate.includes('Wrong-company Write = 0'));
assert(gate.includes('Historical OT = 1,373'));
assert(gate.includes('Year-End Runtime Golden = 153,900'));

console.log('PASS: v4.3.0 Formal Release identity, RC.2 compile fixes, frozen core hashes, physical QA promotion state and stable gate');
