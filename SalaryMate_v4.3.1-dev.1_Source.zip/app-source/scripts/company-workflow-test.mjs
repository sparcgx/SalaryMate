import assert from 'node:assert/strict';
import fs from 'node:fs';

const app = fs.readFileSync('src/app.js', 'utf8');
const index = fs.readFileSync('src/index.html', 'utf8');
const styles = fs.readFileSync('src/styles.css', 'utf8');
const shell = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt', 'utf8');
const payroll = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt', 'utf8');
const quick = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/NativeQuickEntryScreen.kt', 'utf8');
const repo = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt', 'utf8');
const models = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt', 'utf8');

for (const label of ['首頁','快速登記','薪資','年度總覽','公司管理','設定']) assert(index.includes(`>${label}</button>`) || shell.includes(`"${label}"`), `missing root nav ${label}`);
assert(app.includes("const PRIMARY_TABS = Object.freeze(['dashboard', 'overtime', 'records', 'tax', 'companies'])"));
assert(app.includes("const currentCompany = () => state.companies.find((company) => company.isCurrent) || null;"));
assert(app.includes('需要選擇目前公司'));
assert(!app.slice(app.indexOf('const renderFilters = () =>'), app.indexOf('const renderBarChart = () =>')).includes('state.companies[0].id'));

assert(app.includes('payrollStep: 1'));
assert(app.includes("const payrollStepLabel = (step) => ['月份', '本月資料', '確認']"));
for (const n of ['data-payroll-step="1"','data-payroll-step="2"','data-payroll-step="3"']) assert(app.includes(n));
assert(app.includes("action === 'payroll-next'"));
assert(app.includes("action === 'payroll-back'"));
assert(app.includes("draft.companyId !== currentCompany()?.id"));
assert(app.includes("recordExists(draft, '')"));
assert(app.includes('draft.customDeductions = [];'));
assert(app.includes("filter((item) => item.sourceType === 'company-fixed')"));
assert(app.includes('draft.overtime = overtimeForSalaryMonth'));
assert(styles.includes('CM-05 | Company Workflow & 3-step Payroll'));

const webRecordEditor = app.slice(app.indexOf('const recordEditorFormHtml ='), app.indexOf('const payrollStepLabel ='));
const webOvertimeForm = app.slice(app.indexOf('const overtimeFormHtml ='), app.indexOf('const collectOvertimeDraft ='));
const webLeaveForm = app.slice(app.indexOf('const leaveFormHtml ='), app.indexOf('const collectLeaveDraft ='));
for (const [label, source] of [['payroll editor', webRecordEditor], ['overtime', webOvertimeForm], ['leave', webLeaveForm]]) {
  assert(!source.includes('select class="field-select" name="companyId"'), `${label} still exposes an independent company selector`);
  assert(source.includes('type="hidden" name="companyId"'), `${label} must preserve company scope as a hidden identity field`);
}
assert(app.includes("if (!log && !currentCompany()) { toast('請先在公司管理設為目前公司'"));

assert(app.includes('const dialogHasUnsavedChanges = () =>'));
assert(app.includes("尚有未儲存變更。要放棄變更嗎？"));
assert(app.includes('beforeunload'));
assert(app.includes("window.addEventListener('popstate'"));
assert(app.includes('history.pushState({ salaryMateTab: nextTab }'));
assert(app.includes('目前有尚未儲存的變更，請先儲存或取消'));
assert(app.includes('const assertDraftScope ='));
assert(app.includes('const currentHistoryState = () =>'));
assert(app.includes('ui.recordDraft = null;'));
assert(app.includes('ui.overtimeDraft = null;'));
assert(app.includes('invalidateCalculationCache();'));

for (const label of ['Home("首頁"','Quick("快速登記"','Payroll("薪資"','Annual("年度總覽"','Company("公司管理"','Settings("設定"']) assert(shell.includes(label));
assert(shell.includes('ShellDestination.Annual -> AnnualOverviewEntry'));
assert(shell.includes('BackHandler(enabled = selected != ShellDestination.Home)'));
assert(payroll.includes('第 $step 步，共 3 步'));
assert(payroll.includes('1｜月份'));
assert(payroll.includes('2｜本月資料'));
assert(payroll.includes('3｜確認'));
assert(payroll.includes('snapshot.currentCompanyId != liveDraft.companyId'));
assert(payroll.includes('放棄未儲存薪資草稿？'));
assert(payroll.includes('BackHandler(enabled = activeDraft != null && draftDirty)'));
assert(payroll.includes('val isDirty = liveDraft != draft'));
assert(!payroll.includes('label = "公司"'));
assert(shell.includes('NativeLoadState.Invalid'));
assert(shell.includes('系統不會自動改用第一家公司'));
assert(quick.includes('is NativeLoadState.Invalid'));
assert(payroll.includes('is NativeLoadState.Invalid'));
assert(quick.includes('val initialCompany = requireNotNull(snapshot.currentCompany)'));
assert(!quick.includes('label = "公司"'));
assert(repo.includes('val currentCompany = companies.firstOrNull { it.isCurrent }'));
assert(!repo.includes('val currentCompany = companies.firstOrNull { it.isCurrent } ?: companies.firstOrNull()'));
assert(repo.includes('目前公司尚未設定。請先到公司管理設為目前公司，再建立薪資。'));
assert(models.includes('?: companies.firstOrNull { it.isCurrent }'));
assert(!models.includes('?: companies.firstOrNull()'), 'NativeSnapshot.currentCompany must fail closed instead of selecting the first company');

assert(app.includes('const recordExists = (draft, exceptId = \'\') => state.records.some((record) => record.id !== exceptId && record.companyId === draft.companyId'));
console.log('PASS: CM-05 workflow uses one current-company context, 3-step payroll creation, dirty guard and cross-platform root navigation');
