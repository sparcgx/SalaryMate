import assert from 'node:assert/strict';
import fs from 'node:fs';
import { readVersionContract } from './version-contract.mjs';

const read = path => fs.readFileSync(path, 'utf8');
const json = path => JSON.parse(read(path));
const version = readVersionContract();
const status = json('version.json');
const pack = json('package.json');
const repo = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt');
const models = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt');
const math = read('android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt');
const app = read('src/app.js');
const storage = read('src/storage.js');
const snapshot = read('src/snapshot-store.mjs');
const backupCrypto = read('src/backup-crypto.mjs');
const runtimeSmoke = read('tests/runtime-smoke.mjs');
const gateDoc = read('RELEASE_GATE_v4.3.0-dev.1.md');
const manifest = json('SOURCE_MANIFEST.json');

assert.equal(version.releaseVersion, '4.3.0');
assert.equal(version.schemaVersion, 13);
assert(version.completedGates.includes('CM-06_SOURCE_FREEZE'), 'Current line must descend from the CM-06 dev.1 freeze');
assert.equal(status.schemaVersion, 13);
assert.equal(status.stableEligible, false);
assert(Array.isArray(manifest.files), 'Source manifest files[] missing');
assert(manifest.files.length >= 200, 'Source manifest unexpectedly incomplete');
for (const gate of [
  'CM-01_TARGETED',
  'CM-02_IMPLEMENTATION_REGRESSION',
  'CM-03_IMPLEMENTATION_REGRESSION',
  'CM-04_IMPLEMENTATION_REGRESSION',
  'CM-05_IMPLEMENTATION_REGRESSION',
  'CM-06_SOURCE_FREEZE'
]) assert(status.completedGates.includes(gate), `Missing completed gate ${gate}`);

for (const script of ['test:cm02','test:cm03','test:cm04','test:cm05','test:cm06']) {
  assert(pack.scripts[script], `Missing npm script ${script}`);
}

// Frozen calculation and persistence contracts.
assert(math.includes('gross > 86_001L'));
assert(math.includes('first * 1.34 + later * 1.67'));
assert(math.includes('first * 1.34 + middle * 1.67 + later * 2.67'));
assert(math.includes('safeHours * safeRate * 2.5'));
assert(app.includes("SCHEMA_VERSION = 13"));
assert(app.includes("'salarymate_v310_state'"));
assert(app.includes("總金額 > 86,001 才預扣 5%"));
assert(app.includes("1 / 1.34 / 1.67 / 2 / 2.67；春節 2.5"));
assert(runtimeSmoke.includes("'$153,900'" ) || runtimeSmoke.includes("'$153,900"));
assert(storage.includes('SalaryMateStorage'));
assert(snapshot.includes('ORDER BY id DESC LIMIT 3') || snapshot.includes('LIMIT 3'));
assert(backupCrypto.includes('SalaryMate|encrypted-backup|v1'));

// No parallel canonical data stores.
for (const marker of [
  'CREATE TABLE IF NOT EXISTS overtime',
  'CREATE TABLE IF NOT EXISTS leave',
  'CREATE TABLE IF NOT EXISTS payroll',
  'CREATE TABLE IF NOT EXISTS salary',
  'CREATE TABLE IF NOT EXISTS backup'
]) assert(!repo.includes(marker), `Unexpected parallel store marker: ${marker}`);

// Current company must never silently fall back to the first company.
assert(!repo.includes('?: companies.firstOrNull()'));
assert(repo.includes('companies.firstOrNull { it.optBoolean("isCurrent", false) }'));
assert(!models.includes('?: companies.firstOrNull()'), 'NativeSnapshot.currentCompany must fail closed');

// Freeze evidence must explicitly preserve the unresolved platform/tooling gates.
assert(gateDoc.includes('DEVELOPMENT SOURCE FREEZE'));
assert(gateDoc.includes('PENDING_ENVIRONMENT'));
assert(gateDoc.includes('RC / Stable promotion: NOT AUTHORIZED'));

console.log('PASS: CM-06 development source freeze preserves version, Schema 13, payroll/tax/OT, storage/backup, current-company and release-governance contracts');
