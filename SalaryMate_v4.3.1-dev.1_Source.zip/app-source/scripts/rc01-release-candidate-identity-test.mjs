import assert from 'node:assert/strict';
import fs from 'node:fs'; import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8'); const v=readVersionContract();
assert.equal(v.productVersion,'4.3.0-RC.2'); assert.equal(v.releaseVersion,'4.3.0'); assert.equal(v.androidVersionCode,19); assert.equal(v.buildNumber,7); assert.equal(v.schemaVersion,13);
assert.equal(JSON.parse(read('version.json')).channel,'release-candidate');
assert(read('android/app/build.gradle').includes('versionCode 19')); assert(read('android/app/build.gradle').includes('versionName "4.3.0-RC.2"'));
assert(read('ios/App/App.xcodeproj/project.pbxproj').includes('CURRENT_PROJECT_VERSION = 7;'));
assert(read('src/app.js').includes("APP_VERSION = '4.3.0-RC.2'"));
console.log('PASS: RC-01 Release Candidate identity is unified at 4.3.0-RC.2 / Android 19 / iOS build 7 / Schema 13');
