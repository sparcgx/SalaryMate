import assert from 'node:assert/strict'; import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8'); const v=JSON.parse(read('version.json'));
const a=read('REAL_DEVICE_ACCEPTANCE_v4.3.0-RC.2.md');
for(const m of ['Physical execution: **NOT_RUN**','Real device: NOT_RUN','Upgrade / data preservation: NOT_RUN','Backup / restore physical round-trip: NOT_RUN','Lifecycle / background / foreground: NOT_RUN','Long session: NOT_RUN','Wrong-company Write = 0','Duplicate Commit = 0']) assert(a.includes(m),`Missing ${m}`);
assert.equal(v.stableEligible,false); assert.equal(v.rcPromotionEligible,false);
console.log('PASS: RC-03 physical evidence remains fail-closed; source freeze cannot imply Stable eligibility');
