import assert from 'node:assert/strict';
import fs from 'node:fs';
import { readVersionContract } from './version-contract.mjs';

const read = path => fs.readFileSync(path, 'utf8');
const json = path => JSON.parse(read(path));
const version = readVersionContract();
const status = json('version.json');
const pack = json('package.json');
const math = read('android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt');
const repo = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt');
const models = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt');
const app = read('src/app.js');
const storage = read('src/storage.js');
const snapshot = read('src/snapshot-store.mjs');
const backupCrypto = read('src/backup-crypto.mjs');
const runtimeSmoke = read('tests/runtime-smoke.mjs');
const historicalOt = read('release-evidence/CM06_HISTORICAL_OT_EVIDENCE.txt');
const cm06 = read('RELEASE_GATE_v4.3.0-dev.1.md');
const dev2Gate = read('RELEASE_GATE_v4.3.0-dev.2.md');

// Identity and freeze lineage.
assert.equal(version.releaseVersion, '4.3.0');
assert.equal(version.schemaVersion, 13);
assert(status.completedGates.includes('PAX-06_SOURCE_FREEZE'));
assert.equal(status.rcPromotionEligible, false);
assert.equal(status.stableEligible, false);
for (const gate of [
  'CM-06_SOURCE_FREEZE',
  'PAX-01_IMPLEMENTATION_REGRESSION',
  'PAX-02_IMPLEMENTATION_REGRESSION',
  'PAX-03_IMPLEMENTATION_REGRESSION',
  'PAX-04_IMPLEMENTATION_REGRESSION',
  'PAX-05_IMPLEMENTATION_REGRESSION',
  'PAX-06_SOURCE_FREEZE'
]) assert(status.completedGates.includes(gate), `Missing completed gate ${gate}`);
for (const script of ['test:pax01','test:pax02','test:pax03','test:pax04','test:pax05','test:pax06']) {
  assert(pack.scripts[script], `Missing npm script ${script}`);
}

// Frozen business calculations and Golden evidence.
assert(math.includes('gross > 86_001L'));
assert(math.includes('first * 1.34 + later * 1.67'));
assert(math.includes('first * 1.34 + middle * 1.67 + later * 2.67'));
assert(math.includes('safeHours * safeRate * 2.5'));
assert(runtimeSmoke.includes('$153,900'));
assert(app.includes('總金額 > 86,001 才預扣 5%'));
assert(app.includes('1 / 1.34 / 1.67 / 2 / 2.67；春節 2.5'));

// Historical / snapshot / backup contracts.
assert(historicalOt.includes('914'));
assert(historicalOt.includes('459'));
assert(historicalOt.includes('1,373'));
assert(cm06.includes('Combined compound identities: `1,373 unique`'));
assert(snapshot.includes('ORDER BY id DESC LIMIT 3') || snapshot.includes('LIMIT 3'));
assert(backupCrypto.includes('SalaryMate|encrypted-backup|v1'));
assert(storage.includes('SalaryMateStorage'));

// Single canonical stores / schema only.
assert(app.includes('SCHEMA_VERSION = 13'));
assert(repo.includes('schema == 13'));
for (const marker of [
  'CREATE TABLE IF NOT EXISTS overtime',
  'CREATE TABLE IF NOT EXISTS leave',
  'CREATE TABLE IF NOT EXISTS payroll',
  'CREATE TABLE IF NOT EXISTS salary',
  'CREATE TABLE IF NOT EXISTS backup'
]) assert(!repo.includes(marker), `Unexpected parallel store marker: ${marker}`);

// Current-company, draft, selected-entity, stale async and duplicate-submit safety.
assert(!repo.includes('?: companies.firstOrNull()'));
assert(!models.includes('?: companies.firstOrNull()'));
assert(app.includes('draftScope: null'));
assert(app.includes('selectedEntityScope: null'));
assert(app.includes("console.error('DRAFT_SCOPE_MISMATCH'"));
assert(app.includes("console.error('STALE_CONTEXT_RESULT'"));
assert(app.includes("console.warn('DUPLICATE_SUBMIT_BLOCKED'"));
assert(app.includes('const activeOperationLocks = new Set()'));
assert(app.includes('const recentOperationLocks = new Map()'));
assert(app.includes('if (hasDirtyDraft())'));
assert(app.includes("window.addEventListener('popstate'"));
assert(app.includes('resetTransientUiAfterRestore()'));

// Freeze governance: dev.2 may freeze source, but may not claim platform/RC/Stable readiness.
assert(dev2Gate.includes('DEVELOPMENT SOURCE FREEZE'));
assert(dev2Gate.includes('PENDING_ENVIRONMENT'));
assert(dev2Gate.includes('RC / Stable promotion: NOT AUTHORIZED'));
assert.equal(status.fullPlatformGate, 'PENDING_ENVIRONMENT');

console.log('PASS: PAX-06 full dev.2 freeze preserves PAX-01..05, Schema 13, payroll/tax/OT/year-end, historical OT, backup/snapshot and operational-safety contracts without claiming RC readiness');
