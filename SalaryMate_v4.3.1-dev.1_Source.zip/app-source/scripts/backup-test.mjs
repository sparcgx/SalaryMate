import assert from 'node:assert/strict';
import { createBackupService } from '../src/native-backup.mjs';
import { readVersionContract } from './version-contract.mjs';

const version = readVersionContract();
const payload = JSON.stringify({ schemaVersion: 13, companies: [], records: [], overtimeLogs: [], note: '繁體中文 100.111' });
const password = 'correct horse battery';
let cacheData;
let writes = 0;
let shares = 0;
let saves = 0;
let writeError = false;
let mismatch = false;
let shareCancelled = false;
let saveCancelled = false;
let changedExtension = false;
let savedData;

const codedError = (message, code) => Object.assign(new Error(message), { code });
const crypto = {
  isEncryptedBackup: text => text.startsWith('encrypted:'),
  inspectEncryptedBackup: text => {
    if (!text.startsWith('encrypted:')) throw new Error('format');
    return { version: 1 };
  },
  async encryptBackup(text, secret) {
    if (secret.length < 12) throw codedError('short', 'PASSWORD_TOO_SHORT');
    return `encrypted:${secret}:${text}`;
  },
  async decryptBackup(text, secret) {
    const prefix = `encrypted:${secret}:`;
    if (!text.startsWith(prefix)) throw new Error('password');
    return text.slice(prefix.length);
  }
};
const fs = {
  async writeFile(options) {
    if (writeError) throw new Error('disk');
    cacheData = options.data;
    writes++;
    assert.equal(options.directory, 'CACHE');
    assert(options.path.endsWith('.salarymate'));
  },
  async readFile() { return { data: mismatch ? 'broken' : cacheData }; },
  async getUri(options) { return { uri: `file:///private/cache/${options.path}` }; }
};
const share = {
  async share(options) {
    shares++;
    assert(options.files[0].endsWith('.salarymate'));
    assert(options.title.endsWith('.salarymate'));
    assert.equal(options.dialogTitle, '分享加密薪資備份');
    if (shareCancelled) throw new Error('cancelled');
  }
};
const fileSaver = {
  async save(options) {
    saves++;
    assert(options.fileName.endsWith('.salarymate'));
    assert.equal(options.mimeType, 'application/octet-stream');
    savedData = options.data;
    if (saveCancelled) throw codedError('cancelled', 'SAVE_CANCELLED');
    return { fileName: changedExtension ? options.fileName.replace(/\.salarymate$/, '.file') : options.fileName };
  }
};

const service = createBackupService(fs, share, 'CACHE', 'utf8', version.productVersion, crypto, fileSaver);

const saved = await service.saveEncrypted(payload, password);
assert(saved.fileName.endsWith('.salarymate'));
assert.notEqual(savedData, payload);
assert.equal(await service.decrypt(savedData, password), payload);
assert.equal(saves, 1);

await assert.rejects(service.saveEncrypted('{bad', password));
await assert.rejects(service.saveEncrypted(payload, 'short'), error => error.code === 'PASSWORD_TOO_SHORT');
assert.equal(saves, 1, 'invalid input must never open the system document picker');

saveCancelled = true;
await assert.rejects(service.saveEncrypted(payload, password), error => error.code === 'SAVE_CANCELLED');
saveCancelled = false;
await service.saveEncrypted(payload, password);
assert.equal(saves, 3, 'save cancellation must release the exclusive lock');

changedExtension = true;
await assert.rejects(service.saveEncrypted(payload, password), error => error.code === 'SAVE_EXTENSION_CHANGED');
changedExtension = false;
await service.saveEncrypted(payload, password);
assert.equal(saves, 5, 'extension rejection must release the exclusive lock');

const noSaver = createBackupService(fs, share, 'CACHE', 'utf8', version.productVersion, crypto);
await assert.rejects(noSaver.saveEncrypted(payload, password), error => error.code === 'SAVE_UNAVAILABLE');

await service.shareEncrypted(payload, password);
assert.notEqual(cacheData, payload);
assert.equal(await service.decrypt(cacheData, password), payload);
assert.equal(shares, 1);
await assert.rejects(service.shareEncrypted('{bad', password));
assert.equal(writes, 1);
await assert.rejects(service.shareEncrypted(payload, 'short'));
assert.equal(writes, 1);
writeError = true;
await assert.rejects(service.shareEncrypted(payload, password), /disk/);
assert.equal(shares, 1);
writeError = false;
mismatch = true;
await assert.rejects(service.shareEncrypted(payload, password), /驗證/);
assert.equal(shares, 1);
mismatch = false;
shareCancelled = true;
await assert.rejects(service.shareEncrypted(payload, password), /cancelled/);
shareCancelled = false;
await service.shareEncrypted(payload, password);
assert.equal(shares, 3, 'share cancellation must release the exclusive lock');

console.log('PASS: native Save As preserves .salarymate, verifies encryption, and releases save/share locks after failures');
