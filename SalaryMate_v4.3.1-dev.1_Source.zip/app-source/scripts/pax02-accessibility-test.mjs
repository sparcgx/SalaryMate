import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { readVersionContract } from './version-contract.mjs';

const read = (path) => fs.readFileSync(path, 'utf8');
const version = readVersionContract();
const index = read('src/index.html');
const css = read('src/styles.css');
const app = read('src/app.js');
const shell = read('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt');
const home = read('android/app/src/main/java/com/salarymate/personal/ui/NativeHomeScreen.kt');
const quick = read('android/app/src/main/java/com/salarymate/personal/ui/NativeQuickEntryScreen.kt');
const company = read('android/app/src/main/java/com/salarymate/personal/ui/NativeCompanyManagementScreen.kt');
const math = read('android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt');
const repo = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt');

assert.equal(version.releaseVersion, '4.3.0');
assert(version.completedGates.includes('PAX-02_IMPLEMENTATION_REGRESSION'));
assert.equal(version.schemaVersion, 13);
new vm.Script(app);

// Web keyboard / focus / touch contract.
assert(index.includes('class="skip-link" href="#mainContent"'));
assert(index.includes('<main id="mainContent" tabindex="-1" aria-label="主要內容">'));
assert(index.includes('for="companyFilter">目前公司</label>'));
assert(index.includes('class="menu-file-trigger" role="button" tabindex="0"'));
assert(index.includes('aria-label="選擇 JSON 備份檔" tabindex="-1"'));
assert(app.includes('const FOCUSABLE_SELECTOR ='));
assert(app.includes('const enhanceFormAccessibility ='));
assert(app.includes("control.setAttribute('aria-required', 'true')"));
assert(app.includes("control.setAttribute('aria-describedby'"));
assert(app.includes("control.setAttribute('aria-invalid', 'true')"));
assert(app.includes('const focusPageHeading = () =>'));
assert(app.includes('if (changed) focusPageHeading();'));
assert(app.includes('const trapDialogFocus = (event) =>'));
assert(app.includes("appDialog.addEventListener('cancel'"));
assert(app.includes("if (event.key === 'Escape')"));
assert(app.includes('requestCloseDialog();'));
assert(app.includes("['ArrowLeft','ArrowRight','ArrowUp','ArrowDown']"));
assert(app.includes('aria-current="step"'));
assert(app.includes('第 ${step} 步，共 3 步'));

assert(css.includes('PAX-02 Accessibility / Keyboard / Touch Hardening'));
assert(css.includes('.skip-link:focus-visible'));
assert(css.includes('[aria-invalid="true"]'));
assert(css.includes('@media (pointer: coarse)'));
assert(css.includes('min-height: 44px'));
assert(css.includes('min-height: 48px'));
assert(css.includes('@media (prefers-reduced-motion: reduce)'));
assert(css.includes('body[data-ui-mode="large"] .summary-row'));

// Android semantics: headings, custom click roles, selected-state announcement, decorative short icon suppression.
assert(shell.includes('Modifier.semantics { heading() }'));
assert(shell.includes('Modifier.clearAndSetSemantics { }'));
assert(home.includes('semantics(mergeDescendants = true) { role = Role.Button }'));
assert(quick.includes('stateDescription = if (option.second == selectedLabel) "已選取" else "未選取"'));
assert(company.includes('Modifier.semantics { heading() }'));

// Frozen domain signatures remain present.
assert(math.includes('gross > 86_001L'));
assert(math.includes('safeHours * safeRate * 2.5'));
assert(repo.includes('目前公司尚未設定。請先到公司管理設為目前公司，再建立薪資。'));
console.log('PASS: PAX-02 keyboard focus, dialog trap, form semantics, touch targets, large text and Android semantics contract');
