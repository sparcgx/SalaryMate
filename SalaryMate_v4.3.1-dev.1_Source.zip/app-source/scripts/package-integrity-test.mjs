import assert from 'node:assert/strict';
import fs from 'node:fs';

const required = [
  'version.json',
  'scripts/version-contract.mjs',
  'scripts/sync-version.mjs',
  'scripts/version-drift-test.mjs',
  'tests/runtime-smoke.mjs',
  'src/backup-crypto.mjs',
  'src/backup-import.mjs',
  'src/native-security.mjs',
  'src/icons/app-icon.svg',
  'src/icons/icon-192.png',
  'src/icons/icon-512.png',
  'src/icons/icon-maskable-512.png',
  'android/app/src/main/java/com/salarymate/personal/DeviceSecurityPlugin.java',
  'android/app/src/main/java/com/salarymate/personal/BackupFilePlugin.java',
  'android/app/src/main/java/com/salarymate/personal/MainActivity.java',
  'android/app/src/main/java/com/salarymate/personal/ComposeShellActivity.kt',
  'android/app/src/main/java/com/salarymate/personal/NativeSecurityController.kt',
  'android/app/src/main/java/com/salarymate/personal/backup/NativeBackupCrypto.kt',
  'android/app/src/main/java/com/salarymate/personal/backup/NativeBackupService.kt',
  'android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt',
  'android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt',
  'android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt',
  'android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt',
  'android/app/src/main/java/com/salarymate/personal/ui/NativeHomeScreen.kt',
  'android/app/src/main/java/com/salarymate/personal/ui/NativeQuickEntryScreen.kt',
  'android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt',
  'android/app/src/main/java/com/salarymate/personal/ui/NativeSettingsScreen.kt',
  'android/app/src/main/java/com/salarymate/personal/ui/NativeCompanyManagementScreen.kt',
  'android/app/src/main/java/com/salarymate/personal/ui/SalaryMateTheme.kt',
  'android/app/src/main/java/com/salarymate/personal/ui/SalaryMateTypography.kt',
  'android/app/src/main/res/xml/backup_rules.xml',
  'android/app/src/main/res/xml/data_extraction_rules.xml',
  'android/app/src/main/res/xml/file_paths.xml',
  'android/app/src/debug/res/values/strings.xml',
  'android/app/src/androidTest/java/com/salarymate/personal/SalaryMateInstrumentedTest.java',
  'android/app/src/androidTest/java/com/salarymate/personal/NativeBackupCryptoInstrumentedTest.kt',
  'android/app/src/test/java/com/salarymate/personal/SalaryMateUnitTest.java',
  'android/app/src/test/java/com/salarymate/personal/NativePayrollMathTest.kt',
  'ANDROID_RELEASE_SIGNING.md',
  'BUILD_SIGNED_ANDROID_WINDOWS.ps1',
  'BUILD_COMPOSE_DEBUG_WINDOWS.cmd',
  'INSTALL_COMPOSE_DEBUG_WINDOWS.cmd',
  'RUN_RC2_DEVICE_GATE_WINDOWS.cmd',
  'RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd',
  'MIGRATION_R7_TO_RC3.md',
  'PLAY_CONSOLE_CHECKLIST.md',
  'PLAY_STORE_LISTING_zh-TW.md',
  'PRIVACY_POLICY_zh-TW.md',
  'BASELINE_R7_RELEASE_GATE.md',
  'BASELINE_R7_SHA256.txt',
  'BASELINE_RC2_RELEASE_GATE.md',
  'ROADMAP_v4_to_v5.md',
  'RELEASE_GATE_v4.0.0-rc.3.md',
  'RELEASE_GATE_v4.1.0-dev.1.md',
  'RELEASE_GATE_v4.1.0-dev.3.md',
  'RELEASE_GATE_v4.1.0-dev.4.md',
  'RELEASE_GATE_v4.1.0-RC.1.md',
  'RELEASE_GATE_v4.1.0.md',
  'ANDROID_COMPOSE_ACCEPTANCE.md',
  'ANDROID_RC1_ACCEPTANCE.md',
  'ANDROID_v4.1.0_ACCEPTANCE.md',
  'FORMAL_RELEASE_EVIDENCE.md',
  'WINDOWS_SHORT_PATH.md'
];
assert(fs.existsSync('scripts/native-safety-test.mjs'), 'Missing dev.4 native safety regression');
assert(fs.existsSync('scripts/rc-release-gate-test.mjs'), 'Missing RC.1 release gate regression');
assert(fs.existsSync('scripts/formal-release-gate-test.mjs'), 'Missing formal release gate regression');
for (const file of required) assert(fs.existsSync(file), `Missing packaged dependency: ${file}`);

for (const staleFile of [
  'scripts/extract.mjs',
  'MIGRATION_R7_TO_RC2.md',
  'RELEASE_GATE_v4.0.0-rc.1.md',
  'RELEASE_GATE_v4.0.0-rc.2.md',
  'android/app/src/androidTest/java/com/getcapacitor/myapp/ExampleInstrumentedTest.java',
  'android/app/src/test/java/com/getcapacitor/myapp/ExampleUnitTest.java'
]) assert(!fs.existsSync(staleFile), `Stale release file must be removed: ${staleFile}`);

const regression = fs.readFileSync('scripts/regression.mjs', 'utf8');
const build = fs.readFileSync('scripts/build.mjs', 'utf8');
assert(!regression.includes("../tests/"), 'Regression tests must not depend on files outside the package');
assert(!build.includes("../dist/"), 'App build must not depend on files outside the package');
assert(build.includes("fs.rmSync('www'"), 'App build must clear stale Web output first');
assert(!build.includes("'storage.js'"), 'Node-only storage adapter must not be copied into the App');

if (fs.existsSync('../tests/runtime-smoke.mjs')) {
  assert.deepEqual(
    fs.readFileSync('tests/runtime-smoke.mjs'),
    fs.readFileSync('../tests/runtime-smoke.mjs'),
    'Packaged runtime regression must match the website baseline test'
  );
}

for (const icon of required.filter((file) => file.startsWith('src/icons/'))) {
  const source = `../dist/icons/${icon.split('/').at(-1)}`;
  if (fs.existsSync(source)) {
    assert.deepEqual(fs.readFileSync(icon), fs.readFileSync(source), `Packaged icon must match ${source}`);
  }
}

console.log('PASS: Windows package contains all runtime tests and App build assets');
