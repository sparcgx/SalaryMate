import assert from 'node:assert/strict'; import fs from 'node:fs'; import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8'); const v=readVersionContract();
for(const p of ['SOURCE_MANIFEST.json','SOURCE_MANIFEST.txt','FORMAL_RELEASE_EVIDENCE.md','ANDROID_RELEASE_SIGNING.md','RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd','RUN_IOS_FOUNDATION_GATE_MAC.command']) assert(fs.existsSync(p),`Missing freeze artifact dependency ${p}`);
assert(read('BUILD_ANDROID_WINDOWS.cmd').includes(`SalaryMate_v${v.productVersion}-release.apk`));
assert(read('INSTALL_TO_ANDROID_WINDOWS.cmd').includes('install -r'));
console.log('PASS: RC-05 package, build, signing and in-place-upgrade freeze contracts are present');
