import assert from 'node:assert/strict';
import fs from 'node:fs';

const app = fs.readFileSync('src/app.js', 'utf8');
const styles = fs.readFileSync('src/styles.css', 'utf8');
const models = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt', 'utf8');
const repository = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt', 'utf8');
const payroll = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt', 'utf8');
const companyScreen = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/NativeCompanyManagementScreen.kt', 'utf8');
const mainActivity = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/MainActivity.java', 'utf8');

assert(app.includes('const renderCompanyAdvancedRules = (company) =>'));
const block = app.slice(app.indexOf('const renderCompanyAdvancedRules'), app.indexOf('const renderCompanyDetail'));
for (const label of ['特殊薪資週期','年度加薪','年終規則','其他特殊規則']) assert(block.includes(label));
assert(block.indexOf('特殊薪資週期') < block.indexOf('年度加薪'));
assert(block.indexOf('年度加薪') < block.indexOf('年終規則'));
assert(block.indexOf('年終規則') < block.indexOf('其他特殊規則'));
assert(block.includes('不提供任意公式或 Rule Engine'));
assert(app.includes("payrollPeriodType: ['calendar', 'prev16', 'custom'].includes"));
assert(app.includes('payrollCycleStartDay'));
assert(app.includes('payrollCycleEndDay'));
assert(app.includes("data-action=\"company-advanced-rules\""));
assert(app.includes("data-action=\"edit-payroll-cycle\""));
assert(app.includes("data-action=\"add-annual-raise\""));
assert(app.includes("data-action=\"open-year-end-rule\""));
assert(app.includes("data-action=\"company-special-rules\""));
assert(app.includes("reason === 'annual'"));
assert(app.includes('state.yearEndEstimates'));
assert(!app.includes('specialRulesStore'));
assert(!app.includes('RuleEngine'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS special_rules'));
assert(!repository.includes('schemaVersion", 14'));
assert(repository.includes('private fun payrollPeriodKey(value: JSONObject): String'));
assert(repository.includes('payrollCycleStartDay'));
assert(repository.includes('payrollCycleEndDay'));
assert(payroll.includes('private data class PayrollCycle'));
assert(payroll.includes('value.startsWith("custom:")'));
assert(payroll.includes('salaryPeriodBounds'));
assert(styles.includes('CM-04 | Advanced Company Rules Simplification'));
assert(models.includes('data class NativeCompany'));
assert(companyScreen.includes('Text("進階設定")'));
assert(mainActivity.includes('"company-advanced-rules"'));

// Critical existing cores remain present.
assert(payroll.includes('fun salaryTax(gross: Long): Long = if (gross > 86_001L)'));
for (const rate of ['1.34','1.67','2.67','2.5']) assert(payroll.includes(rate));

console.log('PASS: CM-04 Advanced Company Rules uses Schema 13 company/year-end/salary-adjustment stores, adds bounded custom payroll cycles, and does not add a rule engine');
