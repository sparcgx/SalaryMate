import assert from 'node:assert/strict';
import fs from 'node:fs';

const VERSION = '4.1.0-RC.1';
const VERSION_CODE = 11;
const read = file => fs.readFileSync(file, 'utf8');

const packageJson = JSON.parse(read('package.json'));
const packageLock = JSON.parse(read('package-lock.json'));
const gradle = read('android/app/build.gradle');
const manifest = read('android/app/src/main/AndroidManifest.xml');
const nativeModels = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt');
const repository = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt');
const nativeCrypto = read('android/app/src/main/java/com/salarymate/personal/backup/NativeBackupCrypto.kt');
const nativeBackup = read('android/app/src/main/java/com/salarymate/personal/backup/NativeBackupService.kt');
const webApp = read('src/app.js');
const bootstrap = read('src/bootstrap.mjs');
const nativeWebBackup = read('src/native-backup.mjs');
const index = read('src/index.html');
const releaseBuild = read('BUILD_ANDROID_WINDOWS.cmd');
const debugBuild = read('BUILD_COMPOSE_DEBUG_WINDOWS.cmd');
const releaseInstall = read('INSTALL_TO_ANDROID_WINDOWS.cmd');
const deviceGate = read('RUN_RC1_DEVICE_GATE_WINDOWS.cmd');
const acceptance = read('ANDROID_RC1_ACCEPTANCE.md');
const releaseGate = read('RELEASE_GATE_v4.1.0-RC.1.md');
const playChecklist = read('PLAY_CONSOLE_CHECKLIST.md');
const readme = read('README.md');

assert.equal(packageJson.version, VERSION);
assert.equal(packageLock.version, VERSION);
assert.equal(packageLock.packages[''].version, VERSION);
assert(gradle.includes(`versionCode ${VERSION_CODE}`));
assert(gradle.includes(`versionName "${VERSION}"`));
assert(gradle.includes('applicationId "com.salarymate.personal"'));
assert(gradle.includes('applicationIdSuffix ".debug"'));
assert(nativeModels.includes(`NATIVE_APP_VERSION = "${VERSION}"`));
assert(webApp.includes(`APP_VERSION = '${VERSION}'`));
assert(bootstrap.includes(`'${VERSION}'`));
assert(nativeWebBackup.includes(`version = '${VERSION}'`));
assert(index.includes(`v${VERSION}`));

for (const marker of [
  `SalaryMate_v${VERSION}-release.apk`,
  `SalaryMate_v${VERSION}-release.aab`,
  `versionCode='${VERSION_CODE}'`,
  'clean assembleRelease bundleRelease',
  'apksigner.bat',
  'jarsigner.exe',
  'dump permissions'
]) assert(releaseBuild.includes(marker), `Missing RC release build marker: ${marker}`);

for (const marker of [
  `SalaryMate_v${VERSION}-compose-debug.apk`,
  `versionCode='${VERSION_CODE}'`,
  ':app:testDebugUnitTest :app:assembleDebugAndroidTest :app:assembleDebug'
]) assert(debugBuild.includes(marker), `Missing RC debug build marker: ${marker}`);

for (const marker of [
  `SalaryMate_v${VERSION}-release.apk`,
  'install -r',
  'RC1_preinstall_identity.txt',
  'RC1_postinstall_identity.txt',
  `versionCode=${VERSION_CODE}`,
  `versionName=${VERSION}`
]) assert(releaseInstall.includes(marker), `Missing RC upgrade install marker: ${marker}`);
assert(!releaseInstall.includes(' install -d'));
assert(!/^\s*"?%ADB%"?\s+uninstall\b/im.test(releaseInstall));
assert(!/^\s*"?%ADB%"?\s+shell\s+pm\s+clear\b/im.test(releaseInstall));

for (const marker of [
  ':app:connectedDebugAndroidTest',
  'com.salarymate.personal.debug',
  `versionCode=${VERSION_CODE}`,
  `versionName=${VERSION}-debug`
]) assert(deviceGate.includes(marker), `Missing connected-device gate marker: ${marker}`);

assert(repository.includes('salarymateSQLite.db'));
assert(repository.includes('schema == 13'));
assert(repository.includes('ORDER BY id DESC LIMIT 3'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS overtime'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS leave'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS backup'));
for (const marker of [
  'salarymate-encrypted-backup',
  'SalaryMate|encrypted-backup|v1',
  '310_000',
  'AES/GCM/NoPadding'
]) assert(nativeCrypto.includes(marker), `Missing frozen backup marker: ${marker}`);
assert(nativeBackup.includes('appContext.packageName'));
assert(!nativeBackup.includes('BuildConfig'));
assert(manifest.includes('android:authorities="${applicationId}.fileprovider"'));

for (let number = 59; number <= 72; number++) {
  assert(acceptance.includes(`| ${number} |`), `Missing RC acceptance item ${number}`);
}
for (const marker of [
  '1～58',
  '1～72',
  'adb install -r',
  '1,373 筆歷史 OT',
  'HOLD FOR RELEASE',
  'GO FOR RELEASE REVIEW'
]) assert(acceptance.includes(marker), `Missing RC acceptance marker: ${marker}`);

for (const marker of [
  `versionCode ${VERSION_CODE}`,
  `versionName ${VERSION}`,
  'HOLD FOR RELEASE',
  'Internal testing',
  '1～72'
]) assert(releaseGate.includes(marker), `Missing RC release gate marker: ${marker}`);
assert(playChecklist.includes(`versionCode ${VERSION_CODE}`));
assert(playChecklist.includes(`versionName ${VERSION}`));
assert(readme.includes('dev.4-R2'));
assert(readme.includes('RUN_RC1_DEVICE_GATE_WINDOWS.cmd'));

for (const file of [
  'BUILD_ANDROID_WINDOWS.cmd',
  'BUILD_COMPOSE_DEBUG_WINDOWS.cmd',
  'INSTALL_TO_ANDROID_WINDOWS.cmd',
  'INSTALL_COMPOSE_DEBUG_WINDOWS.cmd',
  'RUN_RC1_DEVICE_GATE_WINDOWS.cmd'
]) {
  const command = fs.readFileSync(file);
  assert([...command].every(byte => byte < 128), `${file} must remain ASCII-only`);
  for (let index = 0; index < command.length; index++) {
    if (command[index] === 0x0a) assert.equal(command[index - 1], 0x0d, `${file} must use CRLF`);
  }
  const text = command.toString('ascii');
  const labels = new Set([...text.matchAll(/^:([A-Za-z0-9_]+)\r?$/gm)].map(match => match[1].toLowerCase()));
  for (const match of text.matchAll(/\bgoto\s+([A-Za-z0-9_]+)/gi)) {
    assert(labels.has(match[1].toLowerCase()), `${file} has undefined batch label: ${match[1]}`);
  }
}

console.log('PASS: RC.1 identity, upgrade safety, data compatibility and release-candidate gates are present');
