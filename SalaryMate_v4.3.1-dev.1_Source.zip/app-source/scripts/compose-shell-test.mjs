import assert from 'node:assert/strict';
import fs from 'node:fs';
import { readVersionContract } from './version-contract.mjs';

const version = readVersionContract();
const rootGradle = fs.readFileSync('android/build.gradle', 'utf8');
const appGradle = fs.readFileSync('android/app/build.gradle', 'utf8');
const capacitorGradle = fs.readFileSync('android/app/capacitor.build.gradle', 'utf8');
const manifest = fs.readFileSync('android/app/src/main/AndroidManifest.xml', 'utf8');
const composeActivity = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ComposeShellActivity.kt', 'utf8');
const shell = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt', 'utf8');
const nativeHome = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/NativeHomeScreen.kt', 'utf8');
const nativeQuick = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/NativeQuickEntryScreen.kt', 'utf8');
const nativePayroll = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt', 'utf8');
const nativeCompany = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/ui/NativeCompanyManagementScreen.kt', 'utf8');
const repository = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt', 'utf8');
const nativeMath = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt', 'utf8');
const nativeModels = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateModels.kt', 'utf8');
const mainActivity = fs.readFileSync('android/app/src/main/java/com/salarymate/personal/MainActivity.java', 'utf8');

assert(rootGradle.includes('kotlin-gradle-plugin:2.3.21'));
assert(rootGradle.includes('compose-compiler-gradle-plugin:2.3.21'));
assert(appGradle.includes("apply plugin: 'org.jetbrains.kotlin.android'"));
assert(appGradle.includes("apply plugin: 'org.jetbrains.kotlin.plugin.compose'"));
assert(appGradle.includes('androidx.compose:compose-bom:2026.06.01'));
assert(appGradle.includes(`versionName "${version.productVersion}"`));
assert(appGradle.includes(`versionCode ${version.androidVersionCode}`));
assert(appGradle.includes('sourceCompatibility JavaVersion.VERSION_21'));
assert(appGradle.includes('targetCompatibility JavaVersion.VERSION_21'));
assert(appGradle.includes("jvmTarget = '21'"));
assert(appGradle.includes('jvmToolchain(21)'));
assert(capacitorGradle.includes('sourceCompatibility JavaVersion.VERSION_21'));
assert(capacitorGradle.includes('targetCompatibility JavaVersion.VERSION_21'));
assert(!appGradle.includes('JavaVersion.VERSION_17'));
assert(!appGradle.includes("jvmTarget = '17'"));

const activityBlock = name => {
  const markerIndex = manifest.indexOf(`android:name="${name}"`);
  assert(markerIndex >= 0, `Missing activity ${name}`);
  const start = manifest.lastIndexOf('<activity', markerIndex);
  const end = manifest.indexOf('</activity>', markerIndex);
  return manifest.slice(start, end + '</activity>'.length);
};
const shellActivityBlock = activityBlock('.ComposeShellActivity');
const webActivityBlock = activityBlock('.MainActivity');
assert(shellActivityBlock.includes('android.intent.action.MAIN'));
assert(shellActivityBlock.includes('android.intent.category.LAUNCHER'));
assert(shellActivityBlock.includes('android:exported="true"'));
assert(webActivityBlock.includes('android:exported="false"'));
assert(!webActivityBlock.includes('android.intent.category.LAUNCHER'));

assert(composeActivity.includes('class ComposeShellActivity : FragmentActivity()'));
assert(composeActivity.includes('repository = repository'));
assert(composeActivity.includes('SalaryMateLockedScreen'));
assert(composeActivity.includes('Intent(this, MainActivity::class.java)'));
for (const destination of ['首頁', '快速登記', '薪資', '年度總覽', '公司管理', '設定']) {
  assert(shell.includes(destination), `Missing Compose destination: ${destination}`);
}
for (const route of ['add-record', 'add-overtime', 'add-leave', 'manage-companies', 'data-health', 'company-full-settings']) {
  assert(mainActivity.includes(`"${route}"`), `Missing safe Web route: ${route}`);
}
assert(mainActivity.includes('ALLOWED_TABS'));
assert(mainActivity.includes('ALLOWED_ACTIONS'));
assert(mainActivity.includes('routeFromComposeShell(getIntent(), 0);'));
assert(mainActivity.includes("action==='add-leave'?'leave'"));
assert(mainActivity.includes("action==='add-overtime'?'overtime'"));
assert(fs.readFileSync('src/bootstrap.mjs', 'utf8').includes('await App.exitApp()'));
assert(nativeModels.includes(`NATIVE_APP_VERSION = "${version.productVersion}"`));
assert(repository.includes('salarymateSQLite.db'));
assert(repository.includes('INSERT INTO snapshots'));
assert(repository.includes('ORDER BY id DESC LIMIT 3'));
assert(repository.includes('executeSet(statements, true'));
assert(repository.includes('schema == 13'));
assert(repository.includes('isHalfHourIncrement(draft.hours)'));
assert(repository.includes('isHalfHourIncrement(draft.customHours)'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS overtime'));
assert(!repository.includes('CREATE TABLE IF NOT EXISTS leave'));
assert(nativeHome.includes('同一份 SQLite 快照'));
assert(nativeHome.includes('onOpenQuick(QuickEntryKind.Overtime)'));
assert(nativeHome.includes('onClick = onOpenPayroll'));
assert(nativeQuick.includes('onSaveOvertime'));
assert(nativeQuick.includes('onSaveLeave'));
assert(nativeQuick.includes('以三位小數快照保存'));
assert(nativePayroll.includes('建立月度薪資'));
assert(nativePayroll.includes('複製下一月'));
assert(nativePayroll.includes('刪除薪資紀錄？'));
assert(repository.includes('prepareSalaryDraft'));
assert(repository.includes('saveSalaryRecord'));
assert(repository.includes('deleteSalaryRecord'));
assert(repository.includes('這家公司已有'));
assert(nativeMath.includes('gross > 86_001L'));
assert(nativeMath.includes('defaultPayDate'));
assert(nativeMath.includes('first * 1.34 + later * 1.67'));
for (const source of [shell, nativeHome, nativeQuick, nativePayroll, nativeCompany]) {
  assert(!source.includes('import androidx.compose.foundation.layout.weight'));
  assert(!source.includes('loadSample'));
}

console.log('PASS: Compose home, payroll and quick entry use the existing Schema 13 snapshot as the single data source');
