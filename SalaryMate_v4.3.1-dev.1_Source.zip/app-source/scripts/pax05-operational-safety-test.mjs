import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { readVersionContract } from './version-contract.mjs';

const read = path => fs.readFileSync(path, 'utf8');
const version = readVersionContract();
const app = read('src/app.js');
const shell = read('android/app/src/main/java/com/salarymate/personal/ui/SalaryMateShell.kt');
const payroll = read('android/app/src/main/java/com/salarymate/personal/ui/NativePayrollScreen.kt');
const company = read('android/app/src/main/java/com/salarymate/personal/ui/NativeCompanyManagementScreen.kt');
const repo = read('android/app/src/main/java/com/salarymate/personal/data/NativeSalaryMateRepository.kt');
const math = read('android/app/src/main/java/com/salarymate/personal/data/NativePayrollMath.kt');

assert.equal(version.releaseVersion, '4.3.0');
assert(version.completedGates.includes('PAX-05_IMPLEMENTATION_REGRESSION'));
assert.equal(version.schemaVersion, 13);
new vm.Script(app);

// One explicit Current Company context, scoped draft and selected-entity state.
assert(app.includes('draftScope: null'));
assert(app.includes('selectedEntityScope: null'));
assert(app.includes('const beginDraftScope ='));
assert(app.includes('contextGeneration: contextGeneration()'));
assert(app.includes("console.error('DRAFT_SCOPE_MISMATCH'"));
assert(app.includes("console.error('STALE_CONTEXT_RESULT'"));
assert(app.includes('if (operational && currentCompany()?.id !== expectedCompany)'));
assert(app.includes('const selectedEntityIsInCurrentScope ='));

// Scope and Dirty are deliberately distinct; revert-to-baseline can become clean.
assert(app.includes('dirty: false'));
assert(app.includes("scope.entityType === 'year-end' && scope.baselineFingerprint"));
assert(app.includes('scope.dirty = stableDraftFingerprint(ui.yearEndDraft) !== scope.baselineFingerprint'));
assert(app.includes('scope.dirty = dialogHasUnsavedChanges()'));
assert(app.includes('const hasDirtyDraft = () => Boolean(dialogHasUnsavedChanges?.() || ui.draftScope?.dirty)'));

// Payroll draft includes company and month and is asserted again before commit.
assert(app.includes("beginDraftScope({ entityType: 'payroll'"));
assert(app.includes("assertDraftScope({ entityType: 'payroll'"));
assert(app.includes('payrollMonthKey(draft.year, draft.month)'));
assert(app.includes("ui.draftScope.payrollMonth = payrollMonthKey(draft.year, draft.month)"));

// Year-End is a page-level draft and must obey the same safety contract.
assert(app.includes('const ensureYearEndDraftScope = () =>'));
assert(app.includes("entityType: 'year-end'"));
assert(app.includes("assertDraftScope({ entityType: 'year-end'"));
assert(app.includes('年終規則有尚未儲存的變更。要放棄變更並切換公司嗎？'));

// Switching company persists before UI/context activation and invalidates stale work.
assert(app.includes("setOperationStatus('submitting', 'switch-company'"));
assert(app.includes('bumpContextGeneration()'));
assert(app.includes('clearOperationalSelection()'));
assert(app.includes('無法切換公司。目前仍使用'));

// Duplicate commit and restore-submit protections.
assert(app.includes('const activeOperationLocks = new Set()'));
assert(app.includes('const recentOperationLocks = new Map()'));
assert(app.includes("console.warn('DUPLICATE_SUBMIT_BLOCKED'"));
assert(app.includes("const restoreCommitKey = 'restore:commit'"));
assert(app.includes('還原正在處理，已阻止重複送出。'));

// Restore / async work cannot apply stale context.
assert(app.includes('const readGeneration = contextGeneration()'));
assert(app.includes("throw new Error('STALE_CONTEXT')"));
assert(app.includes('這份舊的還原讀取結果已捨棄'));
assert(app.includes('resetTransientUiAfterRestore()'));

// Browser Back and company nested routes preserve logical-parent semantics.
assert(app.includes('const currentHistoryState = () =>'));
assert(app.includes('companyDetailId: ui.tab === \'companies\''));
assert(app.includes('const openCompanyDetailRoute ='));
assert(app.includes("'company-back': () =>"));
assert(app.includes('if (hasDirtyDraft())'));
assert(app.includes("window.addEventListener('popstate'"));
assert(app.includes("window.addEventListener('beforeunload'"));

// Read-only operational diagnostics are exposed for runtime regression.
assert(app.includes('operationalScope: () => clone({'));
assert(app.includes('currentCompanyId: currentCompany()?.id || \'\''));
assert(app.includes('contextGeneration: runtimeState.generation'));

// Android bottom navigation cannot silently discard a dirty payroll draft.
assert(shell.includes('var payrollDraftDirty by rememberSaveable'));
assert(shell.includes('var pendingDestinationName by rememberSaveable'));
assert(shell.includes('fun requestDestination(destination: ShellDestination)'));
assert(shell.includes('selected == ShellDestination.Payroll && destination != ShellDestination.Payroll && payrollDraftDirty'));
assert(shell.includes('放棄未儲存薪資草稿？'));
assert(shell.includes('onDraftDirtyChanged = { payrollDraftDirty = it }'));

// Android payroll dirty is value-based, not merely "editor open".
assert(payroll.includes('var draftDirty by remember'));
assert(payroll.includes('BackHandler(enabled = activeDraft != null && draftDirty)'));
assert(payroll.includes('val isDirty = liveDraft != draft'));
assert(payroll.includes('LaunchedEffect(isDirty) { onDirtyChanged(isDirty) }'));

// Android company basic editor also gets a true Dirty Guard.
assert(company.includes('val dirty = name != initialName || salary != initialSalary || startDate != initialStartDate'));
assert(company.includes('放棄未儲存公司資料？'));
assert(company.includes('if (dirty) confirmDiscard = true else onDismiss()'));

// Existing domain/schema rules remain frozen.
assert(math.includes('gross > 86_001L'));
assert(math.includes('safeHours * safeRate * 2.5'));
assert(repo.includes('schema == 13'));
assert(!app.includes('DraftDatabase'));
assert(!app.includes('CompanyStoreV2'));

console.log('PASS: PAX-05 scopes drafts and selected entities, fails closed on context drift, blocks duplicate UI commits, and guards Web/Android navigation without changing business rules');
