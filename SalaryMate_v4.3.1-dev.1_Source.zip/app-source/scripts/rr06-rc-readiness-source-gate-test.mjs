import assert from 'node:assert/strict';
import fs from 'node:fs'; import { readVersionContract } from './version-contract.mjs';
const read=p=>fs.readFileSync(p,'utf8'); const v=readVersionContract(); const status=JSON.parse(read('version.json'));
assert.equal(v.releaseVersion,'4.3.0'); assert.ok(v.androidVersionCode>=17); assert.ok(v.buildNumber>=5); assert.equal(v.schemaVersion,13);
assert.equal(status.stableEligible,false);
assert(fs.existsSync('RELEASE_GATE_v4.3.0-dev.4.md'));
const current=read(`RELEASE_GATE_v${v.productVersion}.md`); assert(current.includes('SOURCE_READY_DEVICE_PENDING')); assert(current.includes('NOT AUTHORIZED'));
console.log(`PASS: RR-06 dev.4 readiness contract is inherited by ${v.productVersion} without claiming Stable readiness`);
