import { DatabaseSync } from 'node:sqlite';
import assert from 'node:assert/strict';
import { SnapshotRepository, createNativeStore, STATE_KEY } from '../src/snapshot-store.mjs';
const sql = new DatabaseSync(':memory:');
let fail = false;
const db = {
  async execute(statement) { sql.exec(statement); },
  async query(statement) { return { values: sql.prepare(statement).all() }; },
  async executeSet(set, transaction) {
    assert.equal(transaction, true);
    sql.exec('BEGIN');
    try {
      for (const item of set) {
        sql.prepare(item.statement).run(...item.values);
        if (fail) throw new Error('simulated disk failure');
      }
      sql.exec('COMMIT');
    } catch (error) { sql.exec('ROLLBACK'); throw error; }
  }
};
const payload = n => JSON.stringify({ schemaVersion: 13, companies: [], records: [], overtimeLogs: [{ hourlyRate: 100.111 }], revision: n });
const values = new Map([[STATE_KEY, payload(0)]]);
const legacy = { getItem: key => values.get(key) ?? null, removeItem: key => values.delete(key) };
const repo = new SnapshotRepository(db);
const statuses = [];
let store = await createNativeStore(repo, legacy, state => statuses.push(state));
assert.equal(await repo.read(), payload(0));
assert.equal(legacy.getItem(STATE_KEY), payload(0));
for (let n = 1; n <= 5; n++) store.setItem(STATE_KEY, payload(n));
await store.flush();
assert.equal(await repo.read(), payload(5));
assert.equal(sql.prepare('SELECT count(*) AS n FROM snapshots').get().n, 3);
assert.equal(statuses.at(-1), 'saved');
const snapshots = await repo.list();
assert.equal(snapshots.length, 3);
assert(snapshots.every(row => row.valid));
assert(snapshots[0].summary.includes('加班 1 筆'));
await repo.write(snapshots.at(-1).payload);
assert.equal(await repo.read(), snapshots.at(-1).payload);
await repo.write(payload(5));
fail = true;
store.setItem(STATE_KEY, payload(6));
await assert.rejects(store.flush(), /disk failure/);
assert.equal(await repo.read(), payload(5));
assert.equal(statuses.at(-1), 'failed');
assert.throws(() => store.setItem(STATE_KEY, payload(7)), /disk failure/);
fail = false;
store = await createNativeStore(repo, legacy);
assert.equal(store.getItem(STATE_KEY), payload(5));
store.setItem(STATE_KEY, payload(8), true);
await store.flush();
assert.equal(sql.prepare('SELECT count(*) AS n FROM snapshots').get().n, 1);
assert.equal(legacy.getItem(STATE_KEY), null);
sql.prepare('UPDATE snapshots SET payload = ?').run('{broken');
assert((await repo.list()).every(row => !row.valid && row.payload === undefined));
await assert.rejects(createNativeStore(repo, legacy));
assert.equal(sql.prepare('SELECT payload FROM snapshots').get().payload, '{broken');
fail = true;
await assert.rejects(repo.write(payload(10)), /disk failure/);
assert.equal(sql.prepare('SELECT payload FROM snapshots').get().payload, '{broken');
fail = false;
await repo.write(payload(10));
assert.equal(await repo.read(), payload(10));
sql.exec('DELETE FROM snapshots');
values.set(STATE_KEY, '{broken legacy');
await assert.rejects(createNativeStore(repo, legacy));
assert.equal(values.get(STATE_KEY), '{broken legacy');
values.set(STATE_KEY, payload(0));
fail = true;
await assert.rejects(createNativeStore(repo, legacy));
assert.equal(sql.prepare('SELECT count(*) AS n FROM snapshots').get().n, 0);
assert.equal(values.get(STATE_KEY), payload(0));
sql.close();
console.log('PASS: real SQLite transactions, ordered writes, 3-snapshot retention, rollback, fail-closed reads, migration and clear');
