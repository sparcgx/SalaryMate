import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createResults } from './formal-device-results.mjs';
import { readVersionContract } from './version-contract.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const version = readVersionContract(root);
const report = createResults(root);
const environment = { ...process.env };
const androidHome = environment.ANDROID_HOME || (environment.LOCALAPPDATA && path.join(environment.LOCALAPPDATA, 'Android', 'Sdk'));
const adb = androidHome && path.join(androidHome, 'platform-tools', 'adb.exe');

function print(message) {
  process.stdout.write(`${message}\n`);
  report.log(message);
}

async function run(name, executable, args, cwd = root, options = {}) {
  const step = report.start(name);
  print(`\n[RUN] ${name}`);
  return new Promise(resolve => {
    let settled = false;
    let output = '';
    const child = spawn(executable, args, { cwd, env: environment, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    const capture = (stream, target) => stream.on('data', chunk => {
      const text = chunk.toString('utf8');
      if (options.capture) output += text;
      report.append(chunk);
      target.write(chunk);
    });
    capture(child.stdout, process.stdout);
    capture(child.stderr, process.stderr);
    child.on('error', error => {
      print(`SPAWN ERROR: ${error.message}`);
      if (!settled) {
        settled = true;
        report.complete(step, 1);
        resolve({ exitCode: 1, output });
      }
    });
    child.on('close', (code, signal) => {
      if (settled) return;
      settled = true;
      let exitCode = Number.isInteger(code) ? code : 1;
      if (exitCode === 0 && options.verify && !options.verify(output)) {
        exitCode = 1;
        print(`VALIDATION FAILED: ${name}`);
      }
      if (signal) print(`INTERRUPTED: ${signal}`);
      report.complete(step, exitCode);
      print(`[${exitCode === 0 ? 'PASS' : 'FAIL'}] ${name} (exit ${exitCode})`);
      resolve({ exitCode, output });
    });
  });
}

async function checked(name, executable, args, cwd, options) {
  const result = await run(name, executable, args, cwd, options);
  if (result.exitCode !== 0) throw new Error(`${name} failed with exit ${result.exitCode}`);
  return result.output;
}

async function main() {
  if (process.platform !== 'win32') throw new Error('Windows is required for the connected device gate');
  if (!adb || !fs.existsSync(adb)) throw new Error('Android SDK Platform-Tools (adb.exe) not found');
  environment.ANDROID_HOME = androidHome;
  const java = await checked('Select JDK 21', process.execPath, ['scripts/select-java-home-windows.mjs'], root, { capture: true });
  environment.JAVA_HOME = java.trim().split(/\r?\n/).at(-1);
  if (!environment.JAVA_HOME || !fs.existsSync(path.join(environment.JAVA_HOME, 'bin', 'java.exe'))) {
    throw new Error('JDK 21 not found');
  }
  const pathKey = Object.keys(environment).find(key => key.toLowerCase() === 'path') ?? 'Path';
  environment[pathKey] = [path.join(environment.JAVA_HOME, 'bin'), path.join(androidHome, 'platform-tools'), environment[pathKey] ?? ''].join(path.delimiter);
  const cmd = environment.ComSpec || 'cmd.exe';
  for (const [name, command] of [
    ['Install locked dependencies', 'npm ci'],
    ['Android environment doctor', 'npm run android:doctor'],
    ['Local regression tests', 'npm test'],
    ['Runtime dependency audit', 'npm run audit:runtime'],
    ['Android native assets sync', 'npm run android:sync']
  ]) await checked(name, cmd, ['/d', '/c', command]);

  await checked('Authorized Android device', adb, ['get-state'], root, {
    capture: true,
    verify: output => output.trim().split(/\r?\n/).includes('device')
  });

  await checked('Connected Android instrumentation', cmd, ['/d', '/c', 'gradlew.bat :app:connectedDebugAndroidTest --no-daemon'], path.join(root, 'android'));
  await checked('Installed debug package identity', adb, ['shell', 'dumpsys', 'package', 'com.salarymate.personal.debug'], root, {
    capture: true,
    verify: output => output.includes(`versionCode=${version.androidVersionCode}`) && output.includes(`versionName=${version.productVersion}-debug`)
  });
  report.finish('PASS', 'All automated Windows and connected-device steps passed');
  print('PASS: Automated device gate only. Manual 1-72, upgrade, backup and Play checks remain NOT_RUN.');
}

try {
  await main();
  print(`Results: ${report.directory}`);
} catch (error) {
  const failedStep = report.result.steps.findLast(step => step.status === 'FAIL')?.name ?? null;
  report.finish('FAIL', error.message, failedStep);
  print(`FAIL: ${error.message}`);
  print(`Results: ${report.directory}`);
  process.exitCode = 1;
}
