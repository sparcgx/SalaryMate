import assert from 'node:assert/strict';
import { decryptBackup, encryptBackup, inspectEncryptedBackup, isEncryptedBackup } from '../src/backup-crypto.mjs';

const payload = JSON.stringify({
  schemaVersion: 13,
  companies: [{ id: 'company-1', name: '測試公司' }],
  records: [],
  overtimeLogs: [{ hourlyRate: 100.111 }]
});
const password = '薪資備份 passphrase 2026';
const first = await encryptBackup(payload, password);
const second = await encryptBackup(payload, password);
assert(isEncryptedBackup(first));
assert.notEqual(first, second, 'salt and IV must randomize identical backups');
assert.equal(inspectEncryptedBackup(first).version, 1);
assert.equal(await decryptBackup(first, password), payload);

await assert.rejects(decryptBackup(first, '錯誤的備份密碼'), error => error.code === 'AUTH_FAILED');
await assert.rejects(encryptBackup(payload, 'too short'), error => error.code === 'PASSWORD_TOO_SHORT');

const tampered = JSON.parse(first);
const replacement = tampered.payload.at(-2) === 'A' ? 'B' : 'A';
tampered.payload = tampered.payload.slice(0, -2) + replacement + tampered.payload.slice(-1);
await assert.rejects(decryptBackup(JSON.stringify(tampered), password), error => error.code === 'AUTH_FAILED');

const expensive = JSON.parse(first);
expensive.kdf.iterations = 9_999_999;
await assert.rejects(decryptBackup(JSON.stringify(expensive), password), error => error.code === 'INVALID_FORMAT');
await assert.rejects(decryptBackup('{broken', password), error => error.code === 'INVALID_FORMAT');
console.log('PASS: AES-GCM backup roundtrip, random salt/IV, wrong password, tamper detection, KDF bounds and damaged-file rejection');
