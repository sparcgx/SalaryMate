import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { readVersionContract } from './version-contract.mjs';

export function createIOSResults(root, scope, plannedSteps) {
  const version = readVersionContract();
  const stamp = () => new Date().toISOString();
  const runId = `${stamp().replace(/[:.]/g, '-')}_${randomUUID().slice(0, 8)}`;
  const directory = path.join(root, 'test-results', `ios-v${version.productVersion}`, runId);
  fs.mkdirSync(directory, { recursive: true });
  fs.writeFileSync(path.join(directory, 'test.log'), '');
  const result = {
    schemaVersion: 1, version: version.productVersion, scope, runId,
    startedAt: stamp(), finishedAt: null, status: 'INCOMPLETE', reason: '尚未完成',
    host: process.platform, steps: plannedSteps.map(name => ({ name, status: 'NOT_RUN', exitCode: null })),
    realDevice: 'NOT_RUN', upgradeDataPreservation: 'NOT_RUN', backupRestore: 'NOT_RUN',
    lifecycle: 'NOT_RUN', longSession: 'NOT_RUN', manualAcceptance: 'NOT_RUN', crossPlatformBackup: 'NOT_RUN',
    releaseDecision: 'HOLD FOR RELEASE'
  };
  const persist = () => {
    const target = path.join(directory, 'result.json');
    fs.writeFileSync(`${target}.tmp`, JSON.stringify(result, null, 2) + '\n');
    fs.renameSync(`${target}.tmp`, target);
    fs.writeFileSync(path.join(directory, 'result.txt'), [
      `SalaryMate v${result.version} | ${scope} | ${result.status}`,
      `開始：${result.startedAt}`, `結束：${result.finishedAt ?? '未完成'}`,
      `原因：${result.reason}`, '',
      ...result.steps.map(s => `${s.status} | ${s.name} | exit=${s.exitCode ?? '未執行'}`),
      '', `iPhone 實機：${result.realDevice}`, `升級／資料保留：${result.upgradeDataPreservation}`,
      `備份／還原：${result.backupRestore}`, `Lifecycle：${result.lifecycle}`, `Long session：${result.longSession}`,
      `跨平台備份：${result.crossPlatformBackup}`, 
      '發行狀態：HOLD FOR RELEASE；此紀錄不代表人工驗收或正式放行。',
      '詳細輸出：test.log；模擬器測試證據（執行後）：Foundation.xcresult', ''
    ].join('\n'));
  };
  persist();
  return {
    directory, result,
    log(text) { fs.appendFileSync(path.join(directory, 'test.log'), text); },
    start(name) {
      const step = result.steps.find(s => s.name === name);
      if (!step || step.status !== 'NOT_RUN') throw new Error(`Invalid step: ${name}`);
      Object.assign(step, { status: 'RUNNING', startedAt: stamp() }); persist(); return step;
    },
    complete(step, code) {
      Object.assign(step, { status: code === 0 ? 'PASS' : 'FAIL', exitCode: code, finishedAt: stamp() }); persist();
    },
    finish(status, reason) {
      if (status === 'PASS' && (!result.steps.length || result.steps.some(s => s.status !== 'PASS'))) {
        throw new Error('Cannot report PASS for unexecuted or failed steps');
      }
      Object.assign(result, { status, reason, finishedAt: stamp() }); persist();
    }
  };
}
