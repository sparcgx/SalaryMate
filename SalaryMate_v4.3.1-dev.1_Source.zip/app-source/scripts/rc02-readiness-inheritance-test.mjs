import assert from 'node:assert/strict'; import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8'); const v=JSON.parse(read('version.json'));
for(const g of ['PAX-06_SOURCE_FREEZE','RI-06_SOURCE_REGRESSION','RR-06_RC_READINESS_SOURCE_GATE']) assert(v.completedGates.includes(g),`Missing prerequisite ${g}`);
for(const p of ['RELEASE_GATE_v4.3.0-dev.4.md','REAL_DEVICE_ACCEPTANCE_v4.3.0-dev.4.md','RELEASE_GATE_v4.3.0-RC.2.md','REAL_DEVICE_ACCEPTANCE_v4.3.0-RC.2.md']) assert(fs.existsSync(p),`Missing ${p}`);
console.log('PASS: RC-02 dev.2 freeze, dev.3 release integration and dev.4 readiness evidence are inherited into RC.2');
