@echo off
setlocal
cd /d "%~dp0"
echo Legacy RC1 entry forwards to the current branch device gate.
call RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd
exit /b %ERRORLEVEL%
