import XCTest

final class FoundationUITests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
    }

    private func tap(_ element: XCUIElement) {
        XCTAssertTrue(element.waitForExistence(timeout: 30))
        for _ in 0..<6 where !element.isHittable { app.swipeUp() }
        XCTAssertTrue(element.isHittable)
        element.tap()
    }

    private func openCompanies() {
        tap(app.buttons["開啟功能與設定"])
        tap(app.buttons["▣ 公司與薪資規則"])
    }

    func testCompanyPersistsAfterProcessRestart() throws {
        app.launch()
        XCTAssertTrue(app.staticTexts["已儲存至本機資料庫"].waitForExistence(timeout: 45),
                      "Native bridge / SQLite startup must succeed")
        let dismiss = app.buttons["稍後／關閉"]
        if dismiss.waitForExistence(timeout: 3) { tap(dismiss) }
        openCompanies()
        let name = "IOS-GATE-" + String(UUID().uuidString.prefix(8))
        let field = app.textFields["公司名稱"]
        tap(field)
        field.typeText(name)
        app.staticTexts["任職公司與預設參數"].tap()
        tap(app.buttons["新增公司"])
        XCTAssertTrue(app.staticTexts["公司已新增"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.staticTexts["已儲存至本機資料庫"].waitForExistence(timeout: 15))
        app.terminate()
        app.launch()
        XCTAssertTrue(app.staticTexts["已儲存至本機資料庫"].waitForExistence(timeout: 45))
        openCompanies()
        let restored = app.staticTexts.containing(NSPredicate(format: "label CONTAINS %@", name)).firstMatch
        XCTAssertTrue(restored.waitForExistence(timeout: 15), "Company must be read back from SQLite after restart")
    }
}
