import Capacitor

final class SalaryMateViewController: CAPBridgeViewController {
    override func capacitorDidLoad() {
        bridge?.registerPluginInstance(DeviceSecurityPlugin())
        bridge?.registerPluginInstance(BackupFilePlugin())
    }
}
