import Capacitor
import CryptoKit
import Foundation
import UIKit

@objc(BackupFilePlugin)
public final class BackupFilePlugin: CAPPlugin, CAPBridgedPlugin, UIDocumentPickerDelegate {
    public let identifier = "BackupFilePlugin"
    public let jsName = "BackupFile"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "save", returnType: CAPPluginReturnPromise)
    ]
    private let maximumBytes = 30 * 1024 * 1024
    private var pending: CAPPluginCall?
    private var stagingDirectory: URL?
    private var expectedDigest: Data?
    private var expectedLength = 0
    private let io = DispatchQueue(label: "com.salarymate.backup", qos: .userInitiated)

    private func safeName(_ name: String) -> Bool {
        !name.isEmpty && name.count <= 180 && name.lowercased().hasSuffix(".salarymate") &&
        !name.contains("/") && !name.contains("\\") &&
        name.rangeOfCharacter(from: .controlCharacters) == nil
    }

    @objc public func save(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard self.pending == nil else { call.reject("另存備份正在進行", "SAVE_BUSY"); return }
            guard let name = call.getString("fileName"), self.safeName(name) else {
                call.reject("備份檔名必須以 .salarymate 結尾", "SAVE_EXTENSION_CHANGED"); return
            }
            guard let text = call.getString("data"), !text.isEmpty,
                  let data = text.data(using: .utf8), data.count <= self.maximumBytes else {
                call.reject("備份為空或超過 30 MB 上限", "SAVE_FAILED"); return
            }
            guard let presenter = self.bridge?.viewController, presenter.presentedViewController == nil else {
                call.reject("請先關閉其他系統視窗", "SAVE_UNAVAILABLE"); return
            }
            self.pending = call
            self.expectedDigest = Data(SHA256.hash(data: data))
            self.expectedLength = data.count
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent("SalaryMate-" + UUID().uuidString, isDirectory: true)
            self.stagingDirectory = folder
            self.io.async {
                do {
                    try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                    let source = folder.appendingPathComponent(name)
                    try data.write(to: source, options: [.atomic, .completeFileProtection])
                    guard try Data(contentsOf: source) == data else { throw CocoaError(.fileReadCorruptFile) }
                    DispatchQueue.main.async {
                        guard self.pending != nil else { return }
                        let picker = UIDocumentPickerViewController(forExporting: [source], asCopy: true)
                        picker.delegate = self
                        picker.shouldShowFileExtensions = true
                        picker.modalPresentationStyle = .formSheet
                        presenter.present(picker, animated: true)
                    }
                } catch {
                    DispatchQueue.main.async { self.fail("備份暫存或驗證失敗", code: "SAVE_FAILED") }
                }
            }
        }
    }

    public func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        fail("已取消另存備份", code: "SAVE_CANCELLED")
    }

    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard pending != nil, let url = urls.first, urls.count == 1 else {
            fail("儲存位置無效", code: "SAVE_FAILED"); return
        }
        guard safeName(url.lastPathComponent) else {
            // Never delete a provider's destination: it may be a pre-existing user file.
            fail("儲存位置未保留 .salarymate 副檔名", code: "SAVE_EXTENSION_CHANGED"); return
        }
        let digest = expectedDigest
        let length = expectedLength
        io.async {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            var coordinationError: NSError?
            var verificationError: Error?
            var verified = false
            NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: url, options: [], error: &coordinationError) { readable in
                do {
                    let handle = try FileHandle(forReadingFrom: readable)
                    defer { try? handle.close() }
                    var hasher = SHA256()
                    var total = 0
                    while let chunk = try handle.read(upToCount: 65_536), !chunk.isEmpty {
                        total += chunk.count
                        guard total <= self.maximumBytes else { throw CocoaError(.fileReadTooLarge) }
                        hasher.update(data: chunk)
                    }
                    verified = total == length && Data(hasher.finalize()) == digest
                } catch { verificationError = error }
            }
            DispatchQueue.main.async {
                guard coordinationError == nil, verificationError == nil, verified else {
                    self.fail("無法核對另存檔案；請改存到「我的 iPhone」後重試", code: "SAVE_FAILED"); return
                }
                let call = self.pending
                self.cleanup()
                call?.resolve(["fileName": url.lastPathComponent, "verified": true])
            }
        }
    }

    private func fail(_ message: String, code: String) {
        let call = pending
        cleanup()
        call?.reject(message, code)
    }

    private func cleanup() {
        if let folder = stagingDirectory { io.async { try? FileManager.default.removeItem(at: folder) } }
        stagingDirectory = nil
        expectedDigest = nil
        expectedLength = 0
        pending = nil
    }
}
