import Capacitor
import Foundation
import LocalAuthentication
import UIKit

@objc(DeviceSecurityPlugin)
public final class DeviceSecurityPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "DeviceSecurityPlugin"
    public let jsName = "DeviceSecurity"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "getStatus", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "authenticate", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "configureLock", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setScreenProtectionEnabled", returnType: CAPPluginReturnPromise)
    ]
    private var pending: CAPPluginCall?
    private var context: LAContext?
    private var observers: [NSObjectProtocol] = []
    static let lockKey = "salarymate.lockEnabled"
    static let protectionKey = "salarymate.screenProtectionEnabled"
    static var protectionEnabled: Bool {
        UserDefaults.standard.object(forKey: protectionKey) as? Bool ?? true
    }

    public override func load() {
        for (name, active) in [(UIScene.didActivateNotification, true), (UIScene.willDeactivateNotification, false)] {
            observers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                self?.notifyListeners("appStateChange", data: ["isActive": active])
            })
        }
    }

    private func status() -> JSObject {
        let probe = LAContext()
        var error: NSError?
        let available = probe.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error)
        return ["available": available,
                "lockEnabled": UserDefaults.standard.bool(forKey: Self.lockKey),
                "screenProtectionEnabled": Self.protectionEnabled,
                "platform": "ios", "unlockedRecently": false]
    }

    @objc public func getStatus(_ call: CAPPluginCall) {
        DispatchQueue.main.async { call.resolve(self.status()) }
    }

    @objc public func setScreenProtectionEnabled(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            UserDefaults.standard.set(call.getBool("enabled") ?? true, forKey: Self.protectionKey)
            call.resolve(self.status())
        }
    }

    @objc public func authenticate(_ call: CAPPluginCall) {
        DispatchQueue.main.async { self.beginAuthentication(call, requestedLock: nil) }
    }

    @objc public func configureLock(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            let enabled = call.getBool("enabled") ?? false
            if enabled == UserDefaults.standard.bool(forKey: Self.lockKey) {
                call.resolve(self.status())
                return
            }
            self.beginAuthentication(call, requestedLock: enabled)
        }
    }

    private func beginAuthentication(_ call: CAPPluginCall, requestedLock: Bool?) {
        guard pending == nil else { call.reject("裝置驗證正在進行", "AUTH_BUSY"); return }
        let auth = LAContext()
        auth.localizedCancelTitle = "取消"
        var error: NSError?
        guard auth.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            call.reject("請先在 iPhone 設定裝置密碼或生物辨識", "AUTH_UNAVAILABLE")
            return
        }
        pending = call
        context = auth
        let reason = call.getString("reason") ?? "確認身分後開啟薪資資料或變更鎖定設定"
        auth.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason) { [weak self] success, error in
            DispatchQueue.main.async {
                guard let self = self, let activeCall = self.pending else { return }
                self.pending = nil
                self.context = nil
                guard success else {
                    let code = (error as? LAError)?.code
                    let cancelled = code == .userCancel || code == .appCancel || code == .systemCancel
                    activeCall.reject(cancelled ? "已取消裝置驗證" : "裝置驗證未通過",
                                      cancelled ? "AUTH_CANCELLED" : "AUTH_ERROR")
                    return
                }
                // Persist changes only after successful device authentication.
                if let enabled = requestedLock {
                    UserDefaults.standard.set(enabled, forKey: Self.lockKey)
                }
                activeCall.resolve(self.status())
            }
        }
    }

    deinit {
        context?.invalidate()
        observers.forEach { NotificationCenter.default.removeObserver($0) }
    }
}
