# Google Play Console 發布檢查

## 不可逆決策

- [ ] 在 Play Console 確認 `com.salarymate.personal` 可建立且確定長期使用。
- [ ] 確認開發者帳戶法定名稱、地址、電話及 Email 驗證狀態。
- [ ] 啟用 Play App Signing，保存 upload key 與憑證資訊。
- [ ] 確認 v4.1.0 沿用既有 upload key 與 alias，沒有重建金鑰。

## 技術產物

- [ ] `versionCode 12`、`versionName 4.1.0`。
- [ ] target SDK 36、compile SDK 36。
- [ ] 上傳 signed AAB 至 Internal testing，不直接進 Production。
- [ ] App Bundle Explorer 無阻擋錯誤。
- [ ] 預發布報告無啟動、崩潰、ANR、權限或 16 KB page-size 阻擋問題。
- [ ] RC.1 的 1～72 驗收紀錄完成並核對 `RELEASE_GATE_v4.1.0-RC.1.md`。
- [ ] Internal testing 的 Play 安裝版通過 `ANDROID_v4.1.0_ACCEPTANCE.md`。
- [ ] Google Play 處理完成後，以測試連結驗證現有正式版 → v4.1.0 原地升級，不解除安裝。

## 商店與政策

- [ ] 填入開發者聯絡 Email。
- [ ] 將 `PRIVACY_POLICY_zh-TW.md` 定稿並發布為公開固定網址，App 與商店敘述一致。
- [ ] 完成 Data safety；特別核對使用者主動將加密薪資備份交給文件／分享服務的申報方式。
- [ ] 完成 App access（無登入）、Ads（無廣告）、內容分級、目標族群與財經功能聲明。
- [ ] 完成 App 圖示、Feature graphic、手機截圖、繁中商店文字與版本說明。
- [ ] 若帳戶受測試門檻約束，依 Play Console 顯示完成封閉測試人數與天數。

## 發布控制

- [ ] 保留 RC.1、既有正式安裝與至少兩份已驗證的加密備份。
- [ ] v4.1.0 使用 versionCode 12，不重用 RC.1 的 11。
- [ ] `FORMAL_RELEASE_EVIDENCE.md` 全部完成且審核通過後，才考慮 Production。

官方依據：

- Target API：https://support.google.com/googleplay/android-developer/answer/11926878
- Play App Signing：https://support.google.com/googleplay/android-developer/answer/9842756
- Data safety：https://support.google.com/googleplay/android-developer/answer/10787469
