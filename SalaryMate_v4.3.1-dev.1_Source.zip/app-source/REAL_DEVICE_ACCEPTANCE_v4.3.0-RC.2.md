# SalaryMate v4.3.0-RC.2｜Release Candidate Real-Device Acceptance

## Current decision
- Physical execution: **NOT_RUN**
- RC.2 source compile fix: **READY_FOR_REBUILD**
- Stable promotion: **HOLD FOR RELEASE**

## Required Android evidence
- Real device: NOT_RUN
- Signed build identity: NOT_RUN
- compileDebugKotlin / testDebugUnitTest / assembleDebugAndroidTest: NOT_RUN
- In-place upgrade: NOT_RUN
- Upgrade / data preservation: NOT_RUN
- Historical OT physical count = 1,373: NOT_RUN
- Backup / restore physical round-trip: NOT_RUN
- Lifecycle / background / foreground: NOT_RUN
- Long session: NOT_RUN
- TalkBack / keyboard / touch acceptance: NOT_RUN
- Wrong-company Write = 0: NOT_RUN
- Duplicate Commit = 0: NOT_RUN

## Required iOS evidence
- Real device: NOT_RUN
- Signed/native build identity: NOT_RUN
- Upgrade / data preservation: NOT_RUN
- Backup / restore physical round-trip: NOT_RUN
- VoiceOver / Dynamic Type / keyboard: NOT_RUN
- Lifecycle / background / foreground: NOT_RUN
- Long session: NOT_RUN
- Wrong-company Write = 0: NOT_RUN
- Duplicate Commit = 0: NOT_RUN

## Golden flow
Launch → Current Company A → Quick Entry → Payroll A → Create B → Switch B → Payroll B → Switch A → Verify isolation → Backup → Modify → Restore → Restart.

## Physical backup / lifecycle golden
- State A → Backup → State B → Restore → State A
- Background → Foreground preserves Draft / Context
- Force Close → Relaunch preserves persisted data and never auto-commits an unsaved Draft
- Corrupt / unsupported backup leaves existing data unchanged

## Zero-tolerance release conditions
- Wrong-company Write = 0
- Context Leakage = 0
- Stale Company Exposure = 0
- Duplicate Commit = 0
- Data Loss = 0

Stable promotion remains blocked until every required item is PASS.
