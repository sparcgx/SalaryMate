# v4.0.0-rc.3 發布閘門

範圍：上架前殘留清理與權限最小化。Production 發布不在本階段授權範圍內。

| 閘門 | 狀態 | 說明 |
|---|---|---|
| RC2 已驗證基線 | PASS | signed APK／AAB 與實機測試已完成；詳見 `BASELINE_RC2_RELEASE_GATE.md` |
| 薪資與 Schema 13 行為凍結 | PASS | runtime、儲存、SQLite 交易、加密、匯入、快照與移轉回歸全部通過 |
| 正式 App ID 與版本 | PASS | `com.salarymate.personal`、versionCode 6、versionName `4.0.0-rc.3`；Debug 使用 `.debug` |
| Android 權限最小化 | PASS | Manifest 只保留生物辨識／舊版指紋相容權限；不宣告 `INTERNET` |
| Google Services 範本清理 | PASS | 移除未使用的 Gradle classpath 與 plugin 套用入口 |
| PWA 網頁殘留清理 | PASS | Android 原生包移除安裝提示、Service Worker 更新邏輯與無效 UI |
| 正式版示範資料入口 | PASS | 移除 UI、action 與內嵌示範資料，避免覆寫正式資料 |
| Android 測試身分 | PASS | 移除 `com.getcapacitor.myapp` 範本，測試改為 `com.salarymate.personal` |
| Android 測試工作範圍 | PASS | Windows R1 僅執行 `:app:` 測試工作，不誤觸第三方外掛的 AndroidTest 變體 |
| 簽章快速預檢 | PASS | npm／Gradle 前驗證 keystore、alias、儲存庫密碼及私鑰密碼；不輸出秘密 |
| 建置輸出清理 | PASS | 每次重建 `www`，不再把僅供 Node 回歸的 `storage.js` 複製進 App |
| 執行期依賴安全 | PASS | `npm audit --omit=dev`：0 項弱點 |
| 候選原始碼封裝 | PASS | `npm ci`、全測試、Web build、Capacitor sync、殘留掃描與檔案完整性均通過 |
| Windows signed APK／AAB | PENDING | 使用 RC2 upload key 執行 `BUILD_SIGNED_ANDROID_WINDOWS.ps1` |
| RC2 → RC3 覆蓋升級 | PENDING | 同一 upload key、`adb install -r`、不解除安裝，核對原資料與保護快照 |
| R7 → RC3 資料移轉 | PENDING | 實機核對摘要、金額、假別與 `100.111` 時薪快照 |
| Play Internal testing | PENDING | 上傳 AAB、等待官方處理並完成 Play 安裝版 1–20 驗收 |

判定：原始碼 Gate 全部 PASS 後可交付 RC3 Windows／Android 候選包；signed 產物、覆蓋升級、資料移轉與 Play Gate 未完成前，不得建立 v4.0.0 Production。

完整開發依賴稽核仍有 3 項 moderate，皆來自只在建置階段使用的 `@capacitor/cli → xcode → uuid@7` 間接鏈，不進入 App runtime。現行最新穩定 Capacitor CLI 仍依賴該鏈，`npm audit fix --dry-run` 沒有可套用變更；本版未使用高風險 override 強制跨 major 替換。
