# v4.1.0-RC.1｜完整回歸、覆蓋升級與候選版閘門

日期：2026-09-22

## 基線與版本身分

- 輸入基線：`v4.1.0-dev.4-R2｜FileProvider Authority Build Fix`。
- dev.4-R2 已完成 Windows 建置與 1～58 驗收，維持凍結且不直接修改。
- RC.1：`versionCode 11`／`versionName 4.1.0-RC.1`。
- Release App ID：`com.salarymate.personal`；Debug App ID：`com.salarymate.personal.debug`。
- `salarymateSQLite.db`、Schema 13、Snapshot 最近三份、1,373 筆歷史 OT 與 `.salarymate` 加密格式不變。

## 候選版控制

| Gate | 狀態 | 通過條件 |
|---|---|---|
| 凍結基線隔離 | PASS | RC.1 使用獨立工作樹；dev.4-R2 原始碼與交付包不修改 |
| 版本一致性 | PASS（靜態／資產） | Web、Compose、Gradle、npm、同步後 Android 資產與 APK／AAB 名稱均為 RC.1／versionCode 11 |
| 本機完整回歸 | PASS | `npm test`、Web build、Android sync 全部成功；runtime audit 為 0 個弱點 |
| Kotlin／Android 編譯 | 待 Windows | unit test、instrumentation test APK、Debug APK、signed Release APK／AAB 均可編譯 |
| 連接實機 Gate | 待 Windows／Android | `RUN_RC1_DEVICE_GATE_WINDOWS.cmd` 成功，instrumentation tests 無失敗 |
| 簽章與權限 | 待 Windows | APK/AAB 簽章有效；正式 App ID、versionCode 正確；無非預期敏感權限 |
| 覆蓋升級 | 待實機 | 相同簽章以 `adb install -r` 升級，不解除安裝、不清除資料、不降版 |
| 資料完整性 | 待實機 | 公司、薪資、加班、請假、年終、調薪、1,373 筆歷史 OT 與關鍵金額前後一致 |
| 備份跨版互通 | 待實機 | dev.4-R2 ↔ RC.1 加密備份往返，錯誤密碼與損壞檔案維持 fail-closed |
| 完整實機回歸 | 待實機 | `ANDROID_RC1_ACCEPTANCE.md` 1～72 全部 PASS |
| Play 候選版 | 待 Internal testing | 只上傳 Internal testing，完成 Play 安裝版重點回歸與預發布報告 |

## 自動化證據

- `BUILD_COMPOSE_DEBUG_WINDOWS.cmd`：Debug unit／instrumentation 編譯、身分、簽章與權限檢查。
- `RUN_RC1_DEVICE_GATE_WINDOWS.cmd`：在連接裝置執行 `connectedDebugAndroidTest` 並核對 Debug 身分。
- `BUILD_SIGNED_ANDROID_WINDOWS.ps1`：以隱藏密碼輸入啟動 signed APK／AAB 建置。
- `BUILD_ANDROID_WINDOWS.cmd`：Release 簽章、App ID、versionCode、權限、APK／AAB 輸出與 SHA-256。
- `INSTALL_TO_ANDROID_WINDOWS.cmd`：保存升級前後版本身分並只使用 `adb install -r`。

## GO／HOLD

- 目前狀態：**HOLD FOR RELEASE**。
- 本機封裝通過只代表可進入 Windows 與 Android 候選版驗證，不等於可發布。
- 1～72、簽章／權限、覆蓋升級、備份互通與 Internal testing 全部通過後，才能標記 **GO FOR RELEASE REVIEW**。
- 任一資料差異、簽章衝突、崩潰、ANR、非預期權限或備份失敗，立即停止並維持 HOLD。
