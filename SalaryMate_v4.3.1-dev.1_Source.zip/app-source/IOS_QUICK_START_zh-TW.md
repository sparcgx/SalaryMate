# SalaryMate v4.2.0-dev.1｜iOS Hybrid Foundation

這是可重建的開發原始碼包，尚未包含簽署的 IPA。先在 Mac 準備工程，再以 Xcode 安裝至 iPhone。

## 1. 準備 Mac

- 完整 Xcode 26 或更新版本；先啟動一次，完成必要元件安裝與授權。在 Xcode Settings → Locations 確認 Command Line Tools 選到這份 Xcode。
- Node.js 22.13 或更新版本（建議使用已安裝的 LTS 版本）。
- 自動模擬器測試需在 Xcode Settings → Components 安裝一個 iOS runtime。
- 本 App 的最低部署版本為 iOS 16；iPhone 15 在此範圍內。
- 首次準備需要網路下載 npm 與 Swift 套件；安裝後日常薪資登記可離線。

## 2. 開啟工程

將 ZIP 解壓到自己的專案資料夾，例如 `~/Projects/SalaryMate_ios_dev1`。開啟其中的 `PREPARE_IOS_MAC.command`。

若 macOS 未直接執行 `.command`，可在「終端機」先輸入 `cd `，將解壓後的資料夾拖入終端機，按 Enter，再執行：

```bash
bash PREPARE_IOS_MAC.command
```

它會依序檢查環境、安裝鎖定的 npm 套件、跑回歸、建立 Web 資產、同步 iOS 外掛、解析 Swift 套件，最後開啟 `ios/App/App.xcodeproj`。本版使用 Swift Package Manager，不需要執行 `pod install`。

PREPARE_ONLY 的 PASS 只表示準備完成，還不表示 Swift 建置或 iPhone 驗收已完成。

## 3. 用 Xcode 安裝 iPhone

1. 選擇 `App` target，進入 Signing & Capabilities，選擇自己的 Team。
2. Debug 的 Bundle Identifier 預設為 `com.salarymate.personal.iosdev`。若 Personal Team 要求唯一名稱，可改成自己的識別碼；之後更新請沿用相同 Team 與識別碼。
3. 連接並信任 iPhone；依 Xcode／iPhone 指示啟用 Developer Mode。
4. Xcode 上方選 `App` scheme 與自己的 iPhone，按 Run。
5. 手機上會出現 **SalaryMate iOS Dev**。依 `IOS_DEV1_ACCEPTANCE.md` 測試。

請先使用測試資料。Debug 與 Release 是不同 App 沙盒；Android、iPhone、Web 之間不會自動同步。資料移轉使用使用者主動建立的加密備份。

## 4. 產生自動測試紀錄

```bash
bash RUN_IOS_FOUNDATION_GATE_MAC.command
```

此入口重新檢查工程後，建立本次專用的全新模擬器，執行 Xcode build + XCTest，測試「App 啟動／原生 SQLite 就緒→由畫面建立公司→終止 App→重新啟動→讀回同一家公司」。完成後只清理本次建立的測試模擬器。

每次執行都會建立 `test-results/ios-v4.2.0-dev.1/<執行編號>/`：

| 檔案 | 內容 |
|---|---|
| result.txt | 成功、失敗、中斷與未執行摘要 |
| result.json | 每一步狀態、執行時間與結束代碼 |
| test.log | 完整指令輸出 |
| Foundation.xcresult | Xcode 測試證據；只有實際進入該步驟才會產生 |

沒有 Mac、沒有 Xcode、沒有 runtime 或編譯失敗都會留下 FAIL；後續步驟保持 NOT_RUN。一般中斷記為 INCOMPLETE。突然斷電時，先前已寫入的紀錄仍維持未完成狀態。

模擬器 PASS 不涵蓋 iPhone Face ID、檔案供應商、分享、實機背景切換與跨平台備份；這些請依驗收表執行。測試後提供 `result.txt`、`result.json`；失敗時加上檢查過個人路徑與私密資訊的 `test.log`。

## 使用上的能力界線

- iOS 背景畫面保護會遮住離開 App 時的預覽；不阻擋系統截圖或螢幕錄影。
- App 鎖使用 LocalAuthentication；密碼、生物辨識資料不交給 Web 核心。
- SQLite 沿用既有未啟用 SQLCipher 加密的模式；App 鎖不是資料庫加密。
- 另存 `.salarymate` 使用「檔案」選擇器並讀回驗證。如果雲端檔案供應商不能立即讀回，會回報失敗；可改存至「我的 iPhone」。失敗時不會自動刪除供應商端可能已存在的檔案。
- iOS 匯入沿用系統檔案選擇器，接受 `.salarymate`、BIN、`.file`、舊 JSON，仍以內容驗證。解密後要核對摘要並確認才會寫入。
- SwiftUI 原生首頁、跨裝置自動同步及 App Store／TestFlight 發布不在 dev.1 範圍。

官方參考：

- https://capacitorjs.com/docs/ios
- https://capacitorjs.com/docs/ios/custom-code
- https://capacitorjs.com/docs/ios/privacy-manifest
- https://github.com/capacitor-community/sqlite
