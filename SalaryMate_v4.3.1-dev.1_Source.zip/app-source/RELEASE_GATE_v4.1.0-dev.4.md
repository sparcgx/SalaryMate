# v4.1.0-dev.4｜原生備份、分享、安全與效能補強開發閘門

日期：2026-09-22

## 基線與版本

- 輸入基線：`v4.1.0-dev.3-R2｜Kotlin Money Formatter Conflict Fix`。
- dev.3-R2 保持唯讀；dev.4 使用獨立工作樹。
- 本分支升版為 `versionCode 10`／`versionName 4.1.0-dev.4`。
- `salarymateSQLite.db`、Schema 13、`snapshots` 表與既有 Web 加密備份格式不變。

## R2｜FileProvider Authority Build Fix

- Windows R1 Kotlin 編譯於 `NativeBackupService.kt` 因 `BuildConfig` 無法解析而停止。
- R2 移除 `com.salarymate.personal.BuildConfig` import，FileProvider authority 改由 `appContext.packageName` 組成。
- 執行期 package name 會分別對應正式版與 Debug 的 application ID，並與 Manifest 的 `${applicationId}.fileprovider` 一致。
- 新增靜態回歸守衛：備份服務不得引用 `BuildConfig`，且服務與 Manifest 必須保留相符的 authority 規則。
- 本次只修正建置阻斷，不變更版本身分、SQLite、Schema、加密格式或功能範圍。

## 開發閘門

| 檢查 | 狀態 | 證據／限制 |
|---|---|---|
| 基線隔離 | PASS | dev.3-R2 工作樹與交付 ZIP 未修改 |
| 單一資料來源 | PASS（靜態） | 原生備份直接匯出／還原既有 Schema 13 snapshot，未建立 backup 資料表 |
| 加密格式相容 | PASS（規格） | AES-256-GCM、PBKDF2-SHA-256、310,000 次、16-byte salt、12-byte IV、128-bit tag 與相同 AAD |
| 密碼保護 | PASS（靜態） | 建立備份至少 12 字元；密碼只存在目前操作記憶體，不寫入偏好設定或檔案名稱 |
| 另存驗證 | PASS（靜態） | SAF 系統另存後重新讀取並以 SHA-256 比對 |
| 分享保護 | PASS（靜態） | 只分享已加密快取檔，FileProvider 僅授予暫時讀取權限 |
| 還原失敗關閉 | PASS（靜態） | 密碼、標記、大小、UTF-8、Schema 及必要陣列任何一項失敗皆不呼叫 snapshot 寫入 |
| 快照交易 | PASS（沿用） | 還原使用既有交易新增完整 snapshot 並保留最近 3 份 |
| App 鎖 | PASS（靜態） | 變更前要求 BiometricPrompt／DEVICE_CREDENTIAL；取消不改設定 |
| 螢幕保護 | PASS（靜態） | 原生切換 `FLAG_SECURE` 並共用既有偏好鍵 |
| 生命週期保護 | PASS（靜態） | 系統另存、選檔及分享期間不觸發 App 自動鎖定清除待處理作業 |
| 效能邊界 | PASS（靜態） | PBKDF2／AES 在 Default dispatcher，檔案處理在 IO dispatcher，單一 busy guard 防重入 |
| Node／Web 回歸 | PASS | 完整 `npm test`、Web build、Android sync 通過；runtime audit 為 0 個弱點 |
| Android 編譯 | R1 FAIL／R2 待 Windows | R1 已定位為 `BuildConfig` unresolved reference；R2 已移除依賴，仍需由 Windows 建置腳本確認 Kotlin 與 instrumentation 編譯 |
| Android 12 實機 | 待驗收 | 抽測基線並完成 29～58 |

## GO／HOLD

- 本機回歸與乾淨封裝通過後，可進入 Windows Debug APK 建置。
- 在 Kotlin 編譯、29～58 實機驗收與加密格式雙向互通完成前，狀態為 **HOLD FOR RELEASE**。
- 不得上傳 Production；需要商店驗證時只使用 Google Play Internal testing。
