# SalaryMate v4.3.0-dev.2｜PAX-06 Full Regression & dev.2 Freeze Gate

## Gate decision
- PAX-01 Visual Polish: **PASS / PRESERVED**
- PAX-02 Accessibility: **PASS / PRESERVED**
- PAX-03 Validation: **PASS / PRESERVED**
- PAX-04 State Hardening: **PASS / PRESERVED**
- PAX-05 Operational Safety: **PASS / PRESERVED**
- PAX-06 Development Source Freeze: **PASS**
- Executable source gates: **27 / 27 PASS**
- Product FAIL: **0**
- Full platform build/device gate: **PENDING_ENVIRONMENT**
- Physical accessibility/state/operational QA: **PENDING_DEVICE_QA**
- RC / Stable promotion: **NOT AUTHORIZED**

## Identity
- Product: `4.3.0-dev.2`
- Release target: `4.3.0`
- Android versionCode: `15`
- iOS build: `3`
- Schema: `13`
- Version Drift: `0`

## Critical freeze contracts
- Payroll / Tax / OT / Year-End calculations remain unchanged.
- Tax boundary: `86,000 -> 0`, `86,001 -> 0`, `86,002 -> 4,300`.
- OT multipliers: `1 / 1.34 / 1.67 / 2 / 2.67`; Lunar New Year `2.5`.
- Year-End runtime Golden: `$153,900`.
- Historical OT retained evidence: `914 + 459 = 1,373`, `1,373 unique`.
- Snapshot retention: latest `3`.
- Wrong-company write observed automated: `0`.
- Duplicate UI write observed automated: `0`.
- Current Company silent first-company fallback: `0`.
- Schema: `13`; no second payroll/OT/leave/company/salary canonical store.

## Environment pending
- `npm run build`: `esbuild` unavailable in the current execution environment.
- iOS Foundation parser/native build: `xcode` npm module unavailable; `ios-gate-test` PASS.
- Android SDK / ADB / Gradle / physical device unavailable in the current execution environment.

## Freeze policy
`v4.3.0-dev.2` is a frozen development-source baseline. No feature work is permitted on the frozen snapshot. Platform build/device validation remains mandatory before RC readiness.

DEVELOPMENT SOURCE FREEZE
PENDING_ENVIRONMENT
RC / Stable promotion: NOT AUTHORIZED
