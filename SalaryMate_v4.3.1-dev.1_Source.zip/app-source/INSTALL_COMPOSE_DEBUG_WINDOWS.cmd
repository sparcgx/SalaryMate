@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SalaryMate v4.3.1-dev.1 Compose Debug Install

if not "%ANDROID_HOME%"=="" goto sdk_ready
if not exist "%LOCALAPPDATA%\Android\Sdk" goto sdk_ready
set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
:sdk_ready

set "ADB=%ANDROID_HOME%\platform-tools\adb.exe"
set "APK=%CD%\output\SalaryMate_v4.3.1-dev.1-compose-debug.apk"

if not exist "%ADB%" goto missing_adb
if not exist "%APK%" goto missing_apk

echo This Debug App uses package com.salarymate.personal.debug.
echo It installs beside the Release App and does not read or overwrite Release private data.
echo Use synthetic data or import a copied encrypted backup for testing.
echo.
echo Enable Android Developer Options and USB debugging.
echo Connect the unlocked phone, then approve the USB debugging prompt.
echo.
"%ADB%" devices
echo.
echo Installing the Compose Debug APK without clearing existing Debug data...
"%ADB%" install -r "%APK%"
if errorlevel 1 goto failed

echo.
echo SUCCESS. Run RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd, then follow ANDROID_v4.1.0_ACCEPTANCE.md.
pause
exit /b 0

:missing_adb
echo HOLD: ADB was not found. Install Android SDK Platform-Tools in Android Studio.
goto hold

:missing_apk
echo HOLD: Run BUILD_COMPOSE_DEBUG_WINDOWS.cmd first.
goto hold

:failed
echo.
echo INSTALL FAILED. Do not uninstall the Release App or clear either App.
echo If you see unauthorized, unlock the phone and approve USB debugging.

:hold
pause
exit /b 1
