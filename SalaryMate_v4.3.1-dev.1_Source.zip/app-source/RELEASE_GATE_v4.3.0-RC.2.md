# SalaryMate v4.3.0-RC.2｜Android Compile Integration Fix & Release Candidate Freeze Gate

## Current decision
- RC.2 compile-integration source gate: **PASS**
- Source readiness: **SOURCE_READY_DEVICE_PENDING**
- Android compile issue from RC.1: **FIXED IN SOURCE / REAL BUILD RECHECK REQUIRED**
- Production build: **PENDING_ENVIRONMENT**
- Android real device: **PENDING_DEVICE_QA**
- iOS real device: **PENDING_DEVICE_QA**
- Stable promotion: **NOT AUTHORIZED**

## RC.2 scope
RC.2 contains only Android Compose compile-integration corrections:
1. `NativeErrorCard` failed-state calls use the named `onOpenHealth` argument.
2. `PayrollIdentityBox` visibility changes from file-private to module-internal so Quick Entry can reuse the existing UI component.
3. `SalaryMateShell.kt` imports `NativeSnapshot` explicitly.

No Schema, repository, payroll math, storage, backup, snapshot, company-isolation or payroll-rule logic is changed.

## Frozen invariants
- Schema 13
- Package `com.salarymate.personal`
- Android versionCode 19
- iOS build 7
- NativePayrollMath unchanged
- NativeSalaryMateRepository unchanged
- Storage / Snapshot / Backup Crypto unchanged
- Tax boundary 86,000 → 0; 86,001 → 0; 86,002 → 4,300
- OT 1 / 1.34 / 1.67 / 2 / 2.67; Lunar New Year 2.5
- Year-End Runtime Golden 153,900
- Historical OT retained contract 1,373
- Wrong-company Write = 0
- Duplicate UI Write = 0

## Stable rule
A source-level compile fix does not authorize Stable. Android/iOS production build, in-place upgrade, data preservation, physical backup/restore, lifecycle, accessibility and manual acceptance remain required.
