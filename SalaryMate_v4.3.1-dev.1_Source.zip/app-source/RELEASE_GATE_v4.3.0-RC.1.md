# SalaryMate v4.3.0-RC.1｜Full Regression & Release Candidate Freeze Gate

## Current decision

- RC SOURCE FREEZE GATE: **PASS**
- Source readiness: **SOURCE_READY_DEVICE_PENDING**
- Production build: **PENDING_ENVIRONMENT**
- Android real device: **PENDING_DEVICE_QA**
- iOS real device: **PENDING_DEVICE_QA**
- Upgrade / data preservation: **PENDING_DEVICE_QA**
- Backup / restore physical round-trip: **PENDING_DEVICE_QA**
- Lifecycle / long-session: **PENDING_DEVICE_QA**
- Stable promotion: **NOT AUTHORIZED**

## RC.1 freeze rules

RC.1 source freeze requires all source regression gates, version identity, package integrity, storage/backup/security, cross-company isolation, Payroll/Tax/OT/Year-End Golden and evidence schemas to PASS.

Physical Android/iOS build, upgrade, backup/restore, lifecycle and manual acceptance remain separate evidence. Source freeze PASS does not imply Stable eligibility.

## Frozen invariants
- Schema 13
- Package `com.salarymate.personal`
- Android versionCode 18
- iOS build 6
- NativePayrollMath / Repository / Storage / Snapshot / Backup Crypto unchanged from dev.4
- Native Backup may differ only in product-version binding
- Tax boundary 86,000 → 0; 86,001 → 0; 86,002 → 4,300
- OT 1 / 1.34 / 1.67 / 2 / 2.67; Lunar New Year 2.5
- Year-End Runtime Golden 153,900
- Historical OT retained contract 1,373 / 1,373 unique identities
- Wrong-company Write = 0 in automated regression
- Duplicate UI Write = 0 in automated regression

## Result vocabulary
- RC source freeze: PASS
- Physical acceptance: PENDING_DEVICE_QA
- Stable: NOT AUTHORIZED
