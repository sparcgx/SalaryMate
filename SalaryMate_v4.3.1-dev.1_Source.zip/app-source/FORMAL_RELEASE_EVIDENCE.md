# SalaryMate v4.1.0｜正式版驗收證據紀錄

狀態：HOLD FOR RELEASE（尚未填入 Windows／Android／Play 實測證據）

請附檔案或填入實際結果；「未提供」不得改寫為 PASS。請勿貼上密碼、keystore 或完整薪資資料。

執行 `RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd` 後，從 `test-results\formal-v4.1.0\<執行編號>\` 附上 `result.txt`、`result.json` 與必要的 `test.log`（先檢查是否含私密資料）。只將實際完成的自動化裝置測試列為 PASS；手動 1～72、升級、備份與 Play 項目保持未測，直到另附實際驗收證據。

| 項目 | 結果（PASS／FAIL／未測） | 證據檔／日期 |
|---|---|---|
| RC.1 1～72 實機測試 | 未測 | |
| RC.1 signed APK／AAB、憑證指紋與 SHA-256 | 未測 | |
| RC.1 同簽章覆蓋升級與資料保留 | 未測 | |
| RC.1 雙向備份互通與失敗防寫入 | 未測 | |
| RC.1 Internal testing 與 Play 安裝版 | 未測 | |
| v4.1.0 Windows Debug 與裝置測試 | 未測 | |
| v4.1.0 signed Release APK／AAB 與版本 12 | 未測 | |
| v4.1.0 安裝前後筆數／金額與 1,373 筆 OT | 未測 | |
| v4.1.0 備份還原與 App 鎖狀態 | 未測 | |
| v4.1.0 Internal testing／預發布檢查 | 未測 | |

驗收裝置／Android 版本：

現有正式 App 安裝來源（本機 APK／Play）：

備份存放位置（不填密碼）：

簽章憑證 SHA-256 指紋（不填金鑰）：

Release APK SHA-256：

Release AAB SHA-256：

資料筆數與關鍵金額對照（避免填個資，可用雜湊／差異數量）：

失敗項／處理紀錄：

最終放行者／日期：未核准
