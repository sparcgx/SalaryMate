# v4.0.0-dev.4 R7 發布閘門

候選用途：Windows 建置包與 Android Debug APK 實機驗收。此版本不發布網站或商店。

| 閘門 | 狀態 | 證據 |
|---|---|---|
| 1. 套件完整性 | PASS | 封裝必要檔與內含 runtime smoke test 均存在 |
| 2. 薪資／Schema 13 回歸 | PASS | 既有公式、到職年／日、時薪快照與 Schema 13 全通過 |
| 3. SQLite 與快照安全 | PASS | 交易、三份保留、回滾、移轉及清除測試通過 |
| 4. 加密、錯誤密碼與竄改 | PASS | AES-GCM、KDF 上限、錯誤密碼、竄改與損壞檔拒絕通過 |
| 5. 原生 `.salarymate` 另存 | PASS | 儲存前自驗證、精確副檔名、寫回雜湊與取消重試測試通過 |
| 6. BIN／`.file` 內容式匯入 | PASS | 四種檔名及舊 JSON 依實際內容辨識測試通過 |
| 7. 裝置驗證與畫面保護 | PASS | 冷啟動、取消／重試、前景再鎖與保護切換通過 |
| 8. Android 發布硬化 | PASS | `versionCode 3`、原生插件註冊、Manifest 與 Windows 指令檢查通過 |
| 9. Windows 封裝完整性 | PASS | 乾淨來源重裝、測試、建置與 Capacitor 同步通過；ZIP 無損壞且內含 runtime smoke／原生插件 |

執行期依賴稽核：`npm audit --omit=dev` 為 0 項弱點。完整開發依賴仍由 Capacitor CLI 的 `xcode → uuid` 間接鏈帶入 3 項 moderate，未進入 Android App 執行期資產；未自行執行可能變更 lockfile 的 `npm audit fix`。

目前受控環境不宣稱完成 Windows 正式簽章建置。實機基線已由使用者確認：R7 的 1–16 均在 ZenFone 7 Pro／Android 12 通過。
