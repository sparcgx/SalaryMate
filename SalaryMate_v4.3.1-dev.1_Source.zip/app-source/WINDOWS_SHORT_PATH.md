# Windows 路徑過長處理｜dev.4 R1 ShortPath

## 錯誤說明

若 Windows 檔案總管顯示 `0x80010135：路徑太長`，代表 ZIP 所在路徑、壓縮包內層目錄與 Android 原始碼目錄相加後過長；檔案本身沒有損壞。

`dev.4 R1 ShortPath` 已縮短壓縮檔與內層根目錄；功能內容、Schema 13 與一般交付包相同。

## 正確解壓方式

1. 若錯誤視窗仍開著，選擇「取消」，不要選擇「略過」。
2. 將 dev.4 R1 ZIP 放在 `C:\`、`C:\Temp` 或「下載」資料夾。
3. 對 ZIP 按右鍵並選擇「全部解壓縮」。
4. 建議目的地填入：`C:\SalaryMate\dev4`。
5. 完成後進入 `SalaryMate_dev4_R1`，執行 `BUILD_COMPOSE_DEBUG_WINDOWS.cmd`。

不需要修改登錄檔或開啟 Windows 長路徑原則。若仍出現同一錯誤，請回報解壓目的地的完整路徑。
