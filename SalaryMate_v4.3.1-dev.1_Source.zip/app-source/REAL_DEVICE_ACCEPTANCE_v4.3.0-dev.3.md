# SalaryMate v4.3.0-dev.3｜Real-Device Acceptance

Status: **PENDING_DEVICE_QA**

## Android / iOS Golden Flow

Launch → Current Company A → Quick Entry → Payroll A → Create B → Switch B → Payroll B → Switch A → Verify isolation → Backup → Modify → Restore → Restart.

## Mandatory checks

- Wrong-company Write = 0
- Context Leakage = 0
- Stale Company Exposure = 0
- Duplicate Commit = 0
- Data Loss = 0
- Background → Foreground preserves Draft/Context.
- Force Close → Relaunch preserves persisted data and never auto-commits unsaved draft.
- State A → Backup → State B → Restore → State A.
- Corrupt / unsupported backup must leave existing data unchanged.
- Existing installation must be upgraded in-place; do not uninstall or clear app data.
- Historical OT physical count must be verified after upgrade.

This document is an acceptance checklist, not PASS evidence.
