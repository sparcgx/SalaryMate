# SalaryMate v4.3.0｜Source of Truth

- Canonical product line: `v4.3.0`
- Current implementation baseline: `v4.3.0-dev.1`
- Schema: `13`
- Android package: `com.salarymate.personal`
- Android versionCode: `14`
- iOS MARKETING_VERSION: `4.3.0`
- iOS CURRENT_PROJECT_VERSION: `2`
- GitHub prior Web Stable baseline: `fe3da26698e09470f895733309b0bc64c6d96e6a` (`v4.2.0-web`)

`version.json` is the canonical human-maintained version record for this integration baseline.

## Freeze invariants

This integration must not introduce a second Company / Attendance / OT / Addition / Payslip store and must not change Schema 13, NativeSalaryMateRepository or NativePayrollMath business behavior.
