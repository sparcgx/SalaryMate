# GitHub × GPT 工作站同步規則

The same canonical source archive and SHA-256 should be used on both sides.

GitHub `main` / `stable/v4.2.0-web` remains the immutable v4.2.0 Web freeze baseline.
The v4.3.0 development line must use a separate branch and must not overwrite the existing stable branch.
