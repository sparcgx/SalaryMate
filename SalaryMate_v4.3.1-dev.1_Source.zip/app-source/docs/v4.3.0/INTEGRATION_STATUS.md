# v4.3.0-dev.1｜Canonical Integration Baseline

## Completed in this package

- Unified active product identity to `4.3.0-dev.1`.
- Added canonical `version.json`.
- Android: versionName `4.3.0-dev.1`, versionCode `14`.
- iOS: marketing version `4.3.0`, build `2`, runtime version `4.3.0-dev.1`.
- Schema remains `13`.
- Existing NativeSalaryMateRepository and NativePayrollMath architecture retained.
- Existing Company/companyId/current-company data contract retained.

## Not claimed as completed

The CM-01～CM-06, PAX-01～PAX-06, RI-01～RI-06, RC.1 and Stable gates defined in GPT are acceptance specifications. Their actual PASS state is still **PENDING** until implementation-specific regression and real-device evidence exists.

This package therefore MUST NOT be labeled `v4.3.0 Stable`.
