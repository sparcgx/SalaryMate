# PAX-04｜Loading / Empty / Failure State Hardening

Status: **IMPLEMENTATION REGRESSION PASS / DEVICE QA PENDING**

## State contract

Web distinguishes `Idle / Loading / Ready / Empty / Invalid / Failure` plus operation `Submitting`.
Android shares `Loading / Empty / Invalid / Ready / Failed` and uses the same Current Company validity rules.

Key rule: `Loading ≠ Empty`, `Empty ≠ Invalid`, `Invalid ≠ Failure`.

## Startup / read safety

- Stored-state parse/read failures render a Failure state.
- Startup failure does not replace persisted content with an empty state.
- Runtime smoke verifies corrupt storage is Failure, not Empty.
- Retry re-runs the original safe load operation.

## Current Company / stale context

- Invalid or absent Current Company blocks operational pages and routes recovery to Company Management.
- Company switch persists first and changes UI context only after persistence succeeds.
- Failed switch rolls memory/UI back to the previous company.
- Runtime smoke verifies failed persistence cannot leak the target company into current context.

## Write / restore safety

- `commitStateMutation` preserves original state on failed writes.
- Delete/sync operations use rollback-safe writes.
- Restore validates input before mutation and restores the pre-restore state if persistence fails.
- Restore success clears transient selections and re-resolves current state.
- Unreadable / unsupported / corrupt / restore-failure messages remain distinct.

## Regression

- Executable source gates: **25 / 25 PASS**
- Product FAIL: **0**
- Schema: `13`
- Version Drift: `0`

Core byte-identical to PAX-03 R1:
- NativePayrollMath
- NativeSalaryMateRepository
- Storage
- Snapshot Store
- Backup Crypto
- Native Backup

## Pending environment / device checks

- Production build: dependency environment lacks `esbuild`.
- Android native build/device: Android SDK is unavailable in this execution environment.
- iOS Foundation parser/native build: `xcode` npm module/Xcode unavailable.
- Physical Loading/Failure/Retry and lifecycle UI checks remain `PENDING_DEVICE_QA`.

Next: **PAX-05｜Navigation / Draft / Context Operational Safety**
