# CM-05｜Company Workflow Simplification & Cross-Platform UX

Status: **IMPLEMENTATION REGRESSION PASS / FULL PLATFORM GATE PENDING**

## Workflow contract

Formal root workflow:

```text
首頁
├─ 快速登記
├─ 薪資
├─ 年度總覽
├─ 公司管理
└─ 設定
```

Company operational flow:

```text
建立公司 → 設為目前公司 → 快速登記 → 建立薪資
          ↓
      公司管理 / 規則
```

## Current Company contract

- Operational modules consume one `CurrentCompanyContext`.
- No current company => operational creation fails closed.
- Company switch clears company-scoped transient drafts / selected state.
- Company Management may view/edit a non-current target company without silently switching current company.
- Web payroll / overtime / leave forms keep `companyId` as a hidden identity field; there is no module-local company selector.
- Android Quick Entry and Payroll use the current company only.

## Payroll creation

New payroll is a fixed 3-step flow:

1. 月份
2. 本月資料
3. 確認

Key rules:
- company is locked for the draft
- Step 1 validates duplicate scope by `companyId + payrollMonth`
- moving to a different month resets month-scoped transactions
- Step 3 performs final context validation before commit
- existing payroll editing remains a separate safe edit path

## Navigation / Draft safety

- Web root navigation supports browser Back/Forward when History API capability exists.
- Restricted / legacy WebViews without `pushState` continue using the existing navigation path.
- Dirty modal draft blocks navigation/company switching until save/discard decision.
- Android system Back returns root destinations to Home.
- Android payroll draft Back triggers an explicit discard confirmation.

## Regression

- Executable script gates: **20**
- PASS messages: **22**
- Product FAIL: **0**
- Version Drift: **0**
- Schema: **13**

Core byte-identical to CM-04 R1:
- `NativePayrollMath.kt`
- `src/storage.js`
- `src/snapshot-store.mjs`
- `src/backup-crypto.mjs`
- `src/native-backup.mjs`

Intentional Repository change:
- remove fallback-to-first-company behavior when no current company exists
- payroll creation now fails closed until a current company is explicitly selected

## Environment pending

- Android full Gradle / physical-device validation: `PENDING_ENVIRONMENT` (Android SDK unavailable in current execution container).
- iOS Foundation parser: `PENDING_ENVIRONMENT` (`xcode` npm module unavailable in current execution container).
- iOS result gate itself: PASS.

These are not recorded as product failures.

Next: **CM-06｜Full Regression & dev.1 Freeze Gate**
