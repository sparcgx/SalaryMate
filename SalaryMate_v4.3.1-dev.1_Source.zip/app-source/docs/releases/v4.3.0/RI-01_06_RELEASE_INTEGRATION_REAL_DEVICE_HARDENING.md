# v4.3.0-dev.3｜Release Integration & Real-Device Hardening

Status: **SOURCE INTEGRATION REGRESSION PASS / REAL DEVICE PENDING**

## RI-01 Release identity
- Product `4.3.0-dev.3`
- Android versionCode `16`
- iOS build `4`
- Schema `13`
- `version.json` remains the single human-maintained identity source.
- Version promotion tooling now supports dev → dev → RC → Stable patterns.

## RI-02 Upgrade / Data preservation
- Android upgrade runner uses `adb install -r`.
- No uninstall / `pm clear` path is allowed.
- Pre/post package identity evidence remains mandatory.
- Schema remains 13; legacy encrypted backup compatibility is preserved.

## RI-03 Real-device evidence
Android and iOS result schemas now record separately:
- realDevice
- upgradeDataPreservation
- backupRestore
- lifecycle
- longSession

These values default to `NOT_RUN`; source automation cannot self-promote them to PASS without actual platform evidence.

## RI-04 Backup physical round-trip
The acceptance contract requires `State A → Backup → State B → Restore → State A`, plus corrupt/unsupported backup fail-closed validation. Physical execution remains pending.

## RI-05 Lifecycle / recovery
Acceptance explicitly covers Background → Foreground, Force Close → Relaunch, Dirty Draft, stale async rejection, duplicate-submit protection, and restore context re-resolution.

## RI-06 Source integration regression
- Source regression: 35 PASS lines / 0 product FAIL
- PAX-01～06 and CM-02～06 preserved
- Core hash audit: NativePayrollMath / Repository / Storage / Snapshot / Backup Crypto SAME; Native Backup differs only in product version binding.

## Environment result
This execution environment does not contain esbuild, Android SDK/ADB, Xcode/xcode npm module. Production/native build and physical-device gates remain `PENDING_ENVIRONMENT` / `PENDING_DEVICE_QA`.

RC / Stable promotion remains unauthorized.
