# PAX-06｜Full Regression & dev.2 Freeze Gate

Status: **DEVELOPMENT SOURCE FREEZE PASS / FULL PLATFORM GATE PENDING**

## Freeze decision
- PAX-01 Visual Polish & Density: PASS / PRESERVED
- PAX-02 Accessibility / Keyboard / Touch: PASS / PRESERVED
- PAX-03 Validation / Error Messaging: PASS / PRESERVED
- PAX-04 Loading / Empty / Failure: PASS / PRESERVED
- PAX-05 Navigation / Draft / Context: PASS / PRESERVED
- PAX-06 Full Regression / dev.2 Source Freeze: PASS
- Full Platform Build / Device Gate: PENDING_ENVIRONMENT
- Physical Device QA: PENDING_DEVICE_QA
- RC / Stable Promotion: NOT AUTHORIZED

## Regression evidence
- Fixed executable gate list: 27 / 27 PASS
- Product FAIL: 0
- Schema: 13
- Version Drift: 0
- `ios-gate-test`: PASS
- `ios-foundation-test`: PENDING_ENVIRONMENT (`xcode` npm module unavailable)
- Production build: PENDING_ENVIRONMENT (`esbuild` unavailable)
- Android SDK / ADB / Gradle: PENDING_ENVIRONMENT
- Kotlin compiler: available; native payroll gate PASS

## Critical invariants
- Tax boundary remains 86,000 -> 0; 86,001 -> 0; 86,002 -> 4,300.
- OT multipliers remain 1 / 1.34 / 1.67 / 2 / 2.67; Lunar New Year 2.5.
- Year-End runtime Golden remains $153,900.
- Historical OT retained evidence remains 914 + 459 = 1,373 with 1,373 unique compound identities.
- Snapshot retention remains latest 3.
- Current Company does not silently fall back to the first company.
- Wrong-company write observed automated: 0.
- Duplicate UI write observed automated: 0.
- No second canonical Payroll / OT / Leave / Salary / Company store is introduced.

## Core isolation vs PAX-05 R1
Byte-identical:
- NativePayrollMath.kt
- NativeSalaryMateRepository.kt
- src/storage.js
- src/snapshot-store.mjs
- src/backup-crypto.mjs
- src/native-backup.mjs

## Freeze policy
This source is frozen for dev.2. No new feature work is permitted on the frozen snapshot. PAX-06 does not imply RC readiness: Production build, Android/iOS native builds and physical-device acceptance remain mandatory before RC promotion.
