# CM-02｜Company Management Shell

Status: **IMPLEMENTATION REGRESSION PASS / PLATFORM BUILD & DEVICE PENDING**

## Scope

- Single Company Management entry.
- Dashboard company selector is switch-only.
- Current company card + other companies list.
- Company detail and basic edit are separate states.
- Add company uses only: company name, base salary, employment start date.
- First company becomes current automatically.
- Adding a second company does not change current company.
- Duplicate company name is a warning, not a hard error.
- Base salary 0 is a warning, not a hard error.
- Existing full company settings remain as a compatibility entry for CM-03 / CM-04.

## Data contract

- Existing Schema 13 only.
- Existing company data in the canonical snapshot only.
- Android writes through `NativeSalaryMateRepository`.
- No second Company Store / table / database.
- Payroll math, storage, snapshot and backup formats are unchanged.

## Platform integration

### Web / Shared

Company Management is a main navigation destination. The top company selector switches current company only; company creation/editing lives in Company Management.

### Android

`NativeCompanyManagementScreen` uses the existing repository for add/edit/switch operations. No independent company persistence layer was introduced.

### iOS

The current iOS Hybrid path consumes the shared Web Company Management shell. Native build/device confirmation remains a later gate.

## Regression

- Script gates: **17**
- PASS lines: **19**
- Product FAIL: **0**
- Version Drift: **0**

Core isolation audit:

- `NativePayrollMath.kt`: SAME
- `src/storage.js`: SAME
- `src/snapshot-store.mjs`: SAME
- `src/backup-crypto.mjs`: SAME
- `src/native-backup.mjs`: SAME

## Environment pending

- Android compile/device: PENDING_ENVIRONMENT — Android SDK is not available in the current execution container.
- `ios-foundation-test.mjs`: PENDING_ENVIRONMENT — locked `xcode` npm module is unavailable in the current execution container.

These are not recorded as product failures.

## Next

`CM-03｜Simplified Salary Rules`
