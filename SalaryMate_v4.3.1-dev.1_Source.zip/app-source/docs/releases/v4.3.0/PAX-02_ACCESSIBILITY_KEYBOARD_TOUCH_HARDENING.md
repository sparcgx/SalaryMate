# PAX-02｜Accessibility & Keyboard / Touch Hardening

Status: **IMPLEMENTATION REGRESSION PASS / PHYSICAL ACCESSIBILITY QA PENDING**

## Web contract

- Skip link to main content.
- Route change moves focus to the new page heading.
- Dialogs trap Tab / Shift+Tab and restore focus to the launcher after close.
- Escape and backdrop close use the existing Dirty Guard rather than bypassing it.
- Required fields expose `aria-required`.
- Help text is connected with `aria-describedby`.
- Native invalid events expose `aria-invalid` until corrected.
- Payroll Step 1 / 2 / 3 announces current step and total step count.
- Menu backup file trigger supports Enter / Space; Escape closes the open menu and restores focus.
- Radio-style interface settings support arrow-key movement and selection.
- Coarse-pointer controls use 44 px minimum targets; text controls use 48 px minimum height.
- Large-text mode allows summary/action wrapping instead of clipping critical money/status text.
- Reduced-motion preference disables non-essential motion.

## Android Compose contract

- Shared `AppHeader` and `SectionHeader` expose heading semantics.
- Custom home action cards expose Button role semantics.
- Quick-entry custom option rows expose Button role and selected-state description.
- Decorative bottom-navigation short labels and monogram are removed from accessibility semantics to avoid duplicate announcements.
- Material buttons / text fields retain native minimum interactive-component behavior.

## Identity / core isolation

- Product: `4.3.0-dev.2`
- Release: `4.3.0`
- Android versionCode: `15`
- iOS build: `3`
- Schema: `13`
- Version Drift: `0`

Byte-identical vs PAX-01 R1:
- `NativePayrollMath.kt`
- `NativeSalaryMateRepository.kt`
- `src/storage.js`
- `src/snapshot-store.mjs`
- `src/backup-crypto.mjs`
- `src/native-backup.mjs`

## Regression

- Executable source gates: **23 / 23 PASS**
- Product FAIL: **0**
- iOS result gate: **PASS**

## Pending physical QA

The current execution environment cannot claim:
- Android TalkBack physical-device reading order / touch-target QA
- Android soft-keyboard occlusion QA
- iOS VoiceOver / Dynamic Type physical-device QA
- iOS native project parser/build (`xcode` npm module unavailable)
- Production build (`esbuild` package unavailable in the clean execution environment)

These are `PENDING_ENVIRONMENT` / `PENDING_DEVICE_QA`, not product failures.

Next: **PAX-03｜Form Validation & Error Messaging**
