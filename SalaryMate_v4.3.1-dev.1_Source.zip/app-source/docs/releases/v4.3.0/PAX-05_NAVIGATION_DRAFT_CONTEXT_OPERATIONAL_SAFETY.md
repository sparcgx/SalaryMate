# PAX-05｜Navigation / Draft / Context Operational Safety

Status: **IMPLEMENTATION REGRESSION PASS / PHYSICAL OPERATIONAL QA PENDING**

## Operational safety model

Operational write target must satisfy:

`Draft.companyId = CurrentCompany.companyId = Commit.companyId`

Company Management is the intentional exception: an explicit non-current `targetCompanyId` may be viewed/edited without changing Current Company.

## Draft contract

- Draft Scope and Dirty are independent.
- Opening an editor is not Dirty.
- Editing and reverting to the original baseline returns to Clean.
- Payroll scope includes company + payroll month.
- Existing entity edits include entity identity.
- Year-End page drafts use the same scope/dirty contract.

## Context / navigation contract

- Operational company switch invalidates scoped selected entities and transient drafts.
- Context generation rejects stale async restore/read results.
- Browser Back follows logical Company Management parent routes.
- Browser/native navigation cannot silently discard a dirty draft.
- Android bottom navigation and system Back respect dirty payroll/company edits.

## Duplicate-submit contract

- Each editable draft gets an operation identity.
- Repeated submit of the same draft is blocked.
- Distinct new records do not share a coarse global dedupe key.
- Restore confirmation is operation-locked.

## Automated regression

- Executable source gates: **26 / 26 PASS**
- Product FAIL: **0**
- Schema: **13**
- Version Drift: **0**
- Wrong-company write observed in automated regression: **0**
- Duplicate UI write observed in automated regression: **0**

Physical rapid-switch/double-tap/lifecycle validation remains `PENDING_DEVICE_QA`.

## Core isolation vs PAX-04 R1

Byte-identical:
- `NativePayrollMath.kt`
- `NativeSalaryMateRepository.kt`
- `src/storage.js`
- `src/snapshot-store.mjs`
- `src/backup-crypto.mjs`
- `src/native-backup.mjs`

Environment pending:
- Production build / `esbuild`
- Android SDK / Gradle / physical device
- iOS `xcode` npm parser / native build

Next: **PAX-06｜Full Regression & dev.2 Freeze Gate**
