# CM-04｜Advanced Company Rules Simplification

Status: **IMPLEMENTATION REGRESSION PASS / FULL PLATFORM GATE PENDING**

## Information architecture

進階設定固定為：

1. 特殊薪資週期
2. 年度加薪
3. 年終規則
4. 其他特殊規則

## Data contract

- Schema remains 13.
- No second Company Store.
- No AdvancedRules / SpecialRules table.
- No arbitrary formula editor or Rule Engine.
- Annual Raise reuses existing `salaryAdjustments` with `reason = annual`.
- Year-End reuses existing `yearEndEstimates` and the existing Year-End calculation UI/core.
- Other Special Rules only summarizes already-supported company fields and links to the compatibility settings entry.

## Payroll cycles

Existing behavior remains compatible:
- Standard: `1 → month end`
- Legacy custom: `16 → next month 15`

CM-04 adds optional bounded company cycle fields in the existing Company JSON:
- `payrollCycleStartDay`
- `payrollCycleEndDay`

No schema bump is required because the Company object is already extensible in Schema 13.

Supported examples:
- `5 → 25` (same-month bounded period)
- `16 → 15` (cross-month)
- `20 → 19` (cross-month)

For a bounded same-month cycle such as `5 → 25`, dates outside the configured period remain unattributed (`null`). The resolver does **not** silently fall back to calendar month.

## Historical safety

Changing an advanced rule does not rewrite existing payslips, saved Year-End records, Snapshot / Lock data, or historical OT rows.

## Regression

- Script gates: 19 PASS / 0 FAIL
- PASS messages: 21
- Native Kotlin cycle execution: 16 PASS / 0 FAIL
- Version Drift: 0
- Schema: 13

Unchanged core files:
- `src/storage.js`
- `src/snapshot-store.mjs`
- `src/backup-crypto.mjs`
- `src/native-backup.mjs`

Intentional core extension:
- `NativePayrollMath.kt`: payroll-period resolver only; existing calendar / prev16 behavior preserved.
- `NativeSalaryMateRepository.kt`: optional custom-cycle field parsing only.

Environment pending:
- Android full Gradle/device gate: PENDING_ENVIRONMENT
- iOS Foundation parser: PENDING_ENVIRONMENT (`xcode` npm module unavailable in current container)

Next: **CM-05｜Company Workflow Simplification & Cross-Platform UX**
