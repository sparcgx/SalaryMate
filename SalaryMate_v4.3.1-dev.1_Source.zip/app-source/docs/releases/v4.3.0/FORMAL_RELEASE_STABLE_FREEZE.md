# v4.3.0｜Formal Release & Stable Freeze

- Date: 2026-09-27
- Source: v4.3.0-RC.2
- Android physical QA: PASS
- iOS physical QA: PASS
- Stable promotion: PASS
- Schema: 13
- Android package: com.salarymate.personal
- Android versionCode: 19
- iOS build: 7

No feature or business-rule changes are part of this promotion. Future changes must branch from this frozen stable baseline.
