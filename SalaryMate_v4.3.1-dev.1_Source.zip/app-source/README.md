# SalaryMate

## Current Release Candidate Baseline

**v4.3.0-RC.2｜Full Regression & Release Candidate Freeze Gate**

- Product: `4.3.0-RC.1`
- Release target: `4.3.0`
- Schema: `13`
- Android versionCode: `18`
- iOS build: `6`
- RC source regression: **47 PASS / 0 FAIL**
- RC source freeze: **PASS**
- Full platform build/device: **PENDING_ENVIRONMENT**
- Physical device QA: **PENDING_DEVICE_QA**
- Stable promotion: **NOT AUTHORIZED**

RC.1 freezes the source candidate. Payroll, Tax, OT, Year-End, repository/storage, snapshot and backup-crypto business contracts remain unchanged from dev.4. Native backup differs only in product-version binding.

Physical Android/iOS build, in-place upgrade/data preservation, backup/restore round-trip, lifecycle/long-session and manual accessibility acceptance remain mandatory before Stable promotion.

See:
- `RELEASE_GATE_v4.3.0-RC.2.md`
- `REAL_DEVICE_ACCEPTANCE_v4.3.0-RC.2.md`
- `release-evidence/v4.3.0-RC.2_Full_Regression_Release_Candidate_Freeze.txt`
