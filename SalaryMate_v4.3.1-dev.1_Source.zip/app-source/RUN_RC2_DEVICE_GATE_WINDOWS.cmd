@echo off
setlocal
cd /d "%~dp0"
echo SalaryMate v4.3.0-RC.2 connected-device gate.
call RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd
exit /b %ERRORLEVEL%
