@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SalaryMate v4.3.1-dev.1 Compose APK Install

if not "%ANDROID_HOME%"=="" goto sdk_ready
if not exist "%LOCALAPPDATA%\Android\Sdk" goto sdk_ready
set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
:sdk_ready

set "ADB=%ANDROID_HOME%\platform-tools\adb.exe"
set "APK=%CD%\output\SalaryMate_v4.3.1-dev.1-release.apk"

if not exist "%ADB%" goto missing_adb
if not exist "%APK%" goto missing_apk

if exist "output" goto output_ready
mkdir "output"
:output_ready

echo This RC build uses package com.salarymate.personal.
echo It upgrades the existing Release App only when signed with the same key.
echo Export two encrypted .salarymate backups before continuing.
echo Do not uninstall the existing App and do not clear App data.
echo.
echo Enable Android Developer Options and USB debugging.
echo Connect the unlocked phone, then approve the USB debugging prompt.
echo.
"%ADB%" devices
echo.
"%ADB%" get-state | findstr /X /C:"device" >nul
if errorlevel 1 goto missing_device

set "PRE_REPORT=%CD%\output\FORMAL_preinstall_identity.txt"
set "POST_REPORT=%CD%\output\FORMAL_postinstall_identity.txt"
"%ADB%" shell dumpsys package com.salarymate.personal | findstr /C:"versionCode=" /C:"versionName=" > "%PRE_REPORT%"
if not errorlevel 1 goto preinstall_ready
echo NOT_INSTALLED> "%PRE_REPORT%"
echo HOLD: No installed Release App to verify data-preserving upgrade.
goto hold
:preinstall_ready

echo Pre-install identity saved to output\FORMAL_preinstall_identity.txt
choice /C YN /N /M "Continue with data-preserving adb install -r? [Y/N] "
if errorlevel 2 goto cancelled

echo.
echo Installing the signed RC APK without clearing existing App data...
"%ADB%" install -r "%APK%"
if errorlevel 1 goto failed

"%ADB%" shell dumpsys package com.salarymate.personal | findstr /C:"versionCode=" /C:"versionName=" > "%POST_REPORT%"
if errorlevel 1 goto identity_failed
findstr /C:"versionCode=20" "%POST_REPORT%" >nul
if errorlevel 1 goto identity_failed
findstr /C:"versionName=4.3.1-dev.1" "%POST_REPORT%" >nul
if errorlevel 1 goto identity_failed

echo.
echo SUCCESS. v4.3.1-dev.1 is installed with versionCode 20.
echo Pre/post identity reports are in the output folder.
echo Keep the previous package and encrypted backups until the formal gates pass.
echo Follow ANDROID_v4.1.0_ACCEPTANCE.md.
pause
exit /b 0

:missing_adb
echo HOLD: ADB was not found. Install Android SDK Platform-Tools in Android Studio.
goto hold

:missing_apk
echo HOLD: Run BUILD_ANDROID_WINDOWS.cmd first.
goto hold

:missing_device
echo HOLD: No authorized Android device is connected.
echo Unlock the phone, enable USB debugging, approve the prompt, and retry.
goto hold

:cancelled
echo.
echo CANCELLED. No package was installed and App data was not changed.
goto hold

:identity_failed
echo.
echo INSTALL FAILED: v4.3.1-dev.1 package identity verification did not pass.
echo Do not uninstall the existing App or clear its data.
goto hold

:failed
echo.
echo INSTALL FAILED. Do not uninstall the current App or clear its data.
echo If you see unauthorized, unlock the phone and approve USB debugging.

:hold
pause
exit /b 1
