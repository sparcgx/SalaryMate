# v4.1.0-dev.3｜薪資快速建立與核心操作原生化開發閘門

日期：2026-09-18

## R2 編譯修正（2026-09-22）

- 修正 Windows Debug APK 建置發現的 Kotlin `money(Long)` 重複 formatter 衝突。
- 移除 `NativeHomeScreen.kt` 的重複私有 formatter，首頁、快速登記與薪資頁統一使用既有套件共用 formatter。
- 新增原生 UI formatter 唯一性回歸檢查，避免再次出現 `Overload resolution ambiguity`／`Conflicting overloads`。
- Capacitor Filesystem deprecated 與 Gradle 9 相容性訊息為第三方／未來升級警告，不列為本次編譯阻擋。

## 基線與範圍

- 輸入基線：已完成 Android 12 實機驗收 1～28 的 `v4.1.0-dev.2 R2 ShortPath`。
- dev2-R2 保持凍結；本分支升版為 versionCode 9／versionName 4.1.0-dev.3。
- Schema 13、`salarymateSQLite.db`、Web 薪資核心、加密備份格式及歷史資料不變。
- 本版原生化月薪建立、清單、編輯、複製下一月與刪除確認；複雜自訂加扣項及分析仍由完整核心處理。

## 開發閘門

| 檢查 | 狀態 | 證據／限制 |
|---|---|---|
| 基線隔離 | PASS | dev2-R2 工作樹與交付 ZIP 未修改 |
| 單一資料來源 | PASS（靜態） | 原生 Repository 只使用既有 `snapshots` 表與 Schema 13 `records`，沒有第二套薪資表 |
| Snapshot 交易 | PASS（靜態） | INSERT 與保留最近 3 份 DELETE 使用同一個 `executeSet(..., true)` 交易 |
| Schema 寫入保護 | PASS（靜態） | 僅 Schema 13 可由原生建立／編輯／刪除；其他版本停止並要求完整核心遷移 |
| 公司與調薪預設 | PASS（靜態） | 依計薪區間末日選擇最近已生效調薪，否則使用公司固定薪資 |
| 加班歸屬 | PASS（規格測試） | 依公司月底制或 16→15 制，只彙總同公司與同薪資月加班 |
| 派遣時薪 | PASS（靜態） | 三位小數時薪 × 0.5 間隔正常工時，儲存獨立月薪快照 |
| 稅額邊界 | PASS（單元規格） | 應發 `86,001` 不預扣；嚴格大於門檻才以 5% 四捨五入 |
| 入帳日 | PASS（單元規格） | 次月 5 日，週六／週日向前移至星期五；國定假日明確要求人工確認 |
| 重複阻擋 | PASS（靜態） | 同公司、同年份、同月份排除目前編輯 ID 後不得重複 |
| 複製安全 | PASS（靜態） | 目標月重套薪資與加班；獎金／副業歸零；舊 `leave-sync` 扣項移除 |
| 編輯相容 | PASS（靜態） | 既有自訂加扣項、sourceType／sourceKey 與歷史金額快照保留 |
| 刪除確認 | PASS（靜態） | UI 顯示公司／年月；Repository 只移除目標 ID 並建立新 snapshot |
| App 鎖與畫面保護 | PASS（沿用） | Compose 啟動入口在載入資料前驗證裝置，沿用既有安全偏好 |
| dev2 Android 12 基線 | PASS | 使用者已確認實機驗收 1～28 全數通過 |
| Node／Web 回歸 | PASS | `npm test`、`npm run build`、`npm run android:sync` 全部通過；runtime audit 為 0 個弱點 |
| Android 編譯 | 待 Windows | 目前環境無 Android SDK／JDK 21；需由 Windows 建置腳本完成單元與 instrumentation 編譯 |
| dev.3 Android 12 | 待驗收 | 抽測舊項目並完成新增 29～42 |

## 安全邊界

- 國定假日沒有內建年度行事曆；預設入帳日只自動避開週六與週日，畫面要求使用者依公司公告確認。
- 原生編輯鎖定公司與歸屬年月；需要改變索引時建立正確月份後再刪除舊筆，避免跨公司誤移。
- 自訂加扣項在原生畫面只顯示與保留；新增、刪除自訂項及請假扣款同步由完整核心處理。
- 若 latest snapshot 無效、缺欄位或資料庫無法開啟，原生畫面停止顯示／寫入，不建立空白替代資料。
- Release 覆蓋測試前必須有兩份已驗證可解密的外部備份。

## GO／HOLD

- 原始碼與本機回歸通過後，可進入 Windows Debug APK 建置與合成資料測試。
- 在 Android 編譯、29～42 實機清單與覆蓋資料驗證完成前，狀態為 **HOLD FOR RELEASE**。
- 不得上傳 Production；需要商店驗證時只使用 Google Play Internal testing。
