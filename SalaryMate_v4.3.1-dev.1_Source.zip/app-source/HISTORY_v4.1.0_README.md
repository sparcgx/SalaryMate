# 個人薪資管理 v4.1.0｜正式版原始碼與放行準備

本版從 `v4.1.0-RC.1` 獨立建立，保持 RC.1 與 dev.4-R2 原始碼不變。正式版僅升級版本身分與發布流程，不增加產品功能。

保留 R2 的 FileProvider 修正、`salarymateSQLite.db`、Schema 13、1,373 筆歷史 OT、Snapshot、App ID 與 `.salarymate` 加密格式。此 ZIP 是可建置的原始碼，不含已簽章 APK／AAB。

## 正式版準備狀態

- 版本身分升為 `versionCode 12`／`versionName 4.1.0`。
- RC.1 的 1～72、Windows 編譯、升級、備份互通及 Play Internal testing 證據尚未提供。
- 因此目前是 **HOLD FOR RELEASE**；僅供正式版建置及驗收，不代表已上架或核准 Production。
- 依 `RELEASE_GATE_v4.1.0.md`、`ANDROID_v4.1.0_ACCEPTANCE.md` 完成驗收，將結果填入 `FORMAL_RELEASE_EVIDENCE.md`。

## 本版完成範圍

- Compose「設定」改為原生資料與安全中心，不必先開啟 Web 核心。
- 原生 AES-256-GCM 加密備份，沿用 PBKDF2-SHA-256、310,000 次與既有 `.salarymate` 格式。
- 使用 Android 系統檔案選擇器另存，寫入後重新讀取並比對 SHA-256。
- 使用 Android 系統分享加密檔案；分享結束後明確提醒到接收位置確認。
- 原生還原只接受通過密碼、加密標記、大小、UTF-8、Schema 13 與必要陣列驗證的資料。
- 錯誤密碼、損壞檔案、超過大小上限或舊 Schema 一律停止寫入。
- 原生切換 App 鎖與螢幕保護；App 鎖變更前必須通過 Android 裝置驗證。
- 加入立即鎖定，以及系統另存／選檔／分享期間不誤觸離開鎖定的生命週期保護。
- 加密在背景執行緒、檔案 I/O 在 IO 執行緒執行，並使用單一 busy guard 阻止重複操作。

dev.3 原生薪資能力完整保留：

- 底部導覽新增「薪資」，直接顯示既有月薪紀錄與應發／實際入帳。
- 原生快速建立月薪：選公司、歸屬年月、入帳日與常用薪資／扣除欄位。
- 依薪資月份區間末日套用公司固定薪資或已生效調薪。
- 派遣時薪以三位小數基本時薪 × 正常工時換算本月底薪。
- 依公司 `1 日～月底` 或 `前月 16 日～本月 15 日` 規則，自動彙總該期加班費。
- 入帳日預設次月 5 日；若遇週六或週日則提前至星期五。國定假日仍需依公司公告確認。
- 自動預扣所得稅：應發薪資嚴格大於 `86,001` 時按 5% 計算；可切換為手動金額。
- 即時顯示應發、代扣、勞退自提與含副業的實際入帳。
- 同公司同年月只允許一筆薪資；重複建立會停止寫入並提示改用編輯。
- 原生編輯保留歷史快照與既有自訂加扣項。
- 「複製下一月」會重新套用目標月份公司薪資與加班，獎金／副業歸零，移除舊的請假連動扣項，再交由使用者確認。
- 刪除前顯示公司與年月確認；取消不寫入，確認後以同一交易建立保護快照。
- 複雜自訂加扣項、請假扣款連動與分析仍可開啟完整薪資核心。

## 資料單一來源

Compose 不建立第二套薪資表。首頁、薪資、加班、請假與完整 Web 核心共用：

| 項目 | 實作 |
|---|---|
| SQLite 檔案 | `salarymateSQLite.db` |
| 資料合約 | Schema 13 JSON snapshot |
| 薪資陣列 | 同一份 `records` |
| 原生寫入 | `snapshots` 表內以單一交易新增完整快照 |
| 回復保護 | 每次寫入後保留最近 3 份 snapshot |
| 既有資料 | 公司、1,373 筆歷史 OT、請假、年終、調薪及介面設定原樣保留 |

若最新資料不是 Schema 13、公司已被刪除或 snapshot 結構無效，原生薪資會停止寫入，不會建立空白替代資料。

## 版本身分

- `versionCode 12`
- `versionName 4.1.0`
- Release App ID：`com.salarymate.personal`
- Debug App ID：`com.salarymate.personal.debug`
- Android：Kotlin 2.3.21、Compose BOM 2026.06.01、AGP 8.13、JVM 21

## Windows 建置

需要 JDK 21、Android API 36、Build Tools 35.0.0 與 Node.js 24 LTS。請將短路徑交付包解壓到 `C:\SalaryMate\v410-formal`，不要覆寫 RC.1，也不要在 ZIP 預覽畫面內逐檔拖曳。

先建立可與正式 App 並存的 Debug APK：

    BUILD_COMPOSE_DEBUG_WINDOWS.cmd
    INSTALL_COMPOSE_DEBUG_WINDOWS.cmd
    RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd

裝置 Gate 每次執行會新增 `test-results\formal-v4.1.0\<執行編號>\`，包含 `result.txt`（成功／失敗摘要）、`result.json`（逐步狀態與結束代碼）及 `test.log`（完整命令輸出）。若程式意外中斷，狀態保留 `INCOMPLETE`，不能當作 PASS。此紀錄僅涵蓋自動化測試；RC.1 的 1～72、同簽章升級、備份與 Play 安裝仍須人工實測，並將證據填入 `FORMAL_RELEASE_EVIDENCE.md`。分享日誌前先確認不含私人資料。

輸出：

    output\SalaryMate_v4.1.0-compose-debug.apk

需要以相同 App ID／upload key 驗證覆蓋升級時，才執行：

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\BUILD_SIGNED_ANDROID_WINDOWS.ps1

輸出：

    output\SalaryMate_v4.1.0-release.apk
    output\SalaryMate_v4.1.0-release.aab

正式資料實機驗證前，先匯出兩份可解密的 `.salarymate` 備份。Debug 與 Release 私有資料彼此隔離。若原 App 是本機簽章安裝並與本次簽章一致，可執行 `INSTALL_TO_ANDROID_WINDOWS.cmd` 覆蓋驗證；若是 Play 安裝版，請走 Internal testing 升級路徑，不要為了安裝測試版而解除安裝或清除資料。

## 驗收與版本邊界

- dev.4-R2 的 1～58 已通過；RC.1 的 1～72 尚無通過回報，不能視為已完成。
- 正式版需獨立核對 APK／AAB、覆蓋升級、資料、備份及 Play 安裝版。
- 全部 Gate 完成前不推送 Production；先使用 Internal testing。
- 任一薪資寫入或歷史資料保留失敗時，停止輸入正式資料，不解除安裝、不清除 App，保留備份並記錄失敗編號。
