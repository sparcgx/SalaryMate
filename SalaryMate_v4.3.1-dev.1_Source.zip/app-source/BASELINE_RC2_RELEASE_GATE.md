# v4.0.0-rc.2 已驗證基線

用途：保存 RC3 開始前已完成的 RC2 建置與實機證據。RC2 不在此套件內重新產製或改寫。

| 項目 | 狀態 | 證據／邊界 |
|---|---|---|
| 正式 App 身分 | PASS | `com.salarymate.personal`、versionCode 5、versionName `4.0.0-rc.2` |
| Windows signed APK／AAB | PASS | 使用者回報同一套件可成功編譯 APK 與 AAB |
| 建置內簽章驗證 | PASS | RC2 建置流程只有在 `apksigner`、`jarsigner` 與套件身分核對成功後才顯示 SUCCESS |
| Android 實機測試 | PASS | 使用者回報測試 OK；RC3 必須以同一 upload key 覆蓋升級再驗證 |
| R7 實機基線 | PASS | ZenFone 7 Pro／Android 12 測試 1–16 通過 |
| Google Play Internal testing | PENDING | 尚待 Google Play 官方處理與 Play 安裝版驗收 |

RC3 以此檔為可回復基線：不得改動 Schema 13、薪資計算、儲存鍵、備份格式或 RC2 upload key。若 RC2 → RC3 覆蓋升級失敗，停止上架流程，不得用解除安裝規避。
