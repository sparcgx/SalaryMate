@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SalaryMate v4.3.1-dev.1 Compose Android Build

echo.
echo =====================================================
echo  SalaryMate v4.3.1-dev.1 - Compose Signed APK and AAB Build
echo =====================================================
echo.

if not defined SALARYMATE_KEYSTORE_FILE goto signing_hold
if not defined SALARYMATE_KEY_ALIAS goto signing_hold
if not defined SALARYMATE_STORE_PASSWORD goto signing_hold
if not defined SALARYMATE_KEY_PASSWORD goto signing_hold
if not exist "%SALARYMATE_KEYSTORE_FILE%" goto missing_keystore

if not "%ANDROID_HOME%"=="" goto sdk_ready
if not exist "%LOCALAPPDATA%\Android\Sdk" goto sdk_ready
set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
:sdk_ready

if "%ANDROID_HOME%"=="" goto path_sdk_ready
set "PATH=%ANDROID_HOME%\platform-tools;%ANDROID_HOME%\cmdline-tools\latest\bin;%PATH%"
:path_sdk_ready

where node >nul 2>nul
if errorlevel 1 goto missing_node

for /f "usebackq delims=" %%J in (`node scripts\select-java-home-windows.mjs`) do set "JAVA_HOME=%%J"
if "%JAVA_HOME%"=="" goto missing_java
if not exist "%JAVA_HOME%\bin\keytool.exe" goto missing_java
set "PATH=%JAVA_HOME%\bin;%PATH%"
:java_path_ready

echo [1/10] Validating release keystore and signing passwords...
set "SIGNING_PREFLIGHT_CSR=%TEMP%\salarymate-upload-preflight-%RANDOM%.csr"
if exist "%SIGNING_PREFLIGHT_CSR%" del /Q "%SIGNING_PREFLIGHT_CSR%" >nul 2>nul
call "%JAVA_HOME%\bin\keytool.exe" -J-Duser.language=en -J-Duser.country=US -list -storetype JKS -keystore "%SALARYMATE_KEYSTORE_FILE%" -alias "%SALARYMATE_KEY_ALIAS%" -storepass:env SALARYMATE_STORE_PASSWORD >nul 2>nul
if errorlevel 1 goto signing_validation_failed
call "%JAVA_HOME%\bin\keytool.exe" -J-Duser.language=en -J-Duser.country=US -certreq -storetype JKS -keystore "%SALARYMATE_KEYSTORE_FILE%" -alias "%SALARYMATE_KEY_ALIAS%" -storepass:env SALARYMATE_STORE_PASSWORD -keypass:env SALARYMATE_KEY_PASSWORD -file "%SIGNING_PREFLIGHT_CSR%" >nul 2>nul
if errorlevel 1 goto signing_validation_failed
del /Q "%SIGNING_PREFLIGHT_CSR%" >nul 2>nul
set "SIGNING_PREFLIGHT_CSR="

echo [2/10] Installing locked dependencies...
call npm ci
if errorlevel 1 goto failed

echo [3/10] Checking JDK and Android SDK...
call npm run android:doctor
if errorlevel 1 goto environment_hold

echo [4/10] Running payroll, migration, and security tests...
call npm test
if errorlevel 1 goto failed

echo [5/10] Auditing runtime dependencies...
call npm run audit:runtime
if errorlevel 1 goto failed

echo [6/10] Building local App assets...
call npm run build
if errorlevel 1 goto failed

echo [7/10] Synchronizing Android plugins...
call npx cap sync android
if errorlevel 1 goto failed

echo [8/10] Compiling Android unit and instrumentation tests...
pushd android
call gradlew.bat :app:testDebugUnitTest :app:assembleDebugAndroidTest --no-daemon
set "TEST_BUILD_RESULT=%ERRORLEVEL%"
popd
if not "%TEST_BUILD_RESULT%"=="0" goto failed

echo [9/10] Building signed Release APK and AAB...
pushd android
call gradlew.bat clean assembleRelease bundleRelease --no-daemon
set "BUILD_RESULT=%ERRORLEVEL%"
popd
if not "%BUILD_RESULT%"=="0" goto failed

set "APK_SOURCE=android\app\build\outputs\apk\release\app-release.apk"
set "AAB_SOURCE=android\app\build\outputs\bundle\release\app-release.aab"
if not exist "%APK_SOURCE%" goto missing_output
if not exist "%AAB_SOURCE%" goto missing_output

echo [10/10] Verifying signatures and collecting outputs...
set "APKSIGNER=%ANDROID_HOME%\build-tools\35.0.0\apksigner.bat"
set "AAPT=%ANDROID_HOME%\build-tools\35.0.0\aapt.exe"
if not exist "%APKSIGNER%" goto missing_apksigner
if not exist "%AAPT%" goto missing_apksigner
call "%APKSIGNER%" verify --verbose --print-certs "%APK_SOURCE%"
if errorlevel 1 goto failed
call "%AAPT%" dump badging "%APK_SOURCE%" | findstr /C:"package: name='com.salarymate.personal'" >nul
if errorlevel 1 goto failed
call "%AAPT%" dump badging "%APK_SOURCE%" | findstr /C:"versionCode='20'" >nul
if errorlevel 1 goto failed
call "%AAPT%" dump badging "%APK_SOURCE%" | findstr /C:"versionName='4.3.1-dev.1'" >nul
if errorlevel 1 goto failed
set "PERMISSION_REPORT=%TEMP%\salarymate-permissions-%RANDOM%.txt"
call "%AAPT%" dump permissions "%APK_SOURCE%" > "%PERMISSION_REPORT%"
if errorlevel 1 goto failed
findstr /L /C:"android.permission.INTERNET" /C:"android.permission.ACCESS_NETWORK_STATE" /C:"android.permission.READ_EXTERNAL_STORAGE" /C:"android.permission.WRITE_EXTERNAL_STORAGE" /C:"android.permission.MANAGE_EXTERNAL_STORAGE" /C:"android.permission.CAMERA" /C:"android.permission.RECORD_AUDIO" /C:"android.permission.ACCESS_FINE_LOCATION" /C:"android.permission.ACCESS_COARSE_LOCATION" /C:"android.permission.POST_NOTIFICATIONS" "%PERMISSION_REPORT%" >nul
if not errorlevel 1 goto unexpected_permission
del /Q "%PERMISSION_REPORT%" >nul 2>nul
set "PERMISSION_REPORT="
call "%JAVA_HOME%\bin\jarsigner.exe" -verify "%AAB_SOURCE%"
if errorlevel 1 goto failed
call "%JAVA_HOME%\bin\keytool.exe" -printcert -jarfile "%AAB_SOURCE%" >nul
if errorlevel 1 goto failed

if exist "output" goto output_ready
mkdir "output"
:output_ready
copy /Y "%APK_SOURCE%" "output\SalaryMate_v4.3.1-dev.1-release.apk" >nul
copy /Y "%AAB_SOURCE%" "output\SalaryMate_v4.3.1-dev.1-release.aab" >nul
certutil -hashfile "output\SalaryMate_v4.3.1-dev.1-release.apk" SHA256
certutil -hashfile "output\SalaryMate_v4.3.1-dev.1-release.aab" SHA256

echo.
echo SUCCESS. Signed v4.3.1-dev.1 test outputs created:
echo %CD%\output\SalaryMate_v4.3.1-dev.1-release.apk
echo %CD%\output\SalaryMate_v4.3.1-dev.1-release.aab
echo.
echo HOLD FOR RELEASE: do not upload to Production until RELEASE_GATE_v4.3.1-dev.1.md is approved.
echo Test first in Internal testing and follow ANDROID_v4.1.0_ACCEPTANCE.md.
pause
exit /b 0

:missing_node
echo.
echo HOLD: Node.js was not found. Install Node.js 24 LTS, close this window, and retry.
goto hold

:missing_java
echo.
echo HOLD: JDK 21 with keytool was not found. Install or select JDK 21, then retry.
goto hold

:signing_hold
echo.
echo HOLD: Release signing variables are incomplete.
echo Read ANDROID_RELEASE_SIGNING.md. Never place passwords inside this project.
goto hold

:missing_keystore
echo.
echo HOLD: SALARYMATE_KEYSTORE_FILE does not point to an existing file.
goto hold

:signing_validation_failed
if defined SIGNING_PREFLIGHT_CSR if exist "%SIGNING_PREFLIGHT_CSR%" del /Q "%SIGNING_PREFLIGHT_CSR%" >nul 2>nul
echo.
echo HOLD: Release keystore, alias, store password, or private key password is incorrect.
echo Signing validation stopped before dependency installation and Gradle compilation.
goto hold

:environment_hold
echo.
echo HOLD: Complete each item marked HOLD above, then retry.
echo SDK items use Android Studio SDK Manager. This build requires JDK 21.
goto hold

:missing_apksigner
echo.
echo HOLD: Build Tools 35.0.0 apksigner was not found.
goto hold

:missing_output
echo.
echo FAILED: Gradle returned success, but the Release APK or AAB was not found.
goto hold

:unexpected_permission
if defined PERMISSION_REPORT if exist "%PERMISSION_REPORT%" del /Q "%PERMISSION_REPORT%" >nul 2>nul
echo.
echo FAILED: The merged Release APK contains an unexpected network, storage, media, location, or notification permission.
goto hold

:failed
if defined PERMISSION_REPORT if exist "%PERMISSION_REPORT%" del /Q "%PERMISSION_REPORT%" >nul 2>nul
echo.
echo BUILD FAILED. Capture the first ERROR through the final line and send it for diagnosis.

:hold
echo.
pause
exit /b 1
