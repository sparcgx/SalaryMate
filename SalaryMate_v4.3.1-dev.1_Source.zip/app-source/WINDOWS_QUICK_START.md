# Windows 快速開始｜v4.1.0 正式版準備

本版會建立含 Jetpack Compose 原生外框的 APK 與 AAB。它仍沿用既有正式 App 的薪資核心與資料庫；線上網站不會被修改。

## 環境

1. Node.js 24 LTS。
2. Android Studio 與 JDK 21。本版將 Java、Kotlin 與 Gradle Toolchain 固定為 JVM 21。
3. Android SDK：API 36、Build Tools 35.0.0、Platform Tools。
4. 第一次建置保持網路連線，讓 npm 與 Gradle 下載依賴。

批次檔會尋找 `SALARYMATE_JAVA_HOME`、`JAVA_HOME`、Android Studio JBR 與常見 JDK 位置，且只接受 JDK 21，避免 Java/Kotlin 編譯目標不一致。

## 建置

首次 Compose 驗證建議使用獨立 Debug App，不需要 upload key，也不覆蓋正式 App：

    BUILD_COMPOSE_DEBUG_WINDOWS.cmd
    INSTALL_COMPOSE_DEBUG_WINDOWS.cmd

成功輸出：

    output\SalaryMate_v4.1.0-compose-debug.apk

完成 Debug 煙霧測試後，連接 Android 裝置並執行：

    RUN_FORMAL_DEVICE_GATE_WINDOWS.cmd

執行完在 `test-results\formal-v4.1.0\<執行編號>\` 查看 `result.txt`、`result.json` 和 `test.log`。每次測試分開存放；缺少環境或任何步驟失敗會留下 FAIL，意外中斷則維持 INCOMPLETE。自動化 PASS 不代表 1～72 手動驗收或正式發行通過。

完成 instrumentation gate 並確認 RC.1 的 1～72 驗收證據後，才進行下列正式身分覆蓋測試。

若要覆蓋既有正式身分測試，必須沿用相同的 keystore。推薦在專案資料夾開啟 PowerShell，使用隱藏密碼提示：

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\BUILD_SIGNED_ANDROID_WINDOWS.ps1

也可依 `ANDROID_RELEASE_SIGNING.md`，在同一個私人命令提示字元手動設定：

    SALARYMATE_KEYSTORE_FILE
    SALARYMATE_KEY_ALIAS
    SALARYMATE_STORE_PASSWORD
    SALARYMATE_KEY_PASSWORD

然後執行：

    BUILD_ANDROID_WINDOWS.cmd

它會先驗證 keystore、alias 與兩組密碼，再依序執行鎖定依賴安裝、環境檢查、薪資與資料安全回歸、執行期弱點稽核、Web 資產建置、Capacitor 同步、Android 測試編譯、Release APK/AAB 建置與簽章驗證。簽章資訊不正確時會在 npm 與 Gradle 前停止。

成功輸出：

    output\SalaryMate_v4.1.0-release.apk
    output\SalaryMate_v4.1.0-release.aab

## 測試方式

目前為正式版原始碼準備包、狀態 HOLD FOR RELEASE；依 `RELEASE_GATE_v4.1.0.md` 與 `ANDROID_v4.1.0_ACCEPTANCE.md` 留存證據。先在 Internal testing 驗證，不直接上傳 Production。

`INSTALL_TO_ANDROID_WINDOWS.cmd` 只供本機 signed APK 實機檢查。若手機目前安裝的是 Google Play 簽章版，本機 upload-key APK 可能無法直接覆蓋；不要為測試 Compose 而先解除安裝，應保留兩份加密備份並使用 Debug App 身分測試。

## 失敗處理

- `HOLD`：依畫面補齊環境或簽署設定。
- 建置失敗：回報第一個 ERROR 到最後一行。
- 安裝簽章衝突：不要刪除 R7；先保留兩份外部加密備份再處理 RC 測試 App。
- 不要把 keystore、密碼、APK 或 AAB 提交到公開儲存庫。
